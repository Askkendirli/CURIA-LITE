"""Regression tests for the 1055a34f941c4629 user run; inference and source transport are simulated."""
from __future__ import annotations
import json
from pathlib import Path
import pytest
import requests

from curia_lite.context import analyse_context, source_actor
from curia_lite.query import Query
from curia_lite.screening import valid_classification, request_messages, select_evidence, PROMPT_VERSION
from curia_lite.context_check import EXAMPLES, run_context_check
from curia_lite.sources import ENDPOINT, fetch_record, catalogue_query, DownloadError, VersionUnavailable, obtain
from curia_lite.publication import CATALOGUE_VERSION, rdf_catalogue
from curia_lite.keywords import OPERATORS, KeywordPlan
from test_publication_context_iteration import REC, EN, WORK, LANG3, PublicationNet, tree, q
from conftest import html

class RejectedCatalogue(PublicationNet):
    def get(self,url,headers=None,params=None):
        if url==ENDPOINT:
            self.calls.append((url,headers or {},params));response=requests.Response();response.status_code=500;response.url=url
            raise requests.HTTPError('SPARQL Request Failed — simulated regression',response=response)
        return super().get(url,headers,params)


def test_rejected_catalogue_still_recovers_english_from_independent_tree(cfg):
    net=RejectedCatalogue(english_tree=True)
    raw,_,resolved=fetch_record(REC,'en',cfg,net)
    assert raw==html(lang='en') and resolved==EN.replace('http:','https:')
    assert sum(u==ENDPOINT for u,_,_ in net.calls)==1
    assert any(h.get('Accept')=='application/rdf+xml;notice=tree' for _,h,_ in net.calls)


def test_rejected_catalogue_can_establish_narrow_publication_gap(cfg):
    net=RejectedCatalogue()
    with pytest.raises(VersionUnavailable) as caught:fetch_record(REC,'en',cfg,net)
    assert caught.value.available_languages==['fr']
    assert any(a.get('stage')=='publication-tree' for a in caught.value.attempts)
    assert sum(u==ENDPOINT for u,_,_ in net.calls)==1
    assert not any('/resource/celex/' in u for u,_,_ in net.calls)


def test_catalogue_and_tree_failure_cannot_be_cached_as_absence(cfg):
    net=RejectedCatalogue(notice_error=True)
    with pytest.raises(DownloadError) as caught:fetch_record(REC,'en',cfg,net)
    assert not isinstance(caught.value,VersionUnavailable)
    assert any(a.get('stage')=='publication-tree' for a in caught.value.attempts)


def test_rejected_catalogue_is_not_requested_twice_on_same_attempt(cfg):
    net=RejectedCatalogue(notice_error=True)
    with pytest.raises(DownloadError):fetch_record(REC,'en',cfg,net)
    assert sum(u==ENDPOINT for u,_,_ in net.calls)==1


def test_chosen_external_provider_can_recover_an_unlisted_cellar_file(cfg):
    class Alternative(RejectedCatalogue):
        def get(self,url,headers=None,params=None):
            if url.startswith('https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/'):
                self.calls.append((url,headers or {},params));return html(lang='en'),url,{'Content-Type':'text/html'}
            return super().get(url,headers,params)
    raw,url,_=fetch_record(REC,'en',cfg,Alternative())
    assert raw==html(lang='en') and 'eur-lex' in url


def test_query_is_bounded_without_unbounded_property_paths():
    text=catalogue_query(REC)
    assert 'sameAs)*' not in text and '|^' not in text
    assert 'LIMIT 5001' in text and 'UNION' in text and REC['celex'] in text
    assert CATALOGUE_VERSION==5


def test_failed_sparql_tree_recovery_works_through_archive_obtain(cfg,store):
    net=RejectedCatalogue(english_tree=True)
    result=obtain([REC],q(cfg),cfg,store,net,lambda *args,**kw:None)
    assert result['downloaded']==1 and not result['failures'] and not result['unavailable']
    assert store.read(result['documents'][0]['doc_id'])[0]['retrieval_language']=='en'


@pytest.mark.parametrize('context',[
 'Cases in which judges contrasted the wording of language versions',
 'Judgments comparing the English and French wording',
 'Affaires dans lesquelles la Cour compare les versions linguistiques',
 'Urteile in denen das Gericht Sprachfassungen vergleicht',
 'Casi in cui la Corte confronta le versioni linguistiche',
 'Asuntos donde el tribunal compara versiones lingüísticas',
 'Casos em que o tribunal compara versões linguísticas',
 'Zaken waarin het hof taalversies vergelijkt',
])
def test_comparison_paraphrases_are_understood_as_display_hints(context):
    assert analyse_context(context)['specific_language_comparison']


@pytest.mark.parametrize('context',[
 'Cases where the court refused recovery of State aid',
 'Claims by applicants seeking annulment',
 'Judgments in which a proportionality objection was rejected',
 'Tax disputes involving small businesses',
 'Opinions recommending prospective application only',
])
def test_all_contexts_receive_full_shared_evidence_requirements(cfg,context):
    query=Query.parse({'source_mode':'local','context':context,'languages':['en']},cfg)
    messages=request_messages({'doc_type':'judgment'},query,[{'id':1,'text':'A source passage.'}])
    payload=json.loads(messages[1]['content'])
    assert payload['CONTEXT']==context
    assert 'outcome and negation' in payload['EVIDENCE_CHECKS']
    assert 'target_actor' in messages[0]['content'] and 'partial means' in messages[0]['content']


def assess(cfg,context,text,*,target='deciding_court',actor='deciding_court',support='direct',score=5,scope='auto',kind='judgment',category='other_relevance'):
    query=Query.parse({'source_mode':'local','context':context,'languages':['en'],'actor_scope':scope},cfg)
    answer={'score':score,'category':category,'reason':'Synthetic assessment.','evidence':[1],
            'target_actor':target,'evidence_actor':actor,'support':support}
    return valid_classification(answer,[{'id':1,'paragraph':'31','text':text}],{'doc_type':kind},query,strict=True)


def test_general_court_action_not_proven_by_party_argument(cfg):
    r=assess(cfg,'Cases where the Court annulled a decision','31 The applicant argues that the decision should be annulled.')
    assert r['score']==2 and r['model_score']==5
    assert r['context_checks']['evidence_actor']=='party'


def test_party_question_accepts_party_evidence(cfg):
    r=assess(cfg,'Cases where the applicant requested annulment','31 The applicant argues that the decision should be annulled.',target='party',actor='party')
    assert r['score']==5


def test_public_authority_question_is_not_forced_into_court_frame(cfg):
    r=assess(cfg,'Cases where a customs authority recovered unpaid tax','31 The customs authority recovered unpaid tax.',target='public_authority',actor='public_authority')
    assert r['score']==5 and r['context_checks']['target_actor']=='public_authority'


def test_opinion_matches_advocate_general_question(cfg):
    r=assess(cfg,'Opinions in which the Advocate General proposes annulment','31 The Advocate General proposes annulment.',target='advocate_general',actor='advocate_general',kind='opinion')
    assert r['score']==5


def test_court_adoption_is_not_downgraded_to_party(cfg):
    text='31 The applicant argues that the decision must be annulled. The Court agrees and annuls that decision.'
    assert source_actor(text)=='deciding_court'
    assert assess(cfg,'Cases where the Court annulled a decision',text)['score']==5


def test_explicit_actor_override_is_enforced(cfg):
    r=assess(cfg,'Annulment requests','31 The applicant argues that the decision should be annulled.',target='party',actor='party',scope='deciding_court')
    assert r['score']==2 and r['context_checks']['target_actor']=='deciding_court'


@pytest.mark.parametrize('support,expected',[('direct',5),('partial',3),('background',2),('contradicted',1),('absent',1)])
def test_all_topics_share_support_ceiling(cfg,support,expected):
    r=assess(cfg,'The Court grants retroactive effect','31 The Court holds that the rule applies prospectively.',support=support)
    assert r['score']==expected


def test_negated_comparison_is_not_forced_to_applied_positive(cfg):
    r=assess(cfg,'Cases where the court refused to compare language versions',
             '31 The Court declines to compare language versions because this question does not arise.',category='other_relevance')
    assert r['score']==5 and not r['context_requirements']['specific_language_comparison']


def test_model_actor_interpretation_can_refine_a_court_cases_prefix(cfg):
    r=assess(cfg,'Court cases where the applicant compared language versions',
             '31 The applicant argues that the English and French language versions differ.',target='party',actor='party',category='party_argument')
    assert r['score']==5


def test_unknown_requested_actor_requests_clarification(cfg):
    r=assess(cfg,'Decisions involving a disputed act','31 The Court annuls the act.',target='unknown')
    assert r['score']==3


def test_single_version_correction_not_multilingual_comparison(cfg):
    r=assess(cfg,'Cases where the Court compared language versions',
             '184 The version in the language of the case contains an obvious error: applicant should read Commission, as the context indicates.',category='applied_current_comparison')
    assert r['score']==2 and r['model_score']==5


def test_specific_agreement_can_score_high(cfg):
    r=assess(cfg,'Cases where the Court compared language versions',
             '52 It should be noted that the same wording appears in the Spanish, German and French language versions.',category='applied_current_comparison',score=3)
    assert r['score']==4 and r['model_score']==3


def test_general_principle_remains_low_for_applied_comparison(cfg):
    r=assess(cfg,'Cases where the court compared language versions',
             '31 According to settled case-law, language versions must be interpreted uniformly.',category='general_multilingual_principle')
    assert r['score']==2


def test_strict_response_requires_all_general_context_fields(cfg):
    query=Query.parse({'source_mode':'local','context':'Tax refunds'},cfg)
    with pytest.raises(ValueError):valid_classification({'score':1,'category':'no_evidence','evidence':[],'reason':'No evidence.'},[],{},query,strict=True)


def test_footnote_no_longer_crowds_out_context_evidence(cfg):
    query=Query.parse({'source_mode':'local','context':'Cases where the court compared language versions','keywords':'language version','logic':'any_words','languages':['en']},cfg)
    text='* Language of the case: English.\n\n31 The Court examines a tax refund.\n\n32 It should be noted that different language versions use French and German formulations with the same meaning.'
    packets,_=select_evidence(text,query,'en',{**cfg,'snippets':1})
    assert 'same meaning' in packets[0][0]['text']
    assert KeywordPlan.create(query.keywords,query.logic).match(text)['qualified']


@pytest.mark.parametrize('name',list(OPERATORS))
def test_operator_help_quotes_example_search_terms(name):
    value=OPERATORS[name]
    description=value['description'] if isinstance(value,dict) else value[1]
    assert '"' in description


def test_model_diagnostic_uses_all_eight_scopes_with_mock_answers(cfg,tmp_path):
    class Model:
        def ready(self):return 'synthetic-model'
        def chat(self,messages):
            c=json.loads(messages[1]['content'])['CONTEXT'];x=next(x for x in EXAMPLES if x['context']==c)
            return {'score':x['expected'][1],'category':x['category'],'evidence':[1], 'reason':'Synthetic response for software validation.',
                    'target_actor':x['target'],'evidence_actor':x['actor'],'support':x['support']},{'elapsed_seconds':0}
    r=run_context_check(tmp_path,cfg,client=Model())
    assert r['passed'] and r['model_calls']==len(EXAMPLES) and len(r['checks'])==len(EXAMPLES)
    assert (tmp_path/'diagnostics/context-check.json').is_file()


def test_model_diagnostic_stops_after_transport_error(cfg,tmp_path):
    class Model:
        def ready(self):return 'synthetic-model'
        def chat(self,messages):raise TimeoutError('Synthetic model unavailable')
    r=run_context_check(tmp_path,cfg,client=Model())
    assert not r['passed'] and r['model_calls']==1 and r['stopped_early']


def test_model_diagnostic_inventory_failure_has_no_classifications(cfg,tmp_path):
    class Model:
        def ready(self):raise ConnectionError('Synthetic inventory failure')
    r=run_context_check(tmp_path,cfg,client=Model())
    assert not r['passed'] and not r['checks'] and r['model_calls']==0


def test_specific_confirmation_is_not_generic_principle_when_direct_support_is_explicit(cfg):
    r=assess(cfg,'Cases where the court compared language versions',
             '237 It should be noted that classification as limitation periods is confirmed by other language versions, in particular Spanish prescripción and French prescription.',
             category='general_multilingual_principle',score=5)
    assert r['category']=='applied_current_comparison' and r['score']==5
    assert r['model_category']=='general_multilingual_principle'


def test_cited_precedent_alone_is_not_current_court_action_for_general_context(cfg):
    r=assess(cfg,'Cases where the Court annulled a decision',
             '31 In an earlier judgment, an unrelated decision was annulled.',actor='deciding_court',category='quoted_precedent_only')
    assert r['score']==2 and r['context_checks']['evidence_actor']=='earlier_court'


def test_explicit_referral_question_accepts_referring_court(cfg):
    r=assess(cfg,'Cases where the national court questioned proportionality',
             '31 The referring court asks whether the measure is proportionate.',target='referring_court',actor='referring_court')
    assert r['score']==5


def test_placeholders_and_hover_help_are_example_labelled():
    root=Path(__file__).parents[1]/'curia_lite/web'
    text=(root/'index.html').read_text('utf-8')
    assert 'placeholder="Example: language version"' in text
    assert 'placeholder="Example: cases where the court compared language versions"' in text
    js=(root/'app.js').read_text('utf-8')
    assert 'option.onmouseenter=help' in js and 'option.onfocus=help' in js
    assert '"language"' in OPERATORS['any_words'][1] and '"version"' in OPERATORS['any_words'][1]


def test_latest_single_version_error_excerpt_is_downgraded_without_rewriting_history(cfg):
    data=json.loads((Path(__file__).parent/'fixtures/reviewed_20261015_evidence.json').read_text())
    row=next(x for x in data['assessments'] if x['case_id']=='C-382/22 P')
    query=Query.parse({'context':'cases where the court compared language versions','source_mode':'local','languages':['en']},cfg)
    original={k:row[k] for k in ('score','category','reason')};original['evidence']=[p['id'] for p in row['evidence']]
    checked=valid_classification(original,row['evidence'],row,query)
    assert checked['score']==2 and checked['model_score']==4 and row['score']==4


@pytest.mark.parametrize('case',['C-18/24','C-367/22 P','C-379/22 P'])
def test_reviewed_specific_agreement_under_shared_direct_rubric(cfg,case):
    data=json.loads((Path(__file__).parent/'fixtures/reviewed_20261015_evidence.json').read_text())
    row=next(x for x in data['assessments'] if x['case_id']==case)
    # These role/support labels are explicit review annotations for a software test, not a fresh model run.
    query=Query.parse({'context':'cases where the court compared language versions','source_mode':'local','languages':['en']},cfg)
    raw={'score':3 if case!='C-379/22 P' else 5,'category':row['category'],'reason':row['reason'],'evidence':[p['id'] for p in row['evidence']],
         'target_actor':'deciding_court','evidence_actor':'deciding_court','support':'direct'}
    checked=valid_classification(raw,row['evidence'],row,query,strict=True)
    assert checked['score']>=4


def test_loopback_general_preview_and_context_diagnostic_api(tmp_path,monkeypatch):
    import threading
    from http.server import ThreadingHTTPServer
    from curia_lite.server import Application,handler_class
    app=Application(tmp_path/'app');server=ThreadingHTTPServer(('127.0.0.1',0),handler_class(app))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    base=f'http://127.0.0.1:{server.server_port}';headers={'X-Curia-Token':app.token}
    monkeypatch.setattr('curia_lite.context_check.run_context_check',lambda home,cfg,**kw: {'passed':True,'checks':[],'model_calls':0,'status':'synthetic-api-check'})
    try:
        with requests.Session() as session:
            session.trust_env=False
            r=session.post(base+'/api/focus-preview',headers=headers,json={'context':'Applicant requests a tax refund','actor_scope':'party'})
            assert r.status_code==200 and r.json()['enabled'] and r.json()['requirements']['actor_hint']=='party'
            assert session.post(base+'/api/context-check',headers=headers,json={}).json()['status']=='synthetic-api-check'
            assert not app.diagnostic_lock.locked()
            with app.diagnostic_lock:
                assert session.post(base+'/api/search',headers=headers,json={}).status_code==400
                assert session.post(base+'/api/settings',headers=headers,json={'model':'other-model'}).status_code==400
    finally:server.shutdown();server.server_close()


def test_context_acceptance_can_be_stopped_between_requests(cfg,tmp_path):
    import threading
    cancel=threading.Event()
    class Model:
        def ready(self):return 'synthetic-model'
        def chat(self,messages):
            cancel.set()
            return {'score':5,'category':'direct_requested_relationship','evidence':[1],'reason':'Synthetic stop test.',
                    'target_actor':'deciding_court','evidence_actor':'deciding_court','support':'direct'},{}
    result=run_context_check(tmp_path,cfg,Model(),cancel)
    assert result['status']=='cancelled' and result['model_calls']==1


def test_context_diagnostic_language_requirement_checked_before_inference(cfg,tmp_path):
    class NoCalls:
        def ready(self):raise AssertionError('Inventory must not be checked for unsupported test language.')
    cfg={**cfg,'native_languages':['fr']}
    r=run_context_check(tmp_path,cfg,NoCalls())
    assert r['status']=='test-language-unavailable' and r['model_calls']==0
