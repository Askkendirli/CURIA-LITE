"""Regression fixtures for the saved 2025 test run. No live inference is claimed."""
from __future__ import annotations

import copy
import csv
import io
import json
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest
import requests
from docx import Document

from conftest import FakeModel, html
from curia_lite.concurrency import bounded_completed
from curia_lite.context import general_guard
from curia_lite.engine import execute
from curia_lite.export import write_exports
from curia_lite.extractor import parse_metadata,document_heading,paragraphs
from curia_lite.publication import rdf_catalogue,format_mime
from curia_lite.query import Query
from curia_lite.review import review_reason,specific_source_passage
from curia_lite.screening import semantic_result,valid_classification
from curia_lite.sources import fetch_record,ENDPOINT,LANG3,VersionUnavailable
from curia_lite.status_help import EN,definitions,counts_for
from test_publication_context_iteration import REC,WORK,EN as ENFILE,PublicationNet,tree

ROOT=Path(__file__).parent/'fixtures/iteration5'
HEADERS=json.loads((ROOT/'retrieval_header_previews.json').read_text())['examples']
EVIDENCE=json.loads((ROOT/'relevance_examples.json').read_text())['examples']

@pytest.mark.parametrize('sample',HEADERS,ids=[x['celex'] for x in HEADERS])
def test_reported_header_previews_are_identified(sample):
    result=parse_metadata(sample['preview'],celex_hint=sample['celex'],retrieval_language='en')
    assert result['doc_type']=='judgment' and result['extractor_version']==4
    assert result['delivery_date'].startswith('2025-')
    assert result['case_numbers']


def test_plural_header_contains_both_cases():
    text=next(x['preview'] for x in HEADERS if x['celex']=='62022TJ0830')
    assert parse_metadata(text,celex_hint='62022TJ0830',retrieval_language='en')['case_numbers']==['T-830/22','T-156/23']

@pytest.mark.parametrize('prefix',['EN','EN ','en','en '])
def test_prefixed_opinion_heading_preserves_type(prefix):
    h=document_heading(prefix+'OPINION OF ADVOCATE GENERAL\nSomeone')
    assert h['kind']=='opinion' and h['language']=='en'


def test_short_judgment_requires_both_court_and_own_t_case():
    assert document_heading('Judgment (Chamber giving preliminary rulings)\nOther text') is None
    assert document_heading('Judgment (Chamber giving preliminary rulings)\nIn Case C-1/25\nTHE GENERAL COURT') is None


def test_own_identity_ignores_case_in_subject_heading():
    text='JUDGMENT OF THE COURT\n\n10 July 2025\n\n(Reference concerning a Case C-99/23 cited in a heading)\n\nIn Case C-99/24,\n\n'+ 'Ordinary source text. '*30
    assert parse_metadata(text,celex_hint='62024CJ0099',retrieval_language='en')['case_numbers']==['C-99/24']
    with pytest.raises(ValueError):parse_metadata(text,celex_hint='62023CJ0099',retrieval_language='en')

@pytest.mark.parametrize('langdate',['13 February 2025','13. Februar 2025','13 février 2025','13 de fevereiro de 2025'])
def test_document_date_is_not_a_legal_paragraph(langdate):
    assert paragraphs(langdate)[0]['legal_paragraph']==''


def test_paragraph_containing_date_keeps_legal_number():
    assert paragraphs('23 On 10 May 2025 the applicant submitted its request.')[0]['legal_paragraph']=='23'

@pytest.mark.parametrize('fmt',['pdfa1a','pdfa1b','pdfa2a','pdfa2b','pdfa3a'])
def test_pdf_accept_preserves_subtype(fmt):assert format_mime(fmt)=='application/pdf;type='+fmt


def test_html_preferred_before_pdf(cfg):
    class Network(PublicationNet):
        def get(self,url,headers=None,params=None):
            if url==ENDPOINT:
                self.calls.append((url,headers or {},params))
                rows=[{'language':{'value':'http://publications.europa.eu/resource/authority/language/ENG'},'format':{'value':fmt},'item':{'value':item}} for fmt,item in [('pdfa2a',WORK+'.0002.04/DOC_1'),('xhtml',ENFILE)]]
                return json.dumps({'results':{'bindings':rows}}).encode(),url,{}
            return super().get(url,headers,params)
    net=Network(english_sparql=True)
    fetch_record(REC,'en',cfg,net)
    assert len(net.calls)==2 and not any(h.get('Accept','').startswith('application/pdf') for _,h,_ in net.calls)


def test_empty_catalogue_does_not_skip_rdf(cfg):
    class Network(PublicationNet):
        def get(self,url,headers=None,params=None):
            if url==ENDPOINT:
                self.calls.append((url,headers or {},params))
                rows=[{'language':{'value':'http://publications.europa.eu/resource/authority/language/ENG'}}]
                return json.dumps({'results':{'bindings':rows}}).encode(),url,{}
            return super().get(url,headers,params)
    net=Network(english_tree=True)
    raw,_,_=fetch_record(REC,'en',cfg,net)
    assert raw==html(lang='en')
    assert any(h.get('Accept')=='application/rdf+xml;notice=tree' for _,h,_ in net.calls)


def test_xml_literal_does_not_invent_publication_links():
    raw=tree().replace(b'</rdf:RDF>',f'''<rdf:Description rdf:about="urn:en"><cdm:label rdf:parseType="Literal"><span xmlns="http://www.w3.org/1999/xhtml"><a href="{ENFILE}">A metadata link</a></span></cdm:label></rdf:Description></rdf:RDF>'''.encode())
    c=rdf_catalogue(raw,REC,LANG3)
    assert c['established'] and c['file_languages']==['fr'] and not c['languages']['en']['items']


def test_rdf_collection_metadata_is_read_without_network_fetches():
    raw=tree(True).replace(b'</rdf:RDF>',b'<rdf:Description rdf:about="urn:metadata"><cdm:members rdf:parseType="Collection"><rdf:Description rdf:about="urn:a"/><rdf:Description rdf:about="urn:b"/></cdm:members><cdm:empty rdf:parseType="Collection"/></rdf:Description></rdf:RDF>')
    assert rdf_catalogue(raw,REC,LANG3)['file_languages']==['en','fr']

@pytest.mark.parametrize('attribute',['<unknown rdf:parseType="Unknown"/>','<!DOCTYPE x>'])
def test_unrecognised_xml_stays_rejected(attribute):
    raw=tree().replace(b'</rdf:RDF>',('<rdf:Description>'+attribute+'</rdf:Description></rdf:RDF>').encode())
    with pytest.raises(ValueError):rdf_catalogue(raw,REC,LANG3)


def query(cfg):return Query.parse({'source_mode':'local','languages':['en'],'context':'cases where the court compared language versions'},cfg)

@pytest.mark.parametrize('case',['C-346/23','C-405/24','C-570/24','T-409/24'])
def test_saved_low_scores_trigger_second_reading(cfg,case):
    d=next(x for x in EVIDENCE if x['case_id']==case)
    assert review_reason(d,d['reviewed_passages'],query(cfg))


def test_party_only_language_argument_is_not_promoted(cfg):
    p={'id':1,'text':'31 The applicant argues that the French and German language versions differ.'}
    a={'score':2,'category':'party_argument'}
    assert not review_reason(a,[p],query(cfg))


def test_partial_comparison_keeps_medium(cfg):
    ans={'score':3,'category':'partial_requested_relationship','evidence':[1],'reason':'Some conditions remain unclear.','target_actor':'deciding_court','evidence_actor':'deciding_court','support':'partial'}
    r=valid_classification(ans,[{'id':1,'text':'The Court discusses a translation difference whose significance remains to be explained.'}],{'doc_type':'judgment'},query(cfg),strict=True)
    assert r['score']==3


def test_mixed_source_evidence_does_not_overwrite_unresolved_current_actor(cfg):
    snippets=[{'id':1,'text':'22 Some language versions use an irrebuttable presumption, whereas others refer to a fair price.'},
              {'id':2,'text':'17 The referring court asks whether the wording differs.'}]
    a={'score':4,'category':'applied_current_comparison','evidence':[1,2],'reason':'The comparison applies the rule.','target_actor':'deciding_court','evidence_actor':'deciding_court','support':'direct'}
    out=valid_classification(a,snippets,{'doc_type':'judgment'},query(cfg),strict=True)
    assert out['score']==4 and out['context_checks']['evidence_actor']=='deciding_court'


def test_second_reading_is_cached_and_initial_answer_retained(cfg,store):
    meta=store.ingest(html(lang='en',body='31 The Court notes that all language versions except for Dutch use the plural.\n\n32 That wording therefore covers several consumers.'),language='en',celex='62025CJ0901')
    meta,text=store.read(meta['doc_id'])
    class Model(FakeModel):
        def chat(self,messages):
            self.calls+=1;p=json.loads(messages[1]['content'])['SNIPPETS'];anchor=next(x for x in p if 'except for Dutch' in x['text'])
            second='Recheck the exact requested relationship' in messages[0]['content']
            return {'score':4 if second else 2,'category':'applied_current_comparison' if second else 'contextual_background','evidence':[anchor['id']],
                    'reason':'Specific wording is analysed.','target_actor':'deciding_court','evidence_actor':'deciding_court','support':'direct' if second else 'background'},{'elapsed_seconds':0}
    model=Model();a=semantic_result(meta,text,query(cfg),cfg,store,model)
    assert model.calls==2 and a['score']==4 and a['evidence_review']['initial_score']==2
    assert [x['stage'] for x in a['packet_assessments']]==['initial','review']
    b=semantic_result(meta,text,query(cfg),cfg,store,model)
    assert model.calls==2 and b['cache_hits']==2 and b['evidence_review']['cached']
    c=semantic_result(meta,text,query(cfg),{**cfg,'review_uncertain':False},store,model)
    assert c['score']==2 and not c['evidence_review']['requested']


def test_recheck_can_lower_rating_and_failures_stay_visible(cfg,store):
    # A low conflicting first answer followed by no evidence must not retain the maximum score.
    meta=store.ingest(html(lang='en',body='31 The Court notes that the French language version differs from the German wording.'),language='en',celex='62025CJ0901')
    meta,text=store.read(meta['doc_id'])
    class Model(FakeModel):
        def chat(self,messages):
            self.calls+=1;p=json.loads(messages[1]['content'])['SNIPPETS'][0]
            second='Recheck the exact requested relationship' in messages[0]['content']
            return {'score':1 if second else 2,'category':'no_evidence' if second else 'contextual_background','evidence':[] if second else [p['id']],
                    'reason':'Synthetic review answer.','target_actor':'deciding_court','evidence_actor':'deciding_court','support':'absent' if second else 'background'},{'elapsed_seconds':0}
    model=Model();out=semantic_result(meta,text,query(cfg),cfg,store,model)
    assert out['score']==1 and out['evidence_review']['performed']


def test_many_tasks_keep_queue_bounded():
    consumed=[0];gate=threading.Event();cancel=threading.Event();received=[]
    def items():
        for i in range(5000):consumed[0]+=1;yield i
    def work(i):gate.wait(1);return i
    with ThreadPoolExecutor(max_workers=2) as pool:
        generator=bounded_completed(pool,work,items(),limit=4,cancel=cancel)
        def next_result():received.append(next(generator))
        worker=threading.Thread(target=next_result);worker.start()
        import time;time.sleep(.03)
        assert consumed[0]<=4
        cancel.set();gate.set();worker.join()
        list(generator)
    assert consumed[0]<=4 and received


def test_status_help_covers_all_interfaces():
    defs=definitions()
    assert set(defs)=={'en','fr','de'}
    for lang,entries in defs.items():
        assert set(entries)==set(EN)
        assert all(e['label'] and len(e['description'])>20 for e in entries.values())
    assert 'language version' in defs['en']['unlisted']['description']


def test_exports_explain_unlisted_and_keep_failed_separate(cfg,tmp_path):
    result=execute(tmp_path/'run',cfg,{'source_mode':'local','keywords':'absent'})
    result['acquisition']={'requested':5,'cached':1,'downloaded':1,'remaining':1,'publication_cache_hits':0}
    result['unavailable_versions']=[{'celex':'62025CJ0901','language':'en','available_languages':['fr'],'checked_at':'2026-10-15'}]
    result['failures']=[{'stage':'download','celex':'62025CJ0902','error':'A sample retrieval failure.'}]
    dest=tmp_path/'export';exports=write_exports(result,dest)
    doc=Document(dest/'shortlist.docx');text='\n'.join(p.text for p in doc.paragraphs)
    assert 'Unlisted' in text and 'These versions were left out' in text and 'Needs attention: 1' in text
    content=json.loads((dest/'results.json').read_text())
    guide={x['key']:x for x in content['status_guide']}
    assert guide['unlisted']['count']==1 and guide['failed']['count']==1
    rows=list(csv.DictReader((dest/'collection_status.csv').open(encoding='utf-8-sig')))
    assert next(x for x in rows if x['key']=='cached')['count']=='1'
    assert exports['collection_status']=='collection_status.csv'


def test_review_does_not_treat_phonetic_words_as_legal_versions(cfg):
    p={'id':1,'text':'The sound at the start of the English word home differs from some Spanish words.'}
    assert not review_reason({'score':1},[p],query(cfg))


def test_reported_party_letter_keeps_its_actor(cfg):
    p={'id':1,'text':'On 23 March 2023, the applicant informed the Council that, unlike the other language versions, the French version suggested a different relationship.'}
    assert not review_reason({'score':1},[p],query(cfg))


def test_single_encyclopaedia_language_is_not_a_review_trigger(cfg):
    p={'id':1,'text':'It is apparent from the article in the Spanish-language version of the online encyclopaedia Wikipedia that the acronym GEI can be used in Spain to refer to greenhouse gases.'}
    assert not review_reason({'score':1,'category':'no_evidence'},[p],query(cfg))
