from __future__ import annotations
import json
import threading
from pathlib import Path
import pytest
from curia_lite.settings import validate
from curia_lite.store import Store


@pytest.fixture
def cfg():return validate({})


@pytest.fixture
def store(tmp_path):return Store(tmp_path/'workspace')


def html(number='0901',lang='fr',body=None,kind='judgment'):
    heads={'fr':'ARRÊT DE LA COUR','en':'JUDGMENT OF THE COURT','de':'URTEIL DES GERICHTSHOFS',
           'es':'SENTENCIA DEL TRIBUNAL DE JUSTICIA','it':'SENTENZA DELLA CORTE',
           'pt':'ACÓRDÃO DO TRIBUNAL DE JUSTIÇA','nl':'ARREST VAN HET HOF'}
    labels={'fr':"Dans l’affaire",'en':'In Case','de':'In der Rechtssache','es':'En el asunto','it':'Nella causa','pt':'No processo','nl':'In zaak'}
    dates={'fr':'14 octobre 2025','en':'14 October 2025','de':'14. Oktober 2025','es':'14 de octubre de 2025','it':'14 ottobre 2025','pt':'14 de outubro de 2025','nl':'14 oktober 2025'}
    title=heads[lang] if kind=='judgment' else 'CONCLUSIONS DE L’AVOCAT GÉNÉRAL'
    body=body or '31 La Cour compare la version française à la version allemande. Les versions linguistiques divergent. Une comparaison précise est effectuée dans ce litige fictif.'
    return f'<html lang="{lang}"><body><h1>{title}</h1><p>{dates[lang]}</p><p>{labels[lang]} C-{int(number)}/25,</p><p>Synthetic Example A contre B</p><p>{body}</p><p>100 SYNTHETIC TEST ONLY. This is not an official document. These words exist only to exercise software behaviour.</p></body></html>'.encode()


class FakeModel:
    def __init__(self):
        self.cancel=threading.Event();self.model_digest='fake-model-digest';self.calls=0
    def ready(self):return self.model_digest
    def chat(self,messages):
        self.calls+=1
        data=json.loads(messages[-1]['content']);snippet=data['SNIPPETS'][0]
        return {'score':5,'category':'applied_current_comparison','evidence':[snippet['id']],'reason':'Synthetic classification, not actual model output.','target_actor':'deciding_court','evidence_actor':'deciding_court','support':'direct'},{'elapsed_seconds':0,'eval_count':1}
