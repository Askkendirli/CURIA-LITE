"""Publication recovery and source-role regressions prompted by the two supplied run exports."""
from __future__ import annotations
import io
import json
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
import pytest
import requests

from curia_lite.publication import rdf_catalogue, no_file_listed, format_mime, annotate_catalogue
from curia_lite.sources import (ENDPOINT, LANG3, fetch_record, obtain, VersionUnavailable, DownloadError,
                                publication_cache_key, Network)
from curia_lite.query import Query
from curia_lite.screening import select_evidence, valid_classification, screen, PROMPT_VERSION
from curia_lite.attribution import comparison_focus, passage_role
from curia_lite.extractor import source_content, parse_metadata, EXTRACTOR_VERSION
from curia_lite.common import utc_now
from conftest import html, FakeModel

WORK='http://publications.europa.eu/resource/cellar/aaaaaaaa-0000-4000-8000-000000000001'
WORK2='http://publications.europa.eu/resource/cellar/aaaaaaaa-0000-4000-8000-000000000002'
REC={'celex':'62025CJ0901','delivery_date':'2025-10-14','work_uri':WORK,'work_uris':[WORK]}
FR=WORK+'.0001.01/DOC_1'; EN=WORK+'.0002.01/DOC_1'

def catalogue_rows(english=False,unknown_format=False,pdf=False):
    rows=[{'language':{'value':'http://publications.europa.eu/resource/authority/language/ENG'}},
          {'language':{'value':'http://publications.europa.eu/resource/authority/language/FRA'},'format':{'value':'html'},'item':{'value':FR}}]
    if english:
        row={'language':{'value':'http://publications.europa.eu/resource/authority/language/ENG'},'item':{'value':EN}}
        if not unknown_format:row['format']={'value':'pdf' if pdf else 'xhtml'}
        rows.append(row)
    return rows


def tree(english=False,aliases=False,celex='62025CJ0901',unknown_format=False):
    # Real WEMI predicate forms, with artificial work/item identities and source text.
    data=f'''<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
        xmlns:cdm="http://publications.europa.eu/ontology/cdm#" xmlns:owl="http://www.w3.org/2002/07/owl#">
        <rdf:Description rdf:about="{WORK}"><cdm:resource_legal_id_celex>{celex}</cdm:resource_legal_id_celex>
          <cdm:work_has_expression rdf:resource="urn:fr"/><cdm:work_has_expression rdf:resource="urn:en"/></rdf:Description>
        <rdf:Description rdf:about="urn:fr"><cdm:expression_uses_language rdf:resource="http://publications.europa.eu/resource/authority/language/FRA"/>
          <cdm:expression_manifested_by_manifestation rdf:resource="urn:mf"/></rdf:Description>
        <rdf:Description rdf:about="urn:mf"><cdm:manifestation_type>html</cdm:manifestation_type><cdm:manifestation_has_item rdf:resource="{FR}"/></rdf:Description>
        <rdf:Description rdf:about="urn:en"><cdm:expression_uses_language rdf:resource="http://publications.europa.eu/resource/authority/language/ENG"/>
          {('<owl:sameAs rdf:resource="urn:en-alias"/>' if aliases else '')}
        </rdf:Description>'''
    if english:
        expression='urn:en-alias' if aliases else 'urn:en'
        data+=f'''<rdf:Description rdf:about="urn:me"><cdm:manifestation_manifests_expression rdf:resource="{expression}"/>
        {'' if unknown_format else '<cdm:manifestation_type>xhtml</cdm:manifestation_type>'}
        <owl:sameAs rdf:resource="urn:me-alias"/></rdf:Description>
        <rdf:Description rdf:about="{EN}"><cdm:item_belongs_to_manifestation rdf:resource="urn:me-alias"/></rdf:Description>'''
    return (data+'</rdf:RDF>').encode()


class PublicationNet:
    def __init__(self,english_tree=False,english_sparql=False,notice_error=False,unknown_format=False):
        self.cancel=threading.Event();self.calls=[];self.english_tree=english_tree
        self.english_sparql=english_sparql;self.notice_error=notice_error;self.unknown_format=unknown_format
    def check(self):
        if self.cancel.is_set():raise RuntimeError('cancelled')
    def get(self,url,headers=None,params=None):
        self.calls.append((url,headers or {},params))
        if url==ENDPOINT:
            return json.dumps({'results':{'bindings':catalogue_rows(self.english_sparql,self.unknown_format)}}).encode(),url,{}
        if (headers or {}).get('Accept')=='application/rdf+xml;notice=tree':
            if self.notice_error or url.endswith('000000000002'):raise requests.Timeout('Notice unavailable')
            return tree(self.english_tree,True),url,{'Content-Type':'application/rdf+xml'}
        if url==EN.replace('http:','https:') and (self.english_tree or self.english_sparql):
            return html(lang='en'),url,{'Content-Type':'application/xhtml+xml'}
        if url.startswith('https://eur-lex'):
            return b'<html><script>verification()</script></html>',url,{'Content-Type':'text/html'}
        response=requests.Response();response.status_code=404;response.url=url
        raise requests.HTTPError('fixture missing resource',response=response)


def q(cfg,refresh=False):
    return Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','languages':['en'],
                        'keywords':['language version'],'logic':'phrase','refresh':refresh},cfg)


def test_metadata_expression_not_a_file():
    c=rdf_catalogue(tree(),REC,LANG3)
    assert c['established'] and c['file_languages']==['fr']
    assert c['languages']['en']['publication_state']=='metadata-only'
    assert no_file_listed(c,'en') and not no_file_listed(c,'fr')


def test_tree_follows_expression_manifestation_item_aliases():
    c=rdf_catalogue(tree(True,True),REC,LANG3)
    assert c['file_languages']==['en','fr'] and c['languages']['en']['items'][0]['url']==EN.replace('http:','https:')


def test_untyped_item_is_retained_and_never_marked_unlisted():
    c=rdf_catalogue(tree(True,True,unknown_format=True),REC,LANG3)
    assert c['languages']['en']['items'] and not no_file_listed(c,'en')


def test_tree_rejects_wrong_work_and_all_empty_metadata_is_inconclusive():
    c=rdf_catalogue(tree(celex='62025CJ0999'),REC,LANG3)
    assert not c['established'] and not no_file_listed(c,'en')
    assert not no_file_listed({'established':True,'languages':{'en':{'formats':[],'items':[]}}},'en')


@pytest.mark.parametrize('content',[b'<!DOCTYPE x [<!ENTITY y SYSTEM "file:///etc/passwd">]><x/>',b'<not-rdf/>',tree().decode().encode('utf-16')])
def test_unsafe_or_unrecognised_notice_is_rejected(content):
    with pytest.raises(ValueError):rdf_catalogue(content,REC,LANG3)


@pytest.mark.parametrize('fmt,mime',[('html','text/html'),('xhtml','application/xhtml+xml'),('xhtml_simplified','application/xhtml+xml'),('pdf','application/pdf'),('pdfa1b','application/pdf;type=pdfa1b'),('fmx4','')])
def test_publication_format_mapping(fmt,mime):assert format_mime(fmt)==mime


def test_independent_tree_recovers_file_hidden_behind_sparql_alias(cfg):
    n=PublicationNet(english_tree=True)
    raw,_,resolved=fetch_record(REC,'en',cfg,n)
    assert raw==html(lang='en') and resolved.endswith('.0002.01/DOC_1') and len(n.calls)==3


def test_unknown_item_format_is_still_attempted(cfg):
    n=PublicationNet(english_sparql=True,unknown_format=True)
    raw,_,_=fetch_record(REC,'en',cfg,n)
    assert raw==html(lang='en') and len(n.calls)==2


def test_reconciled_metadata_only_result_avoids_speculative_404_chain(cfg):
    n=PublicationNet()
    with pytest.raises(VersionUnavailable) as e:fetch_record(REC,'en',cfg,n)
    assert sum(u==ENDPOINT for u,_,_ in n.calls)==1 and e.value.reason_code=='metadata-only-language'
    assert any('eur-lex' in u for u,_,_ in n.calls)
    assert all('/resource/celex/' not in u for u,_,_ in n.calls)
    assert e.value.available_languages==['fr'] and e.value.catalogue['reconciled_publication_tree']


def test_notice_failure_remains_unresolved_download(cfg):
    n=PublicationNet(notice_error=True)
    with pytest.raises(DownloadError):fetch_record(REC,'en',cfg,n)
    assert len(n.calls)>2


def test_one_failed_work_notice_prevents_cacheable_unavailability(cfg):
    n=PublicationNet()
    with pytest.raises(DownloadError):fetch_record({**REC,'work_uris':[WORK,WORK2]},'en',cfg,n)


def test_existing_file_failure_is_not_publication_absence(cfg):
    class Missing(PublicationNet):
        def get(self,url,headers=None,params=None):
            if '/DOC_1' in url:
                r=requests.Response();r.status_code=404;r.url=url
                raise requests.HTTPError('advertised file missing',response=r)
            return super().get(url,headers,params)
    with pytest.raises(DownloadError):fetch_record(REC,'en',cfg,Missing(english_sparql=True))


def test_unavailable_publication_check_is_cached_and_refreshable(cfg,store):
    n=PublicationNet();query=q(cfg)
    a=obtain([REC],query,cfg,store,n,lambda *a,**kw:None)
    assert not a['failures'] and len(a['unavailable'])==1
    initial_calls=len(n.calls);assert initial_calls>2
    b=obtain([REC],query,cfg,store,n,lambda *a,**kw:None)
    assert b['publication_cache_hits']==1 and len(n.calls)==initial_calls
    obtain([REC],q(cfg,True),cfg,store,n,lambda *a,**kw:None)
    assert len(n.calls)==initial_calls*2


def test_publication_cache_expiry_provider_and_valid_local_precedence(cfg,store):
    n=PublicationNet();query=q(cfg);obtain([REC],query,cfg,store,n,lambda *a,**kw:None)
    initial_calls=len(n.calls)
    key=publication_cache_key(REC,'en',cfg)
    old=store.cached(key);old['catalogue']['at']=(datetime.now(timezone.utc)-timedelta(hours=25)).isoformat();store.cache(key,old)
    obtain([REC],query,cfg,store,n,lambda *a,**kw:None);assert len(n.calls)==initial_calls*2
    assert publication_cache_key(REC,'en',{**cfg,'provider':'eurlex'})!=key
    store.ingest(html(lang='en'),language='en',celex=REC['celex'])
    result=obtain([REC],query,cfg,store,n,lambda *a,**kw:None)
    assert result['cached']==1 and not result['unavailable'] and len(n.calls)==initial_calls*2


def pdf_bytes(lines):
    # Minimal text PDF fixture requires no third-party PDF writer in CI.
    text='BT /F1 12 Tf 40 760 Td '+' '.join(('('+line.replace('\\','\\\\').replace('(','\\(').replace(')','\\)')+') Tj 0 -18 Td') for line in lines)+' ET'
    stream=text.encode('ascii')
    objects=[b'<< /Type /Catalog /Pages 2 0 R >>', b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
        b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 800] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
        b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',b'<< /Length '+str(len(stream)).encode()+b' >>\nstream\n'+stream+b'\nendstream']
    out=b'%PDF-1.4\n';offsets=[0]
    for i,o in enumerate(objects,1):offsets.append(len(out));out+=f'{i} 0 obj\n'.encode()+o+b'\nendobj\n'
    xref=len(out);out+=b'xref\n0 6\n0000000000 65535 f \n'+b''.join(f'{n:010} 00000 n \n'.encode() for n in offsets[1:])
    return out+f'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF'.encode()


def test_embedded_text_pdf_identity_language_and_storage(store):
    raw=pdf_bytes(['JUDGMENT OF THE COURT','14 October 2025','In Case C-901/25,','Synthetic Example A v B',
     '31 The English language version differs from the French wording.',
     '32 This material is an artificial software fixture for checking legal text extraction.',
     '33 The parties and facts are fictitious. Only source-reader behaviour is being tested.'])
    text,lang=source_content(raw);assert lang=='en' and 'language version' in text
    d=store.ingest(raw,language='en',celex=REC['celex'])
    assert d['source_path'].endswith('.pdf') and (store.home/d['source_path']).read_bytes()==raw
    assert d['source_format']=='pdf'
    with pytest.raises(ValueError):store.ingest(raw,language='fr',celex=REC['celex'])
    with pytest.raises(ValueError):store.ingest(raw,language='en',celex='62025CJ0902')


def test_pdf_without_text_is_rejected():
    with pytest.raises(ValueError):source_content(pdf_bytes([]))


@pytest.mark.parametrize('context,focused',[
 ('cases where the court compared language versions',True),('affaires dans lesquelles la Cour compare les versions linguistiques',True),
 ('court compared language versions to clarify a provision',True),('cases where the court did not compare language versions',False),
 ('the referring court compared language versions',False),('Commission arguments about language versions',False),('Advocate General compared language versions',False)])
def test_context_intent_applies_current_court_rubric(context,focused):assert bool(comparison_focus(context))==focused


def classify_fixture(cfg,text,category='applied_current_comparison',doc_type='judgment'):
    query=Query.parse({'context':'cases where the court compared language versions','preset':'general','source_mode':'local'},cfg)
    data={'score':5,'category':category,'evidence':[1],'reason':'Recorded simulated model assessment.'}
    return valid_classification(data,[{'id':1,'text':text}],{'doc_type':doc_type},query)


def test_commission_submission_in_supplied_evidence_is_not_current_court(cfg):
    text='79 The Commission contests the applicant’s arguments. In particular, it submits that its interpretation is borne out by the English-language version and the German-language version.'
    r=classify_fixture(cfg,text)
    assert r['score']==2 and r['category']=='party_argument' and r['model_score']==5 and r['guard_adjustments']


def test_generic_principle_in_general_context_is_capped(cfg):
    r=classify_fixture(cfg,'31 According to settled case-law, one language version cannot be the sole basis of interpretation.','general_multilingual_principle')
    assert r['score']==2 and r['model_category']=='general_multilingual_principle'


def test_referring_court_needs_further_current_reasoning(cfg):
    r=classify_fixture(cfg,'20 The referring court observes that the language versions differ.')
    assert r['score']==3 and r['category']=='referring_court_comparison'


def test_explicit_current_court_adoption_not_rejected(cfg):
    r=classify_fixture(cfg,'79 The Commission submits that the language versions differ. The Court agrees and adopts the comparison of the English and French versions.')
    assert r['score']==5 and r['category']=='applied_current_comparison'


def test_positive_specific_comparison_remains_high(cfg):
    r=classify_fixture(cfg,'41 It must be stated that the English and French language versions have different wording.')
    assert r['score']==5


def test_exact_keyword_passage_is_supplied_despite_many_generic_court_hits(cfg):
    text='\n\n'.join(f'{i} The court has compared the applications in these court cases.' for i in range(1,50))
    text+='\n\n72 The French-language version uses a mandatory verb.'
    query=Query.parse({'context':'cases where the court compared language versions','keywords':['language version'],'logic':'phrase','source_mode':'local'},cfg)
    packets,_=select_evidence(text,query,'en',cfg)
    assert any('French-language version' in p['text'] for p in packets[0])


def test_semantic_output_retains_input_evidence_keyword_rules_and_packet_answers(cfg,store):
    raw=html(lang='en',body='31 The English language version differs from the French version. The Court compares the wording.')
    meta=store.ingest(raw,language='en',celex=REC['celex']);query=Query.parse({'context':'cases where the court compared language versions','keywords':['language version'],'logic':'phrase','source_mode':'local'},cfg)
    model=FakeModel();out=screen([meta],query,cfg,store,threading.Event(),lambda *a,**kw:None,model)[0]
    assert out['reviewed_passages'] and out['packet_assessments'] and out['keyword_match']['qualified']
    assert out['effective_focus']=='court_language_comparison' and out['focus_origin']=='context-wording'
    assert out['prompt_version']==PROMPT_VERSION
    again=screen([meta],query,cfg,store,threading.Event(),lambda *a,**kw:None,model)[0]
    assert model.calls==1 and again['cache_hits']==1


def test_general_noncomparison_context_does_not_apply_comparison_caps(cfg):
    query=Query.parse({'context':'arguments advanced by the Commission','source_mode':'local'},cfg)
    r=valid_classification({'score':5,'category':'party_argument','evidence':[1],'reason':'Relevant to this different question.'},[{'id':1,'text':'The Commission submits an argument.'}],{},query)
    assert r['score']==5


def test_streaming_transfer_retry_preserves_response_validation(cfg,monkeypatch):
    calls=[]
    class Response:
        status_code=200;headers={}
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def raise_for_status(self):pass
        def iter_content(self,*args):
            if len(calls)==1:
                yield b'partial';raise requests.exceptions.ChunkedEncodingError('interrupted body')
            yield b'complete'
    class Session:
        def __init__(self):self.headers={}
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def get(self,url,**kwargs):calls.append(url);return Response()
    monkeypatch.setattr('curia_lite.sources.requests.Session',Session);cfg['request_interval']=0
    raw,_,_=Network(cfg).get(WORK,headers={'Accept':'text/html'})
    assert raw==b'complete' and len(calls)==2

@pytest.mark.parametrize('case,score,category',[
 ('C-524/23',1,'no_evidence'),('T-379/23',5,'applied_current_comparison'),('C-18/24',5,'applied_current_comparison'),
 ('C-286/24',2,'general_multilingual_principle'),('C-313/24',5,'applied_current_comparison'),
 ('C-619/24',3,'referring_court_comparison'),('T-69/25',5,'applied_current_comparison'),
 ('T-177/25',5,'applied_current_comparison'),('T-195/25',2,'party_argument')])
def test_replay_original_model_answers_against_retained_public_evidence(cfg,case,score,category):
    from curia_lite.attribution import guard_answer
    fixture=json.loads((Path(__file__).parent/'fixtures/retained_public_evidence.json').read_text('utf-8'))
    record=next(r for r in fixture['cases'] if r['case_id']==case)
    answer={**record['answer'],'evidence':[e['id'] for e in record['evidence']]}
    query=Query.parse({'context':'cases where the court compared language versions','preset':'general','source_mode':'local'},cfg)
    result=guard_answer(answer,record['evidence'],record,query)
    assert result['score']==score and result['category']==category


def test_nested_notice_has_same_catalogue_as_flat_notice():
    raw=tree().replace(b'<cdm:work_has_expression rdf:resource="urn:en"/>',b'<cdm:work_has_expression><rdf:Description rdf:about="urn:en"/></cdm:work_has_expression>')
    nested=rdf_catalogue(raw,REC,LANG3)
    assert nested['languages']==rdf_catalogue(tree(),REC,LANG3)['languages']


def test_pdf_item_retrieved_from_official_catalogue(cfg):
    raw=pdf_bytes(['JUDGMENT OF THE COURT','14 October 2025','In Case C-901/25,','Synthetic Example A v B',
      '31 The language version is the subject of this fictional example.',
      '32 This PDF contains embedded text used to verify extraction and identity checks.',
      '33 An artificial example never establishes the accuracy of a real judicial source.'])
    class Net(PublicationNet):
        def get(self,url,headers=None,params=None):
            if url==ENDPOINT:return json.dumps({'results':{'bindings':catalogue_rows(True,pdf=True)}}).encode(),url,{}
            assert headers['Accept']=='application/pdf'
            return raw,url,{'Content-Type':'application/pdf'}
    found,_,_=fetch_record(REC,'en',cfg,Net())
    assert found==raw


def test_availability_never_counts_as_an_analysed_document(cfg,store):
    from curia_lite.engine import execute
    result=execute(store.home,cfg,q(cfg).to_dict(),network=PublicationNet(),selection={'records':[REC]})
    assert result['status']=='completed-with-unavailable-versions'
    assert result['acquisition']['requested']==1 and result['summary']['eligible_documents']==0
    assert len(result['unavailable_versions'])==1 and not result['documents']
    assert not result['failures']


def test_new_settings_added_without_overwriting_existing_profile(tmp_path,cfg):
    from curia_lite.settings import load
    prior={k:v for k,v in cfg.items() if k not in {'curia_fallback','pdf_fallback','publication_ttl_hours'}}
    prior['num_ctx']=16384;prior['model']='ministral-3:14b'
    (tmp_path/'settings.json').write_text(json.dumps(prior))
    loaded=load(tmp_path)
    assert loaded['num_ctx']==16384 and loaded['model']=='ministral-3:14b'
    assert loaded['curia_fallback'] and loaded['pdf_fallback'] and loaded['publication_ttl_hours']==24


def test_word_excerpt_indicates_shortening_without_changing_json_source():
    from curia_lite.export import source_excerpt,plain_reason
    text='Long source paragraph. '*60
    short=source_excerpt(text)
    assert short.endswith(' […]') and len(short)<len(text)
    assert source_excerpt('Short text.')=='Short text.'
    assert plain_reason('Article **13(2)**')=='Article 13(2)'
