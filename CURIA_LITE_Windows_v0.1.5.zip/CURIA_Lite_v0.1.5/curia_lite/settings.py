from __future__ import annotations

import copy
import os
import re
from pathlib import Path
from urllib.parse import urlsplit

from .common import LANGUAGES, read_optional_object, write_json

# These are the EU languages explicitly named in the selected model family's documentation.
NATIVE_DEFAULTS = ['fr', 'en', 'de', 'es', 'it', 'pt', 'nl']
DEFAULTS = {
    'model': 'ministral-3:8b',
    'native_languages': NATIVE_DEFAULTS,
    'ollama_url': 'http://127.0.0.1:11434',
    'num_ctx': 8192,
    'num_predict': 256,
    'think': None,
    'temperature': 0.0,
    'keep_alive': '30m',
    'evidence_bytes': 5600,
    'snippets': 4,
    'llm_workers': 1,
    'review_uncertain': True,
    'connect_timeout': 10,
    'idle_timeout': 120,
    'request_deadline': 300,
    'discovery_ttl_hours': 24,
    'network_timeout': 45,
    'request_interval': 0.8,
    'download_workers': 2,
    'provider': 'cellar',
    'eurlex_fallback': True,
    'curia_fallback': True,
    'pdf_fallback': True,
    'publication_ttl_hours': 24,
    'browser_fallback': False,
    'browser_executable': '',
    'ui_language': 'en',
    'max_file_mb': 20,
}


def default_home() -> Path:
    env = os.getenv('CURIA_LITE_HOME')
    if env:
        return Path(env).expanduser().resolve()
    return (Path(os.getenv('LOCALAPPDATA', str(Path.home()))) / 'CURIA-Lite').resolve() if os.name == 'nt' else (Path.home() / '.curia-lite').resolve()


def validate(config: dict) -> dict:
    if not isinstance(config, dict) or set(config) - set(DEFAULTS):
        raise ValueError('Unknown setting or invalid configuration object.')
    c = copy.deepcopy(DEFAULTS)
    c.update(config)
    if not isinstance(c['model'], str) or not re.fullmatch(r'[A-Za-z0-9_.:/-]+', c['model']):
        raise ValueError('A valid local Ollama model tag is required.')
    if 'cloud' in c['model'].casefold():
        raise ValueError('Cloud model tags are not accepted by this local-only application.')
    u = urlsplit(c['ollama_url'])
    if u.scheme not in {'http', 'https'} or u.hostname not in {'127.0.0.1', 'localhost', '::1'} or u.username or u.password or u.query or u.fragment or u.path not in {'', '/'}:
        raise ValueError('Ollama must use a loopback HTTP(S) URL without credentials or a path.')
    langs = c['native_languages']
    if not isinstance(langs, list) or not langs or any(not isinstance(x, str) or x not in LANGUAGES for x in langs) or len(langs) != len(set(langs)):
        raise ValueError('native_languages must be a nonempty list of distinct EU language codes.')
    from .extractor import HEADING_LANGS
    unsupported = set(langs)-set(HEADING_LANGS)
    if unsupported:
        raise ValueError('Source-heading recognition must be extended before enabling: '+', '.join(sorted(unsupported)))
    bounds = {
        'num_ctx': (4096, 131072), 'num_predict': (128, 2048), 'evidence_bytes': (800, 50000),
        'snippets': (1, 20), 'llm_workers': (1, 4), 'connect_timeout': (1, 120),
        'idle_timeout': (10, 1800), 'request_deadline': (30, 7200), 'network_timeout': (5, 300),
        'download_workers': (1, 4), 'max_file_mb': (1, 100), 'discovery_ttl_hours': (0, 720), 'publication_ttl_hours': (0, 720),
    }
    for key, (lo, hi) in bounds.items():
        if type(c[key]) is not int or not lo <= c[key] <= hi:
            raise ValueError(f'{key} must be an integer between {lo} and {hi}.')
    if c['num_predict'] + 1800 >= c['num_ctx']:
        raise ValueError('The context must leave room for the screening prompt and evidence.')
    if type(c['temperature']) not in {int, float} or not 0 <= c['temperature'] <= 1:
        raise ValueError('temperature must be between 0 and 1.')
    if type(c['request_interval']) not in {int, float} or not 0.2 <= c['request_interval'] <= 10:
        raise ValueError('request_interval must be between 0.2 and 10 seconds.')
    for key in ('curia_fallback','pdf_fallback','review_uncertain'):
        if type(c[key]) is not bool:raise ValueError(f'{key} must be true or false.')
    if type(c['eurlex_fallback']) is not bool:
        raise ValueError('eurlex_fallback must be true or false.')
    if type(c['browser_fallback']) is not bool:
        raise ValueError('browser_fallback must be true or false.')
    if not isinstance(c['browser_executable'], str):
        raise ValueError('browser_executable must be a string.')
    if c['provider'] not in {'cellar', 'eurlex', 'curia'}:
        raise ValueError('provider must be cellar, eurlex, or curia.')
    if c['ui_language'] not in {'en', 'fr', 'de'}:
        raise ValueError('Interface language must be en, fr, or de.')
    if c['think'] is not None and type(c['think']) is not bool and c['think'] not in {'low', 'medium', 'high'}:
        raise ValueError('think must be null, a Boolean, or a supported model reasoning level.')
    if not isinstance(c['keep_alive'], str) or not re.fullmatch(r'(0|\d+[smh])', c['keep_alive']):
        raise ValueError('keep_alive must be 0 or a duration such as 30m.')
    return c


def load(home: Path) -> dict:
    home.mkdir(parents=True, exist_ok=True)
    p = home / 'settings.json'
    if p.exists():
        data = read_optional_object(p)
        if not data:
            raise ValueError(f'Settings are unreadable: {p}. Preserve the file and restore settings.example.json.')
        return validate(data)
    c = validate({})
    write_json(p, c)
    return c


def save(home: Path, changes: dict) -> dict:
    updated = validate({**load(home), **changes})
    write_json(home / 'settings.json', updated)
    return updated
