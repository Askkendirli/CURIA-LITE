"""Publication-file evidence and an independent, locally parsed CELLAR RDF tree."""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from collections import defaultdict
from urllib.parse import urlsplit

from .common import trusted_url, utc_now

CDM = 'http://publications.europa.eu/ontology/cdm#'
RDF = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#'
OWL = 'http://www.w3.org/2002/07/owl#'
CATALOGUE_VERSION = 5
HTML_FORMAT = re.compile(r'x?html(?:[_-](?:simplified|conv))?$', re.I)
PDF_FORMAT = re.compile(r'pdf(?:a[0-9]?[ab]?|[_-].*)?$', re.I)


def format_mime(value):
    value = str(value).rstrip('/').rsplit('/', 1)[-1].rsplit('#', 1)[-1].lower()
    if HTML_FORMAT.fullmatch(value):
        return 'application/xhtml+xml' if value.startswith('xhtml') else 'text/html'
    if PDF_FORMAT.fullmatch(value):
        return 'application/pdf' if value=='pdf' else 'application/pdf;type='+value
    return ''


def annotate_catalogue(catalogue):
    """An expression label and an actual publication file are separate catalogue facts."""
    for lang, entry in catalogue.get('languages', {}).items():
        entry.setdefault('formats', [])
        entry.setdefault('items', [])
        entry['publication_state'] = ('files-listed' if entry['items'] else
                                      'formats-listed' if entry['formats'] else 'metadata-only')
    catalogue['catalogue_version'] = CATALOGUE_VERSION
    catalogue['file_languages'] = sorted(k for k, v in catalogue.get('languages', {}).items() if v['items'])
    catalogue['metadata_languages'] = sorted(catalogue.get('languages', {}))
    return catalogue


def no_file_listed(catalogue, lang):
    """Return a narrowly scoped observation about the checked catalogue, not worldwide absence."""
    if not catalogue or not catalogue.get('established'):
        return False
    # At least one real file anchors the observation; an all-empty metadata graph is inconclusive.
    if not any(e.get('items') for e in catalogue.get('languages', {}).values()):
        return False
    entry = catalogue['languages'].get(lang)
    return entry is None or (not entry.get('formats') and not entry.get('items'))


def merge_catalogues(primary, supplementary):
    result = {**primary, 'languages': {k: {**v, 'formats': list(v.get('formats', [])),
                  'items': list(v.get('items', []))} for k, v in primary.get('languages', {}).items()}}
    for lang, entry in supplementary.get('languages', {}).items():
        dest = result['languages'].setdefault(lang, {'formats': [], 'items': []})
        dest['formats'] = list(dict.fromkeys(dest['formats'] + entry.get('formats', [])))
        for item in entry.get('items', []):
            if item not in dest['items']:
                dest['items'].append(item)
    result['established'] = bool(primary.get('established') or supplementary.get('established'))
    result.setdefault('checked_sources', [])
    result['checked_sources'] = list(result['checked_sources']) + supplementary.get('checked_sources', [])
    return annotate_catalogue(result)


def rdf_catalogue(raw: bytes, record: dict, lang3: dict) -> dict:
    """Parse only links in the supplied RDF tree; no remote entities or links are fetched here."""
    if b'\x00' in raw or len(raw) > 25 * 1024 * 1024 or re.search(br'<!\s*(?:DOCTYPE|ENTITY)', raw, re.I):
        raise ValueError('The publication notice contains unsupported XML declarations or is too large.')
    root = ET.fromstring(raw)
    if root.tag != '{' + RDF + '}RDF':
        raise ValueError('The publication notice is not an RDF tree.')
    triples = []
    counter=[0]
    def uri(tag):
        return tag[1:].replace('}', '', 1) if tag.startswith('{') else tag
    def blank():
        counter[0]+=1
        return '_:local'+str(counter[0])
    def node_subject(node):
        if node.get('{'+RDF+'}about'):return node.get('{'+RDF+'}about')
        if node.get('{'+RDF+'}nodeID'):return '_:'+node.get('{'+RDF+'}nodeID')
        return blank()
    def read_properties(subject,node,depth):
        if depth>32 or len(triples)>150000:
            raise ValueError('The publication notice exceeds its local parsing limit.')
        for child in node:
            predicate=uri(child.tag)
            resource=child.get('{'+RDF+'}resource')
            node_id=child.get('{'+RDF+'}nodeID')
            parse_type=child.get('{'+RDF+'}parseType')
            if resource is not None:
                if len(child):raise ValueError('Ambiguous RDF resource property.')
                triples.append((subject,predicate,resource,True))
            elif node_id is not None:
                if len(child):raise ValueError('Ambiguous RDF node reference.')
                triples.append((subject,predicate,'_:'+node_id,True))
            elif parse_type=='Resource':
                obj=blank();triples.append((subject,predicate,obj,True));read_properties(obj,child,depth+1)
            elif parse_type=='Literal':
                # XML literals are metadata values; their markup cannot introduce RDF links.
                literal=(child.text or '')+''.join(ET.tostring(x,encoding='unicode') for x in child)
                triples.append((subject,predicate,literal,False))
            elif parse_type=='Collection':
                members=list(child)
                if not members:
                    triples.append((subject,predicate,RDF+'nil',True))
                else:
                    current=blank();triples.append((subject,predicate,current,True))
                    for index,member in enumerate(members):
                        obj=node_subject(member);triples.append((current,RDF+'first',obj,True))
                        read_properties(obj,member,depth+1)
                        following=blank() if index+1<len(members) else RDF+'nil'
                        triples.append((current,RDF+'rest',following,True));current=following
            elif parse_type:
                raise ValueError(f'Unsupported RDF parseType in publication metadata: {parse_type[:60]!r}.')
            elif len(child):
                if len(child)!=1:raise ValueError('Ambiguous nested RDF property.')
                obj=node_subject(child[0]);triples.append((subject,predicate,obj,True))
                read_properties(obj,child[0],depth+1)
            else:
                triples.append((subject,predicate,(child.text or '').strip(),False))
    for node in root:
        read_properties(node_subject(node),node,0)
    if len(triples) > 150000:
        raise ValueError('The publication notice exceeds the local parsing limit.')
    parent = {}
    def canonical(value):
        p = urlsplit(value)
        if p.hostname == 'publications.europa.eu' and p.scheme in ('http', 'https'):
            return 'http://publications.europa.eu' + p.path
        return value
    def find(value):
        value = canonical(value)
        parent.setdefault(value, value)
        route=[]
        while parent[value] != value:
            route.append(value);value=parent[value]
        for node in route:parent[node]=value
        return value
    for s, p, o, uri in triples:
        if p == OWL + 'sameAs' and uri:
            a, b = find(s), find(o)
            if a != b:
                parent[b] = a
    linked = defaultdict(set)
    incoming = defaultdict(set)
    values = defaultdict(set)
    aliases = defaultdict(set)
    for s, p, o, uri in triples:
        aliases[find(s)].add(s)
        if uri:
            aliases[find(o)].add(o)
            linked[find(s), p].add(find(o))
            incoming[find(o), p].add(find(s))
        else:
            values[find(s), p].add(o)
    target = record['celex']
    anchors = [f'http://publications.europa.eu/resource/celex/{target}']
    anchors += record.get('work_uris', [])
    if record.get('work_uri'):
        anchors.append(record['work_uri'])
    works = {find(a) for a in anchors}
    works |= {s for (s, p), vals in values.items() if p == CDM + 'resource_legal_id_celex' and target in vals}
    # Reject any anchored work that explicitly identifies another document.
    works = {w for w in works if not values[w, CDM+'resource_legal_id_celex'] or target in values[w, CDM+'resource_legal_id_celex']}
    expressions = set()
    for work in works:
        expressions |= linked[work, CDM+'work_has_expression']
    for work in works:expressions |= incoming[work,CDM+'expression_belongs_to_work']
    reverse = {v.upper(): k for k, v in lang3.items()}
    result = {'celex': target, 'at': utc_now(), 'languages': {}, 'established': False,
              'checked_sources': [{'type':'rdf-tree', 'work_anchors':len(works)}]}
    def related(source, forward, backward):
        out = set(linked[source, CDM+forward])
        out |= incoming[source,CDM+backward]
        return out
    for expr in expressions:
        codes = set()
        for language in linked[expr, CDM+'expression_uses_language']:
            for uri in aliases[language] | {language}:
                code = reverse.get(uri.rstrip('/').rsplit('/', 1)[-1].upper())
                if code:
                    codes.add(code)
        for code in codes:
            entry = result['languages'].setdefault(code, {'formats': [], 'items': []})
            for manifestation in related(expr, 'expression_manifested_by_manifestation', 'manifestation_manifests_expression'):
                formats = set(values[manifestation, CDM+'manifestation_type'])
                for uri in linked[manifestation, CDM+'manifestation_type']:
                    formats.add(uri.rstrip('/').rsplit('/', 1)[-1])
                items = related(manifestation, 'manifestation_has_item', 'item_belongs_to_manifestation')
                for fmt in formats or {''}:
                    fmt = fmt.rstrip('/').rsplit('/', 1)[-1].rsplit('#', 1)[-1].lower()
                    if fmt and fmt not in entry['formats']:
                        entry['formats'].append(fmt)
                    for item in items:
                        for url in aliases[item] | {item}:
                            p = urlsplit(url)
                            if p.hostname != 'publications.europa.eu' or not p.path.startswith('/resource/'):
                                continue
                            safe = trusted_url(url, cellar=True)
                            row = {'url': safe, 'format': fmt}
                            if row not in entry['items']:
                                entry['items'].append(row)
    result['established'] = bool(result['languages'])
    return annotate_catalogue(result)
