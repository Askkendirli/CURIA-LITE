"""Keep long research runs from queuing every task and source text at once."""
from __future__ import annotations

from concurrent.futures import FIRST_COMPLETED, wait


def bounded_completed(pool, function, items, *, limit, cancel):
    """Yield (future, input) with at most limit submitted tasks; stop filling on cancellation."""
    iterator=iter(items)
    pending={}
    exhausted=False
    while pending or not exhausted:
        while not exhausted and not cancel.is_set() and len(pending)<limit:
            try:
                item=next(iterator)
            except StopIteration:
                exhausted=True
                break
            pending[pool.submit(function,item)]=item
        if cancel.is_set():
            exhausted=True
            for future in list(pending):
                if future.cancel():pending.pop(future)
        if not pending:break
        done,_=wait(pending,timeout=0.2,return_when=FIRST_COMPLETED)
        for future in done:
            yield future,pending.pop(future)
