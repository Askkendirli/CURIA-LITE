from __future__ import annotations

import argparse
import json
from pathlib import Path

from .common import prepare_console, write_json
from .demo import install_demo
from .keyword_check import run_keyword_check
from .diagnostics import diagnose
from .engine import execute
from .server import serve
from .settings import default_home, load, save
from .store import Store


def main(argv=None):
    prepare_console()
    parser=argparse.ArgumentParser(description='CURIA LITE: find, rank and save relevant case law.')
    parser.add_argument('--home',type=Path,default=default_home(),help='Local data/settings folder, separate from source code.')
    sub=parser.add_subparsers(dest='command')
    sub.add_parser('test-keywords')
    sub.add_parser('test-context')
    p=sub.add_parser('serve');p.add_argument('--port',type=int,default=8765);p.add_argument('--no-browser',action='store_true')
    p=sub.add_parser('doctor');p.add_argument('--models',action='store_true');p.add_argument('--smoke',action='store_true');p.add_argument('--out',type=Path);p.add_argument('--sources',action='store_true');p.add_argument('--source-language',default='en');p.add_argument('--celex',default='62024CJ0313')
    p=sub.add_parser('import');p.add_argument('path',type=Path);p.add_argument('--language',default='')
    p=sub.add_parser('demo')
    p=sub.add_parser('search');p.add_argument('query',type=Path);p.add_argument('--selection',type=Path)
    p=sub.add_parser('settings');p.add_argument('--apply',type=Path)
    args=parser.parse_args(argv)
    try:
        config=load(args.home)
        if args.command in {None,'serve'}:
            serve(args.home,getattr(args,'port',8765),not getattr(args,'no_browser',False));return 0
        if args.command=='test-context':
            from .context_check import run_context_check
            out=run_context_check(args.home,config)
            print(json.dumps(out,ensure_ascii=False,indent=2));return 0 if out['passed'] else 2
        if args.command=='test-keywords':
            out=run_keyword_check(args.home,config)
            print(json.dumps(out,ensure_ascii=False,indent=2));return 0 if out['passed'] else 2
        elif args.command=='doctor':
            out=diagnose(args.home,config,models=args.models,smoke=args.smoke,sources=args.sources,source_language=args.source_language,celex=args.celex)
            if args.out:write_json(args.out,out)
            print(json.dumps(out,ensure_ascii=False,indent=2));return 0 if out['ok'] else 2
        if args.command=='settings':
            if args.apply:config=save(args.home,json.loads(args.apply.read_text('utf-8-sig')))
            print(json.dumps(config,ensure_ascii=False,indent=2));return 0
        if args.command=='demo':
            print(f'{len(install_demo(Store(args.home)))} synthetic demonstrations imported.');return 0
        if args.command=='import':
            out=Store(args.home).import_path(args.path,args.language)
        else:
            query=json.loads(args.query.read_text('utf-8-sig'))
            selection=json.loads(args.selection.read_text('utf-8-sig')) if args.selection else None
            out=execute(args.home,config,query,selection=selection,progress=lambda stage,msg,**kw:print(f'[{stage}] {msg}'))
        print(json.dumps(out,ensure_ascii=False,indent=2))
        return 2 if out.get('failed') or out.get('failures') or out.get('status') in {'failed','partial','cancelled'} else 0
    except Exception as exc:
        print(f'ERROR: {exc}')
        return 2
