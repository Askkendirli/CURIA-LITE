"""Shared status definitions for the local interface and exported research lists."""
from __future__ import annotations

# The collection counters count requested document/language versions. A case may contain several.
EN = {
 'requested':('Requested versions','Document-and-language combinations selected for collection. One case can have several documents or language versions.'),
 'records':('Document records','Distinct document identifiers found for the selected dates and criteria. Language versions are counted separately during collection.'),
 'cached':('Already saved','Requested document versions found in the local archive and reused after their source files were checked.'),
 'downloaded':('Downloaded','Requested versions retrieved and accepted during this run after language, identity and text checks.'),
 'failed':('Needs attention','Requested versions whose retrieval or validation could not be completed. Open the details for the error and retry options.'),
 'unlisted':('Unlisted','The checked official publication records list no full-text file that this tool can read for the requested language version. Other file languages and the check time appear in Publication details. These versions were left out of the analysis.'),
 'missing':('Still to check','Requested versions awaiting a download or publication-availability check. This count decreases as collection proceeds.'),
 'publication_cache_hits':('Publication checks reused','Recent saved publication checks reused for versions whose full text remained unlisted. Retry this search performs a fresh check.'),
 'eligible':('Available for screening','Local document versions that passed the selected metadata criteria and can be searched.'),
 'processed':('Processed','Document versions processed so far, including keyword exclusions and assessments needing attention.'),
 'keyword_candidates':('Keyword matches','Documents satisfying the selected keyword operator and exclusions. Contextual searches assess these candidates.'),
 'keyword_excluded':('Keyword exclusions','Documents that did not satisfy the keyword condition or contained an excluded expression.'),
 'model_calls':('Model calls','Local model requests made in this run, including additional evidence reviews when needed.'),
 'cache_hits':('Assessments reused','Compatible previously saved model answers reused for the same source, query and model settings.'),
 'reviewed_documents':('Additional reviews','Documents receiving a second reading because the first rating and the supplied evidence needed reconciliation.'),
 'displayed':('Displayed cases','Case groups currently shown under the selected relevance threshold. Individual document assessments remain available in the JSON.'),
 'metadata_unresolved':('Needs metadata','Documents that cannot yet be tested against a selected criterion because the required source metadata is missing.'),
 'assessment_issues':('Assessment issues','Documents with an incomplete contextual assessment. Their recorded evidence and errors remain available for review.'),
}
FR = {
 'requested':('Versions demandées','Combinaisons document-langue sélectionnées. Une affaire peut comporter plusieurs documents ou versions.'),
 'records':('Documents repérés','Identifiants de documents distincts trouvés pour les dates et critères sélectionnés.'),
 'cached':('Déjà enregistrées','Versions retrouvées dans les archives locales et réutilisées après vérification des fichiers sources.'),
 'downloaded':('Téléchargées','Versions récupérées et acceptées pendant cette recherche après vérification de leur langue, identité et texte.'),
 'failed':('À vérifier','Versions dont la récupération ou la validation reste incomplète. Les détails indiquent l’erreur et les possibilités de nouvelle tentative.'),
 'unlisted':('Sans fichier répertorié','Les notices officielles consultées ne proposent aucun fichier intégral que cet outil peut lire pour cette version linguistique. Les autres langues disponibles et la date de vérification figurent dans les détails de publication. Ces versions n’ont pas été analysées.'),
 'missing':('Restant à vérifier','Versions en attente de téléchargement ou de vérification de leur disponibilité.'),
 'publication_cache_hits':('Vérifications réutilisées','Vérifications de publication récentes réutilisées pour les versions sans fichier répertorié. Relancer la recherche effectue une nouvelle vérification.'),
 'eligible':('Prêtes pour la recherche','Versions locales satisfaisant les critères de métadonnées sélectionnés.'),
 'processed':('Traitées','Versions déjà traitées, y compris les exclusions par mots-clés et les analyses à vérifier.'),
 'keyword_candidates':('Correspondances lexicales','Documents satisfaisant l’opérateur et les exclusions sélectionnés.'),
 'keyword_excluded':('Exclusions lexicales','Documents ne satisfaisant pas la condition lexicale ou contenant une expression exclue.'),
 'model_calls':('Appels au modèle','Requêtes adressées au modèle local, y compris les relectures supplémentaires.'),
 'cache_hits':('Analyses réutilisées','Réponses enregistrées réutilisées pour une source, une requête et des paramètres compatibles.'),
 'reviewed_documents':('Relectures supplémentaires','Documents relus lorsque la première note et les passages fournis demandaient vérification.'),
 'displayed':('Affaires affichées','Groupes d’affaires affichés selon le seuil de pertinence choisi. Les analyses individuelles restent dans le JSON.'),
 'metadata_unresolved':('Métadonnées manquantes','Documents auxquels un critère ne peut pas encore être appliqué faute de métadonnées.'),
 'assessment_issues':('Analyses à vérifier','Documents dont l’analyse contextuelle est incomplète. Les passages et erreurs restent consultables.'),
}
DE = {
 'requested':('Angeforderte Fassungen','Ausgewählte Kombinationen aus Dokument und Sprache. Eine Rechtssache kann mehrere Dokumente und Fassungen umfassen.'),
 'records':('Gefundene Dokumente','Unterschiedliche Dokumentkennungen für den ausgewählten Zeitraum und die Kriterien.'),
 'cached':('Bereits gespeichert','Fassungen aus dem lokalen Archiv, deren Quelldateien geprüft und wiederverwendet wurden.'),
 'downloaded':('Heruntergeladen','In diesem Lauf abgerufene Fassungen mit geprüfter Sprache, Identität und Textinhalt.'),
 'failed':('Prüfung erforderlich','Fassungen, deren Abruf oder Validierung unvollständig blieb. Einzelheiten nennen Fehler und Möglichkeiten für einen erneuten Versuch.'),
 'unlisted':('Ohne verzeichnete Datei','Die geprüften amtlichen Publikationsdaten enthalten keine vom Tool lesbare Volltextdatei für die angeforderte Sprachfassung. Andere Dateisprachen und der Prüfzeitpunkt stehen in den Publikationsdetails. Diese Fassungen wurden nicht analysiert.'),
 'missing':('Noch zu prüfen','Fassungen, deren Download oder Verfügbarkeitsprüfung noch aussteht.'),
 'publication_cache_hits':('Publikationsprüfungen wiederverwendet','Gespeicherte aktuelle Verfügbarkeitsprüfungen wiederverwendet. Ein erneuter Suchlauf mit Aktualisierung prüft die Angaben erneut.'),
 'eligible':('Zur Prüfung verfügbar','Lokale Fassungen, die die ausgewählten Metadatenkriterien erfüllen.'),
 'processed':('Bearbeitet','Bereits bearbeitete Fassungen, einschließlich ausgeschlossener Treffer und unvollständiger Bewertungen.'),
 'keyword_candidates':('Worttreffer','Dokumente, die den gewählten Suchoperator und die Ausschlüsse erfüllen.'),
 'keyword_excluded':('Durch Wörter ausgeschlossen','Dokumente, die die Wortbedingung verfehlen oder einen ausgeschlossenen Ausdruck enthalten.'),
 'model_calls':('Modellanfragen','Anfragen an das lokale Modell, einschließlich zusätzlicher Evidenzprüfungen.'),
 'cache_hits':('Bewertungen wiederverwendet','Gespeicherte Antworten für dieselbe Quelle, Suchfrage und kompatible Modelleinstellungen.'),
 'reviewed_documents':('Zusätzliche Prüfungen','Dokumente mit einer zweiten Prüfung aufgrund einer unklaren ersten Bewertung.'),
 'displayed':('Angezeigte Rechtssachen','Gruppierte Rechtssachen oberhalb des gewählten Relevanzwerts. Einzelbewertungen bleiben im JSON erhalten.'),
 'metadata_unresolved':('Metadaten fehlen','Dokumente mit fehlenden Metadaten für ein ausgewähltes Kriterium.'),
 'assessment_issues':('Bewertungen zu prüfen','Dokumente mit unvollständiger Kontextbewertung. Evidenz und Fehlermeldungen bleiben verfügbar.'),
}


def definitions():
    return {lang:{key:{'label':label,'description':description} for key,(label,description) in data.items()}
            for lang,data in [('en',EN),('fr',FR),('de',DE)]}


def counts_for(result):
    acq=result.get('acquisition',{});summary=result.get('summary',{})
    failures=result.get('failures',[])
    values={'records':len(result.get('discovery',{}).get('records',[])),
        'requested':acq.get('requested',0),'cached':acq.get('cached',0),'downloaded':acq.get('downloaded',0),
        'failed':sum(f.get('stage') in {'download','metadata','source-validation'} for f in failures),
        'unlisted':len(result.get('unavailable_versions',[])),
        'missing':acq.get('remaining',0), 'publication_cache_hits':acq.get('publication_cache_hits',0),
        'eligible':summary.get('eligible_documents',0),'processed':len(result.get('documents',[])),
        'keyword_candidates':summary.get('keyword_candidates',0),'keyword_excluded':summary.get('keyword_excluded',0),
        'model_calls':summary.get('model_calls',0),'cache_hits':summary.get('cache_hits',0),
        'metadata_unresolved':len(result.get('metadata_unresolved',[])),
        'assessment_issues':sum(f.get('stage')=='assessment' for f in failures),
        'reviewed_documents':sum(bool(d.get('evidence_review',{}).get('performed')) for d in result.get('documents',[]))}
    return [{'key':key,'count':value,'label':EN[key][0],'description':EN[key][1]} for key,value in values.items()]
