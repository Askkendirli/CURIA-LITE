"""Deterministic keyword operators shared by API, screening, exports and the UI preview."""
from __future__ import annotations

import bisect
import re
import unicodedata
from dataclasses import dataclass

MATCH_VERSION = 2
OPERATORS = {'phrase': ('Exact phrase', 'Enter one phrase, such as "language version". A document matches when those words appear next to each other in that order. Capitalisation and line breaks are ignored.'), 'any_words': ('Any word · OR', 'Enter words separated by spaces. Example input: language version. This searches for "language" or "version"; either word is enough, and documents containing both also match. Put quotation marks around a phrase to keep its words together.'), 'all_words': ('All words · AND', 'Enter words separated by spaces. Example input: language version. This requires both "language" and "version" in the same document. They may be in different sentences and in any order.'), 'all_phrases': ('All phrases', 'Separate complete phrases with a semicolon (;). Example: language version; legal certainty. A document must contain both the complete phrase "language version" and the complete phrase "legal certainty". The two phrases may occur in different paragraphs.'), 'any_phrases': ('Any phrase', 'Separate complete phrases with a semicolon (;). Example: language version; legal certainty. A document matches if it contains the complete phrase "language version", the complete phrase "legal certainty", or both.'), 'near': ('Nearby words · NEAR', 'Enter two words or two quoted phrases. Example: "language" and "version", with distance 5, can appear in either order with at most five words between them, within one paragraph.')}

LEGACY = {'all': 'all_phrases', 'any': 'any_phrases'}


def normalize(text: str) -> str:
    text=unicodedata.normalize('NFKC',text).casefold()
    text=text.translate(str.maketrans({'’':"'",'‐':'-','‑':'-','–':'-','—':'-','\u00ad':'','\u200b':'','\ufeff':''}))
    return re.sub(r'\s+',' ',text).strip()


def normalize_offsets(text: str):
    """Maintain original offsets when folding case, typography and whitespace."""
    chars, starts, ends = [], [], []
    translate = str.maketrans({'’': "'", '‐': '-', '‑': '-', '–': '-', '—': '-'})
    i = 0
    while i < len(text):
        j = i + 1
        while j < len(text) and unicodedata.combining(text[j]):
            j += 1
        folded = unicodedata.normalize('NFKC', text[i:j]).casefold().translate(translate)
        for c in folded:
            if c in '\u00ad\u200b\ufeff':
                continue
            if c.isspace():
                if not chars:
                    continue
                if chars[-1] == ' ':
                    ends[-1] = j
                    continue
                c = ' '
            chars.append(c); starts.append(i); ends.append(j)
        i = j
    if chars and chars[-1] == ' ':
        chars.pop(); starts.pop(); ends.pop()
    return ''.join(chars), starts, ends


def unquote(value):
    value = value.strip().replace('“', '"').replace('”', '"')
    if value.startswith('"') and value.endswith('"') and len(value) > 1:
        value = value[1:-1].strip()
    if '"' in value:
        raise ValueError('Close each quoted expression. Use ; to separate phrases.')
    return value


def entries(value):
    if isinstance(value, str):
        # Semicolons inside a quoted phrase stay within that phrase.
        pieces = re.split(r';(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)', value.replace('“','"').replace('”','"'))
    elif isinstance(value, list) and all(isinstance(v, str) for v in value):
        pieces = value
    else:
        raise ValueError('Enter keywords as text or a list of expressions.')
    if len(pieces) > 30 or any(len(x) > 250 for x in pieces):
        raise ValueError('Use up to 30 expressions, each at most 250 characters.')
    return [x.strip() for x in pieces if x.strip()]


def units_for(keywords, mode):
    mode = LEGACY.get(mode, mode)
    if mode not in OPERATORS:
        raise ValueError('Choose an available keyword operator.')
    values = entries(keywords)
    if mode == 'phrase' and len(values) > 1:
        raise ValueError('Exact phrase accepts one expression. Choose All phrases or Any phrase to use several expressions separated with ;.')
    units = []
    if mode in {'any_words', 'all_words', 'near'}:
        for value in values:
            value = value.replace('“','"').replace('”','"')
            for match in re.finditer(r'"([^"\n]+)"|([^\s;]+)', value):
                item = match[1] if match[1] is not None else match[2]
                if '"' in item:
                    raise ValueError('Close the double quotation marks around the expression.')
                units.append(item)
    else:
        units = [unquote(v) for v in values]
    unique = {}
    for u in units:
        n = normalize(u)
        if n: unique.setdefault(n, u)
    units = list(unique.values())
    if len(units) > 30:
        raise ValueError('Use up to 30 search words or expressions.')
    if mode == 'near' and values and len(units) != 2:
        raise ValueError('NEAR requires two different words or quoted expressions.')
    return units


def pattern_for(unit):
    n = normalize(unit)
    if not n: raise ValueError('A search expression must contain visible text.')
    # Boundaries apply to alphabetic/numeric endings, while punctuation can be searched literally.
    left = r'(?<!\w)' if re.match(r'\w', n[0]) else ''
    right = r'(?!\w)' if re.match(r'\w', n[-1]) else ''
    return re.compile(left + re.escape(n).replace(r'\ ', r' +') + right)


@dataclass
class KeywordPlan:
    mode: str
    units: list[str]
    excluded: list[str]
    distance: int = 5

    @classmethod
    def create(cls, keywords, mode='phrase', exclude=None, distance=5):
        mode = LEGACY.get(mode, mode)
        if type(distance) is not int or not 0 <= distance <= 100:
            raise ValueError('The NEAR distance must be between 0 and 100 intervening words.')
        positive = units_for(keywords, mode)
        negative = units_for(exclude or [], 'any_phrases')
        return cls(mode, positive, negative, distance)

    def describe(self):
        return {'version':MATCH_VERSION, 'operator':self.mode, 'label':OPERATORS[self.mode][0],
                'units':self.units, 'exclude':self.excluded, 'near_distance':self.distance if self.mode=='near' else None,
                'whole_words':True, 'case_sensitive':False, 'translation':False,
                'description':OPERATORS[self.mode][1]}

    def match(self, text):
        positive = [pattern_for(x) for x in self.units]
        negative = [pattern_for(x) for x in self.excluded]
        found, negfound, evidence, counts = set(), set(), [], [0] * len(positive)
        near_count = 0
        for index, block in enumerate(re.split(r'\n\s*\n', text), 1):
            if not block.strip(): continue
            normal = normalize(block)
            starts = ends = None
            locations = [list(p.finditer(normal)) for p in positive]
            for i, matches in enumerate(locations):
                if matches: found.add(i)
                counts[i] += len(matches)
            for i,p in enumerate(negative):
                if p.search(normal): negfound.add(i)
            def add(start, end, hits):
                nonlocal starts,ends
                if len(evidence) >= 20: return
                if starts is None:
                    mapped, starts, ends = normalize_offsets(block)
                    if mapped != normal:raise ValueError('The source normalization could not preserve evidence offsets.')
                a,b = starts[start], ends[end-1]
                before,after = max(0,a-130), min(len(block),b+180)
                excerpt=block[before:after]
                evidence.append({'block':index, 'text':excerpt, 'matched_text':block[a:b],
                                 'start':a-before, 'end':b-before, 'units':hits})
            if self.mode == 'near' and len(locations) == 2:
                bstart=[m.start() for m in locations[1]];bend=[m.end() for m in locations[1]]
                for a in locations[0]:
                    positions={bisect.bisect_left(bstart,a.end()), bisect.bisect_right(bend,a.start())-1}
                    for j in sorted(positions):
                        if not 0 <= j < len(locations[1]): continue
                        b=locations[1][j]
                        if a.start() < b.end() and b.start() < a.end(): continue
                        left,right=(a,b) if a.start()<b.start() else (b,a)
                        gap=len(re.findall(r'\w+',normal[left.end():right.start()]))
                        if gap <= self.distance:
                            near_count += 1
                            add(left.start(),right.end(),self.units)
                            break
            else:
                for i,matches in enumerate(locations):
                    for m in matches[:3]: add(m.start(),m.end(),[self.units[i]])
        if not self.units: qualified=True
        elif self.mode in {'any_words','any_phrases'}: qualified=bool(found)
        elif self.mode == 'near': qualified=near_count>0
        else: qualified=len(found)==len(self.units)
        return {'qualified':qualified and not negfound, 'positive_satisfied':qualified,
                'operator':self.mode, 'units':self.units,'hits':[x for i,x in enumerate(self.units) if i in found],
                'counts':dict(zip(self.units,counts)), 'occurrences':near_count if self.mode=='near' else sum(counts),
                'excluded_by':[x for i,x in enumerate(self.excluded) if i in negfound], 'matches':evidence,
                'matching_version':MATCH_VERSION}
