"""Local, list-only EU case-law discovery and relevance screening."""
__version__ = '0.1.5'
