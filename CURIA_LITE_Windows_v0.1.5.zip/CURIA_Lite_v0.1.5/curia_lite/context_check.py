"""Twelve brief, artificial examples for checking a locally installed classifier."""
from __future__ import annotations

from pathlib import Path
import time
import threading
from . import __version__
from .common import utc_now, write_json
from .query import Query
from .screening import Ollama, request_messages, valid_classification

EXAMPLES = [
    {'name':'Court refuses recovery','context':'Cases where the court refused recovery of aid', 'kind':'judgment',
     'text':'31 The Court holds that the aid may not be recovered from the beneficiary because the authorised scheme created protected legitimate expectations.',
     'expected':[4,5], 'target':'deciding_court','actor':'deciding_court','support':'direct','category':'other_relevance'},
    {'name':'A request is not a judicial outcome','context':'Cases where the court annulled a decision', 'kind':'judgment',
     'text':'31 The applicant argues that the decision should be annulled. The Court has not yet examined that request in the supplied passage.',
     'expected':[1,2], 'target':'deciding_court','actor':'party','support':'background','category':'party_argument'},
    {'name':'Party request matches a party question','context':'Cases where an applicant requested annulment of a decision', 'kind':'judgment',
     'text':'31 The applicant argues that the decision should be annulled because the reasons given were insufficient.',
     'expected':[4,5], 'target':'party','actor':'party','support':'direct','category':'party_argument'},
    {'name':'Opposite outcome','context':'Cases where the court gave the rule retroactive effect', 'kind':'judgment',
     'text':'31 The Court holds that this rule applies only prospectively. Retroactive application is expressly excluded.',
     'expected':[1,2], 'target':'deciding_court','actor':'deciding_court','support':'contradicted','category':'other_relevance'},
    {'name':'Broad topic includes relevant facts','context':'Disputes about aid granted to small businesses', 'kind':'judgment',
     'text':'31 The dispute concerns the recovery of a grant paid to a small business under a national aid scheme. The parties disagree about the eligibility conditions.',
     'expected':[4,5], 'target':'any','actor':'unknown','support':'direct','category':'other_relevance'},
    {'name':'Agreement across versions is a comparison','context':'Judgments that compare language versions of a rule', 'kind':'judgment',
     'text':'31 It should be noted that the French version uses « délai » and the English version uses “time limit”. The Court finds that both formulations establish the same deadline.',
     'expected':[4,5], 'target':'deciding_court','actor':'deciding_court','support':'direct','category':'applied_current_comparison'},
    {'name':'Single-version correction','context':'Cases where the court compared language versions', 'kind':'judgment',
     'text':'31 The language-of-case version contains an obvious error: “applicant” should read “Commission”, as the surrounding context shows. No other language version is examined in this passage.',
     'expected':[1,2], 'target':'deciding_court','actor':'deciding_court','support':'background','category':'other_relevance'},
    {'name':'Advocate General matches an AG question','context':'Opinions where the Advocate General proposes annulment', 'kind':'opinion',
     'text':'31 The Advocate General proposes that the contested decision be annulled because the institution failed to provide sufficient reasons.',
     'expected':[4,5], 'target':'advocate_general','actor':'advocate_general','support':'direct','category':'direct_requested_relationship'},
    {'name':'A grammatical comparison supports interpretation','context':'Judgments comparing singular and plural language versions','kind':'judgment',
     'text':'31 As regards the wording of the rule, the Court notes that all language versions except Dutch use the plural. The plural indicates that the action must concern several consumers.',
     'expected':[4,5],'target':'deciding_court','actor':'deciding_court','support':'direct','category':'applied_current_comparison'},
    {'name':'An article difference is concrete evidence','context':'Decisions comparing wording in different language versions','kind':'judgment',
     'text':'31 It should be noted that the Polish version says “Member State”, while the English, French and German language versions use an indefinite article. The Court therefore reads the rule as referring to any Member State.',
     'expected':[4,5],'target':'deciding_court','actor':'deciding_court','support':'direct','category':'applied_current_comparison'},
    {'name':'The deciding court develops a referred question','context':'Cases in which the deciding court compared language versions','kind':'judgment',
     'text':'31 The referring court asks about different language versions. The Court finds that the French wording uses “or”, whereas the English and German versions use “and”, and resolves the difference through the structure of the provision.',
     'expected':[4,5],'target':'deciding_court','actor':'deciding_court','support':'direct','category':'applied_current_comparison'},
    {'name':'The current court compares an earlier text','context':'Cases where the court compares language versions of an earlier judgment','kind':'judgment',
     'text':'31 The General Court compares the French and English versions of an earlier judgment. The French wording says “mass collection”; the English wording says “bulk collection”. The General Court explains why the latter conveys the intended distinction more accurately.',
     'expected':[4,5],'target':'deciding_court','actor':'deciding_court','support':'direct','category':'applied_current_comparison'},

]


def run_context_check(home,config,client=None,cancel=None):
    cancel=cancel or threading.Event()
    model=client or Ollama(config,cancel=cancel)
    output={'at':utc_now(),'release':__version__,'source':'artificial acceptance examples',
            'model':config['model'],'weight_training':False,'source_requests':0,'model_calls':0,'checks':[]}
    destination=Path(home)/'diagnostics'/'context-check.json'
    began=time.monotonic()
    if 'en' not in config['native_languages']:
        output.update(passed=False,status='test-language-unavailable',error='The twelve built-in examples are in English. Enable English for a compatible model before running this check.')
        write_json(destination,output);return output
    try:
        output['model_digest']=model.ready()
    except Exception as exc:
        output.update(passed=False,status='model-unavailable',error=str(exc),elapsed_seconds=round(time.monotonic()-began,3))
        write_json(destination,output);return output
    for example in EXAMPLES:
        if cancel.is_set():
            output['cancelled']=True;break
        query=Query.parse({'source_mode':'local','query_language':'en','languages':['en'],
                           'context':example['context'],'min_score':1},config)
        snippets=[{'id':1,'paragraph':'31','text':example['text']}]
        meta={'case_id':'SYNTHETIC ACCEPTANCE EXAMPLE','doc_type':example['kind'],'retrieval_language':'en'}
        row={'name':example['name'],'context':example['context'],'expected_range':example['expected'],'input_passages':snippets}
        try:
            output['model_calls']+=1
            raw,metrics=model.chat(request_messages(meta,query,snippets))
            assessed=valid_classification(raw,snippets,meta,query,strict=True)
            row.update(actual_score=assessed['score'],passed=example['expected'][0]<=assessed['score']<=example['expected'][1],
                       model_answer=raw,assessment=assessed,metrics=metrics)
        except Exception as exc:
            row.update(passed=False,error=str(exc));output['checks'].append(row)
            # A transport/response failure stops this optional diagnostic promptly.
            output['stopped_early']=True;write_json(destination,output);break
        output['checks'].append(row);write_json(destination,output)
    output.update(passed=len(output['checks'])==len(EXAMPLES) and all(c['passed'] for c in output['checks']),
                  elapsed_seconds=round(time.monotonic()-began,3))
    output['status']='cancelled' if output.get('cancelled') or cancel.is_set() else ('passed' if output['passed'] else 'needs-review')
    write_json(destination,output);return output
