from __future__ import annotations

import json
import re
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlsplit

from .common import atomic_write, digest, utc_now, write_json, workspace_path
from .extractor import source_content, CELEX, html_content, parse_metadata, EXTRACTOR_VERSION

SIDE_FIELDS = {'case_name','judge_rapporteur','advocate_general','formation','language_of_case',
               'original_language','procedure','subject_matter','referring_country','case_status',
               'national_context','international_context','cited_provisions','ecli','delivery_date','is_demo'}


class Store:
    def __init__(self, home: Path):
        self.home = Path(home).resolve()
        self.home.mkdir(parents=True, exist_ok=True)
        self.db = self.home / 'lite.sqlite3'
        self.lock = threading.RLock()
        with self.connect() as con:
            version = con.execute('PRAGMA user_version').fetchone()[0]
            if version not in {0,1}:
                raise ValueError('The archive schema is incompatible. A separate LITE workspace is required.')
            con.executescript('''
            CREATE TABLE IF NOT EXISTS documents (
                doc_id TEXT PRIMARY KEY, celex TEXT, language TEXT NOT NULL,
                raw_hash TEXT NOT NULL, text_hash TEXT NOT NULL, metadata TEXT NOT NULL,
                source_path TEXT NOT NULL, text_path TEXT NOT NULL, text TEXT NOT NULL,
                imported_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS lookup_document ON documents(celex,language);
            CREATE TABLE IF NOT EXISTS cache (key TEXT PRIMARY KEY, data TEXT NOT NULL, sha TEXT NOT NULL);
            PRAGMA user_version=1;
            ''')

    @contextmanager
    def connect(self):
        con = sqlite3.connect(self.db, timeout=20)
        con.row_factory = sqlite3.Row
        try:
            yield con
            con.commit()
        except BaseException:
            con.rollback()
            raise
        finally:
            con.close()

    def ingest(self, raw: bytes, *, language: str = '', celex: str = '', source_url: str = '',
               resolved_url: str = '', side: dict | None = None, filename: str = '') -> dict:
        if not raw:
            raise ValueError('Empty source file.')
        # UTF-8 is expected for saved official HTML; no lossy decoding is used.
        text, detected = source_content(raw)
        language = language.strip().lower() or detected
        if not detected or not language or detected != language:
            raise ValueError(f'Body language must be identified and agree with the selection (detected={detected}, requested={language}).')
        if not celex:
            m = re.search(r'6\d{4}(?:CJ|CC|CO|TJ|TO|FJ|FO)\d{4}', filename, re.I)
            celex = m[0].upper() if m else ''
        meta = parse_metadata(text, celex_hint=celex, retrieval_language=language)
        side = side or {}
        if not isinstance(side, dict):
            raise ValueError('Supplementary metadata must be an object.')
        for key in SIDE_FIELDS:
            value = side.get(key)
            if value in (None,'',[]):
                continue
            if key == 'is_demo':
                if type(value) is not bool:
                    raise ValueError('is_demo must be Boolean.')
            elif not isinstance(value, (str,list)):
                raise ValueError(f'Invalid supplementary metadata: {key}')
            if key in {'ecli','delivery_date','language_of_case','original_language'} and meta.get(key) and meta[key] != value:
                raise ValueError(f'Supplementary {key} conflicts with the source header.')
            if not meta.get(key) or (key == 'case_name' and meta[key] == meta['case_id']):
                meta[key] = value
        if meta.get('delivery_date'):
            from datetime import date
            date.fromisoformat(meta['delivery_date'])
        meta['court'] = celex[5] if celex else (meta['case_numbers'][0][0] if meta['case_numbers'][0][0] in 'CTF' else 'C')
        host = urlsplit(resolved_url or source_url).hostname or ''
        meta['provider'] = {'publications.europa.eu':'cellar','eur-lex.europa.eu':'eurlex',
                            'curia.europa.eu':'curia','juris.curia.europa.eu':'curia',
                            'infocuria.curia.europa.eu':'curia'}.get(host,'local-import')
        meta.update({'source_url':source_url, 'resolved_url':resolved_url or source_url,
                     'language_validation':'document-heading-or-content-language',
                     'supplementary_metadata':side, 'is_demo':bool(side.get('is_demo',False))})
        if meta['doc_type'] == 'opinion':
            original = meta.get('original_language')
            meta['authority_status'] = ('original-opinion' if language == original else 'translated-opinion') if original else 'original-language-unconfirmed'
        else:
            loc = meta.get('language_of_case')
            meta['authority_status'] = ('language-of-case-version' if language == loc else 'published-translation') if loc else 'unconfirmed'
        raw_hash, text_hash = digest(raw), digest(text)
        doc_id = digest(raw_hash + ':' + language)[:24]
        extension='pdf' if raw.lstrip().startswith(b'%PDF-') else 'html'
        meta['source_format']=extension
        source_path, text_path = f'raw/{doc_id}.{extension}', f'text/{doc_id}.txt'
        with self.lock:
            with self.connect() as con:
                prior = con.execute('SELECT metadata FROM documents WHERE doc_id=?',(doc_id,)).fetchone()
                if prior:
                    old = json.loads(prior['metadata'])
                    for key,value in old.items():
                        if not meta.get(key):
                            meta[key] = value
                meta.update({'doc_id':doc_id, 'sha256':raw_hash, 'text_sha256':text_hash,
                             'source_path':source_path,'text_path':text_path})
                atomic_write(self.home/source_path, raw)
                atomic_write(self.home/text_path, text)
                con.execute('INSERT OR REPLACE INTO documents VALUES (?,?,?,?,?,?,?,?,?,?)',
                    (doc_id,meta['celex'],language,raw_hash,text_hash,json.dumps(meta,ensure_ascii=False),source_path,text_path,text,utc_now()))
        return meta

    def import_path(self, path: Path, language: str = '') -> dict:
        files = sorted(p for p in path.rglob('*') if p.is_file() and p.suffix.lower() in {'.html','.htm','.xhtml','.pdf'}) if path.is_dir() else [path]
        result = {'imported':[], 'failed':[]}
        for p in files:
            try:
                sidepath = p.with_suffix(p.suffix+'.metadata.json')
                side = json.loads(sidepath.read_text('utf-8-sig')) if sidepath.exists() else {}
                result['imported'].append(self.ingest(p.read_bytes(),language=language,
                    celex=side.get('celex',''),side=side,filename=p.name))
            except Exception as exc:
                result['failed'].append({'file':str(p),'error':str(exc)})
        return result

    def documents(self, include_demo=False) -> list[dict]:
        with self.connect() as con:
            rows = con.execute('SELECT metadata FROM documents ORDER BY imported_at,doc_id').fetchall()
        out = [json.loads(r['metadata']) for r in rows]
        return [r for r in out if include_demo or not r.get('is_demo')]

    def read(self, doc_id: str, verify=True) -> tuple[dict,str]:
        with self.connect() as con:
            row = con.execute('SELECT * FROM documents WHERE doc_id=?',(doc_id,)).fetchone()
        if not row:
            raise ValueError('Document not present locally.')
        if verify:
            raw = workspace_path(self.home,row['source_path']).read_bytes()
            text = workspace_path(self.home,row['text_path']).read_text('utf-8')
            if digest(raw) != row['raw_hash'] or digest(text) != row['text_hash'] or row['text'] != text:
                raise ValueError('Local source integrity check failed. Re-import or reacquire the source.')
        metadata=json.loads(row['metadata'])
        if metadata.get('extractor_version',1)!=EXTRACTOR_VERSION:
            # Original source bytes are preserved; only derived text and metadata are refreshed.
            raw=workspace_path(self.home,row['source_path']).read_bytes()
            if digest(raw)!=row['raw_hash']:
                raise ValueError('The saved source has changed. Re-import or download the document again.')
            metadata=self.ingest(raw,language=row['language'],celex=row['celex'] or '',
                source_url=metadata.get('source_url',''),resolved_url=metadata.get('resolved_url',''),
                side=metadata.get('supplementary_metadata') or {})
            with self.connect() as con:
                updated=con.execute('SELECT text FROM documents WHERE doc_id=?',(metadata['doc_id'],)).fetchone()
            return metadata,updated['text']
        return metadata,row['text']

    def lookup(self, celex: str, lang: str) -> dict | None:
        with self.connect() as con:
            rows = con.execute('SELECT doc_id FROM documents WHERE celex=? AND language=? ORDER BY imported_at DESC',(celex,lang)).fetchall()
        for row in rows:
            try:
                return self.read(row['doc_id'])[0]
            except (OSError,ValueError):
                pass
        return None

    def cached(self, key: str):
        with self.connect() as con:
            row = con.execute('SELECT data,sha FROM cache WHERE key=?',(key,)).fetchone()
        if row and digest(row['data']) == row['sha']:
            try:
                return json.loads(row['data'])
            except ValueError:
                pass
        return None

    def cached_objects(self, prefix: str):
        with self.connect() as con:
            rows=con.execute('SELECT key FROM cache WHERE substr(key,1,?)=?',(len(prefix),prefix)).fetchall()
        return [obj for row in rows if isinstance((obj:=self.cached(row['key'])),dict)]

    def cache(self, key: str, data):
        s = json.dumps(data,ensure_ascii=False,sort_keys=True)
        with self.lock, self.connect() as con:
            con.execute('INSERT OR REPLACE INTO cache VALUES (?,?,?)',(key,s,digest(s)))

    def stats(self):
        docs = self.documents(True)
        return {'documents':len(docs),'real_documents':sum(not d.get('is_demo') for d in docs),
                'languages':sorted({d['retrieval_language'] for d in docs}),
                'dates':sorted({d.get('delivery_date') for d in docs if d.get('delivery_date')}),
                'workspace':str(self.home)}
