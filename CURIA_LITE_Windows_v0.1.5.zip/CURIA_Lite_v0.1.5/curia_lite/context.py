"""Query-wide evidence requirements shared by all contextual research questions."""
from __future__ import annotations

import re
from .common import normalise_search

ACTORS = ['any','deciding_court','referring_court','party','advocate_general','public_authority','legislature','earlier_court','unknown']
SUPPORT = ['direct','partial','background','contradicted','absent']
ACTOR_LABELS = {'any':'any relevant participant','deciding_court':'the deciding court','referring_court':'the referring court',
               'party':'a party to the proceedings','advocate_general':'the Advocate General',
               'public_authority':'a public authority','legislature':'the legislature','earlier_court':'a court in an earlier cited case','unknown':'the actor described in the context'}
LANGUAGES = re.compile(r'language.{0,15}versions?|linguistic.{0,10}versions?|versions? linguistiques?|sprachfass|sprachversion|taalversi|version[ie] linguistic|versiones? lingüístic|vers[õã]es? linguístic|(?:english|french|german|dutch|spanish|italian).{0,25}(?:wording|text|translations?)',re.I)
COMPARISON = re.compile(r'compar|contrast|cross.check|cross.check|side.by.side|read.{0,20}together|reconcil|divergen|agree.{0,20}versions|versions?.{0,20}agree|differ.{0,25}(?:versions|wording)|multilingual.{0,20}interpret|vergleich|verglich|vergel|sprachvergleich|confront|raffront|contrast|diferen|linguistic.{0,12}discrep',re.I)
NEGATIVE_COMPARISON = re.compile(r'(?:not|never|without|failed to|declined to|refused to|didn.t|sans|jamais|pas|nicht|keine|no|non|sin|sem|não|niet).{0,30}(?:compar|contrast|vergleich|vergel|raffront)',re.I)
# These patterns are display hints. The whole original context is supplied to the model.
ACTOR_HINTS = {
 'advocate_general':r'advocate.general|avocat.general|général.{0,15}avocat|generalanw|avvocato generale|abogado general|advogado.geral|advocaat.generaal',
 'referring_court':r'referring court|national court|juridiction de renvoi|nationalen? gericht|vorlegende|giudice del rinvio|órgano jurisdiccional remitente|tribunal de reenvio|verwijzende rechter',
 'party':r'\b(?:parties|party|applicant|appellants?|defendants?|litigants?|requérant\w*|kläger\w*|demandante\w*|ricorrente\w*)\b|commission.{0,30}(?:argu|submi|conten|claim)|(?:arguments?|claims?|submissions?).{0,20}(?:commission|government)',
 'deciding_court':r'\b(?:judgments?|judgements?|court|courts|judges|cjeu|ecj|cour|gerichtshof|gericht|corte|tribunal|hof)\b',
 'legislature':r'\b(?:legislature|legislator|legislators|législateur|gesetzgeber|legislatore|legislador|wetgever)\b',
 'public_authority':r'\b(?:authorities|authority|ministry|customs office|administration|autorité|behörde|autoridad|autoridade)\b',
}


def analyse_context(context='',preset='general',actor_scope='auto'):
    text=normalise_search(context)
    hint='unknown';origin='model-interpretation'
    if actor_scope!='auto':
        hint=actor_scope;origin='selected-actor'
    else:
        # Referring courts and Advocates General must not be mistaken for the deciding court.
        candidates=[]
        for actor,pattern in ACTOR_HINTS.items():
            m=re.search(pattern,text,re.I)
            if m:candidates.append((m.start(),list(ACTOR_HINTS).index(actor),actor))
        if candidates:
            candidates.sort();hint=candidates[0][2];origin='context-wording'
        elif text:
            hint='any';origin='broad-context'
    if preset=='court_language_comparison':hint='deciding_court';origin='selected-preset'
    language_topic=bool(LANGUAGES.search(text)) or preset=='court_language_comparison'
    comparing=bool(COMPARISON.search(text)) or preset=='court_language_comparison'
    negated=bool(NEGATIVE_COMPARISON.search(text)) and preset!='court_language_comparison'
    specific=language_topic and comparing and not negated and hint=='deciding_court'
    return {'version':1,'context':context,'actor_scope':actor_scope,'actor_hint':hint,'origin':origin,
            'topic':'language_versions' if language_topic else 'from-context',
            'specific_language_comparison':specific,'negated_comparison_request':negated,
            'checks':['requested subject','requested action or relationship','responsible actor','outcome and negation','conditions stated in the question'],
            'preview':('Evidence will be checked against the subject, action, outcome and conditions in this context.' +
                       (' The requested actor is '+ACTOR_LABELS[hint]+'.' if hint not in {'any','unknown'} else ''))}


def frame_for(query):
    return analyse_context(query.context,query.preset,getattr(query,'actor_scope','auto'))


def source_actor(text):
    """Return only explicit textual role indicators; uncertain prose stays unresolved."""
    s=re.sub(r'^\s*\d+[.\s]+','',normalise_search(text))
    if re.search(r'(?:the (?:general )?court (?:adopts|endorses|agrees(?: with)?|accepts|finds|holds)|la cour (?:retient|approuve|juge|fait sienne))',s):return 'deciding_court'
    if re.search(r'^(?:.{0,55})?(?:referring court|national court|juridiction de renvoi|vorlegende.{0,14}gericht)|^as observed by that court',s):return 'referring_court'
    if re.search(r'^.{0,70}(?:applicant|appellant|defendant|commission|government|requérant|kommission|kläger|ricorrente|demandante).{0,90}(?:argues|submits|contends|claims|contests|maintains|informed|reported|pointed out|stated|soutient|fait valoir|macht geltend|sostiene|alega)',s):return 'party'
    if re.search(r'^.{0,60}(?:advocate.general|avocat.general|generalanwalt).{0,60}(?:proposes|considers|argues|suggests|concludes|propose|estime|considère|schlägt)',s):return 'advocate_general'
    if re.search(r'^.{0,60}(?:legislature|legislator|législateur|gesetzgeber).{0,60}(?:adopt|amend|replace|provid|adopté|modifi)',s):return 'legislature'
    if re.search(r'^.{0,40}(?:the (?:general )?court|la cour|le tribunal|il ressort|it (?:must|should) be (?:stated|noted)|it is apparent from)',s):return 'deciding_court'
    return 'unknown'


def general_guard(answer,snippets,meta,query):
    """Check actor compatibility and evidence support for every contextual query."""
    out=dict(answer);frame=frame_for(query)
    selected=[p for p in snippets if p['id'] in answer.get('evidence',[])]
    target=frame['actor_hint']
    if frame['actor_scope']=='auto' and query.preset=='general':
        target=answer.get('target_actor',target)
    target_unresolved=target=='unknown'
    if target=='unknown':target=frame['actor_hint']
    if frame['actor_scope']=='any':target='any'
    observed=answer.get('evidence_actor','unknown')
    explicit=[{'id':p['id'],'actor':source_actor(p.get('text',''))} for p in selected]
    roles={x['actor'] for x in explicit}-{ 'unknown' }
    # An Opinion reports the AG's position unless it clearly quotes a different named actor.
    if meta.get('doc_type')=='opinion' and observed=='deciding_court' and not any(x['actor']=='deciding_court' for x in explicit):observed='advocate_general'
    if len(roles)==1 and 'deciding_court' not in roles and explicit and all(x['actor']!='unknown' for x in explicit):
        observed=next(iter(roles))
    if answer.get('category')=='quoted_precedent_only':observed='earlier_court'
    support=answer.get('support','direct' if answer.get('score',1)>=4 else 'partial')
    score=answer['score'];reason=answer['reason'];adjustments=list(answer.get('guard_adjustments',[]))
    ceiling={'direct':5,'partial':3,'background':2,'contradicted':1,'absent':1}[support]
    if target_unresolved and 'support' in answer and score>3:
        ceiling=min(ceiling,3);reason='The requested actor needs clarification; select an actor or clarify the context.';adjustments.append(reason)
    if target not in {'any','unknown'} and observed not in {'unknown',target}:
        ceiling=min(ceiling,3 if observed=='referring_court' else 2)
        msg='The cited evidence concerns '+ACTOR_LABELS[observed]+'. Evidence for '+ACTOR_LABELS[target]+' is still needed.'
        if score>ceiling:adjustments.append(msg);reason=msg
    elif target not in {'any','unknown'} and observed=='unknown' and 'support' in answer:
        ceiling=min(ceiling,3)
        if score>ceiling:
            reason='The cited passage leaves the responsible actor unclear.';adjustments.append(reason)
    if score>ceiling:
        if reason==answer['reason']:
            reason={'partial':'The cited passages support part of the requested relationship; the remaining conditions need review.',
                    'background':'The passages provide background on the topic; the requested event or relationship is not established.',
                    'contradicted':'The cited material contradicts the event or outcome requested in this context.',
                    'absent':'The supplied passages do not establish the requested relationship.'}.get(support,reason)
            adjustments.append(reason)
        score=ceiling
    if score==3 and ceiling>=4 and support=='direct' and 'support' in answer and selected and observed not in {'unknown','any'} and not adjustments:
        score=4;reason='The cited evidence directly supports the requested actor and relationship. '+reason
        adjustments.append('Direct support is displayed as High under the shared relevance scale.')
    out.update(score=score,reason=reason,context_requirements=frame,context_checks={'target_actor':target,'evidence_actor':observed,'support':support,'source_roles':explicit})
    if score!=answer['score'] or adjustments!=answer.get('guard_adjustments',[]):
        out.update(model_score=answer.get('model_score',answer['score']),model_category=answer.get('model_category',answer['category']),
                   model_reason=answer.get('model_reason',answer['reason']),guard_adjustments=list(dict.fromkeys(adjustments)))
    return out
