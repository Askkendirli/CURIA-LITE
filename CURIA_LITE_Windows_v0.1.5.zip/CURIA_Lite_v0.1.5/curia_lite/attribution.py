"""Conservative passage-role checks for a court-language-comparison research question."""
from __future__ import annotations
import re
from .common import normalise_search


def comparison_focus(context='', preset='general'):
    from .context import analyse_context
    frame=analyse_context(context,preset)
    return frame['origin'] if frame['specific_language_comparison'] else ''


LANGUAGE_CUE=re.compile(r'language.{0,16}version|linguistic.{0,8}version|versions? linguistiques?|sprachfass|taalversi|version[ie] linguistic|versiones? lingüístic|vers[õã]es? linguístic|\b(?:english|french|german|dutch|italian|spanish|polish|finnish|swedish|greek)\b.{0,35}\b(?:word|term|version|use|meaning)',re.I)
PARTY=re.compile(r'^.{0,70}\b(?:commission|applicant|defendant|government|appellant|requérant|requérante|gouvernement|kommission|kläger|ricorrente|demandante)\b.{0,110}\b(?:contests?|submits?|argues?|contends?|maintains?|informed|reported|pointed out|stated|soutient|fait valoir|conteste|estime|trägt vor|macht geltend|sostiene|alega)\b',re.I|re.S)
REFERRING=re.compile(r'^.{0,90}(?:referring court.{0,65}(?:points? out|observes?|considers?|asks?|notes?)|as observed by that court|juridiction de renvoi.{0,70}(?:relève|observe|indique)|vorlegende.{0,12}gericht)',re.I|re.S)
PRINCIPLE=re.compile(r'(?:settled case.law|case.law.{0,20}(?:settled|repeatedly)|jurisprudence constante|st[aä]ndig.{0,12}rechtsprechung)',re.I)
CURRENT=re.compile(r'(?:it (?:is (?:apparent|clear)|must be stated)|it should be (?:noted|observed)|the (?:general )?court (?:observes|finds|notes|compares|agrees|adopts)|il (?:ressort|y a lieu de (?:constater|relever))|la cour (?:constate|relève))',re.I)
ADOPTION=re.compile(r'(?:^|[.;]\s+)(?:the (?:general )?court (?:finds|holds|compares|notes|concludes)|la cour (?:constate|relève))|(?:the (?:general )?court (?:agrees|adopts|endorses)|la cour (?:fait sienne|retient|approuve))',re.I)
SPECIFIC=re.compile(r'(?:english|french|german|dutch|italian|spanish|polish|finnish|swedish|greek|française|allemande|anglaise|deutsche|englische|französische)',re.I)


def passage_role(text):
    s=re.sub(r'^\s*\d+[.\s]+','',normalise_search(text))
    if not LANGUAGE_CUE.search(s):return 'other'
    if PARTY.search(s) and not ADOPTION.search(s):return 'party_argument'
    if REFERRING.search(s) and not ADOPTION.search(s):return 'referring_court_comparison'
    # A paragraph can contain a specific comparison and a reminder of general principles.
    if SPECIFIC.search(s) and (CURRENT.search(s) or re.search(r'first, as regards|from a comparison|same general wording|different language versions',s)):
        return 'current-comparison-candidate'
    if PRINCIPLE.search(s) and not SPECIFIC.search(s):return 'general_multilingual_principle'
    return 'unresolved-comparison'


def guard_answer(answer, snippets, meta, query):
    """Apply only explicit role contradictions; the stored model answer remains inspectable."""
    result=dict(answer)
    from .context import frame_for
    frame=frame_for(query)
    origin=frame['specific_language_comparison']
    # For free context, the model can identify a target actor more precisely than the display hint.
    if query.actor_scope=='auto' and query.preset=='general' and answer.get('target_actor') not in (None,'deciding_court'):
        return result
    if not origin:return result
    chosen=[p for p in snippets if p['id'] in answer['evidence']]
    roles=[{'id':p['id'],'role':passage_role(p.get('text',''))} for p in chosen]
    result['attribution_checks']=roles
    category=answer['category'];score=answer['score'];change=''
    # Generic-principle labels must not erase a source-supported comparison finding agreement.
    strong=[p for p in chosen if passage_role(p.get('text',''))=='current-comparison-candidate' and re.search(r'confirmed by other language versions|same (?:general )?wording.{0,60}other language versions|from a comparison of.{0,30}language versions',p.get('text',''),re.I)]
    if category=='general_multilingual_principle' and strong and answer.get('support')=='direct':
        category='applied_current_comparison';score=max(4,score)
        change='The cited reasoning checks specific language formulations and uses their agreement to support the interpretation.'
    if meta.get('doc_type')=='opinion' and category=='applied_current_comparison':
        category='advocate_general_comparison';change='The cited document is an Advocate General’s Opinion.'
    relevant={r['role'] for r in roles if r['role']!='other'}
    if category=='applied_current_comparison' and relevant and 'current-comparison-candidate' not in relevant and 'unresolved-comparison' not in relevant:
        if 'party_argument' in relevant:
            category='party_argument';change='The cited comparison is presented as a party’s argument. Check the Court’s subsequent reasoning.'
        elif 'referring_court_comparison' in relevant:
            category='referring_court_comparison';change='The cited passages attribute the comparison to the referring court. Further reasoning needs review.'
        else:
            category='general_multilingual_principle';change='The cited passage states a general multilingual-interpretation principle. A specific comparison still needs to be located.'
    # Correcting one language version from context does not itself compare versions.
    selected_text=' '.join(p.get('text','') for p in chosen)
    if category=='applied_current_comparison' and re.search(r'(?:obvious|clerical|manifest|typographical) error',selected_text,re.I) and not re.search(r'other language|different language|comparison of|French|German|Spanish|Italian|Dutch|Polish',selected_text,re.I):
        category='other_relevance';change='The evidence corrects one version from its context. A comparison between language versions is not established by this passage.'
    if category!='applied_current_comparison':
        ceiling=3 if category in {'uncertain','referring_court_comparison','partial_requested_relationship'} else (1 if category=='no_evidence' else 2)
        score=min(score,ceiling)
        if score!=answer['score'] and not change:
            change='The cited material supports a '+category.replace('_',' ')+'; inspect the source before treating it as the Court’s own comparison.'
    if category!=answer['category'] or score!=answer['score']:
        result.update(score=score,category=category,reason=change,model_score=answer['score'],model_category=answer['category'],model_reason=answer['reason'],guard_adjustments=[change])
    return result
