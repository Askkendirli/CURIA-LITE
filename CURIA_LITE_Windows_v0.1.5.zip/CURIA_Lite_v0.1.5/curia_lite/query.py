from __future__ import annotations

import datetime as dt
import re
from dataclasses import asdict, dataclass, field

from .common import LANGUAGES, date_range, normalise_search
from .keywords import KeywordPlan, entries, LEGACY, OPERATORS

FILTERS = {'case_number', 'case_name', 'ecli', 'celex', 'judge_rapporteur', 'advocate_general',
           'formation', 'language_of_case', 'original_language', 'procedure', 'subject_matter',
           'referring_country', 'case_status', 'national_context', 'international_context',
           'cited_provisions'}


@dataclass
class Query:
    date_from: str = ''
    date_to: str = ''
    courts: list[str] = field(default_factory=lambda: ['C', 'T'])
    types: list[str] = field(default_factory=lambda: ['judgment'])
    languages: list[str] = field(default_factory=lambda: ['fr'])
    query_language: str = 'en'
    keywords: list[str] = field(default_factory=list)
    logic: str = 'phrase'
    exclude: list[str] = field(default_factory=list)
    near_distance: int = 5
    context: str = ''
    preset: str = 'general'
    actor_scope: str = 'auto'
    depth: str = 'fast'
    source_mode: str = 'auto'
    refresh: bool = False
    filters: dict = field(default_factory=dict)
    min_score: int = 3
    include_demo: bool = False

    def to_dict(self):
        return asdict(self)

    @classmethod
    def parse(cls, value: dict, config: dict):
        if not isinstance(value, dict) or set(value) - set(cls.__dataclass_fields__):
            raise ValueError('Unexpected search fields.')
        q = cls(**value)
        if not all(isinstance(v, str) for v in [q.date_from, q.date_to, q.context, q.query_language]):
            raise ValueError('Dates, context, and query language must be strings.')
        date_range(q.date_from, q.date_to)
        if q.date_to and dt.date.fromisoformat(q.date_to) > dt.date.today():
            raise ValueError('The decision end date cannot be in the future.')
        if q.source_mode not in {'auto', 'local'}:
            raise ValueError('Source mode must be auto or local.')
        if q.source_mode == 'auto' and (not q.date_from or not q.date_to):
            raise ValueError('Automatic retrieval requires both decision-date bounds.')
        for values, allowed, label in [
            (q.courts, {'C', 'T', 'F'}, 'courts'),
            (q.types, {'judgment', 'opinion', 'order'}, 'document types'),
            (q.languages, set(config['native_languages']), 'document-version languages'),
        ]:
            if not isinstance(values, list) or not values or any(not isinstance(x, str) or x not in allowed for x in values) or len(set(values)) != len(values):
                raise ValueError(f'Invalid {label}. At least one supported value is required.')
        if q.query_language not in config['native_languages']:
            raise ValueError('Query language is not in the configured model-language list.')
        q.keywords = entries(q.keywords)
        q.exclude = entries(q.exclude)
        q.logic = LEGACY.get(q.logic, q.logic)
        KeywordPlan.create(q.keywords,q.logic,q.exclude,q.near_distance)
        from .context import ACTORS
        if q.actor_scope not in set(ACTORS)-{'unknown'}|{'auto'}:
            raise ValueError('Choose a valid evidence actor.')
        if q.preset=='court_language_comparison' and q.actor_scope not in {'auto','deciding_court'}:
            raise ValueError('The language-comparison preset selects the deciding court. Use General search to choose another actor.')
        q.context = q.context.strip()
        if len(q.context.split()) > 30 or len(q.context) > 500:
            raise ValueError('Brief context is limited to 30 whitespace-separated words and 500 characters.')
        if not q.context and not q.keywords and q.preset == 'general':
            raise ValueError('Enter keywords or brief context, or select the language-comparison preset.')
        if q.logic not in OPERATORS or q.preset not in {'general', 'court_language_comparison'} or q.depth not in {'fast', 'full'}:
            raise ValueError('Invalid keyword logic, search preset, or screening depth.')
        if type(q.min_score) is not int or not 1 <= q.min_score <= 5:
            raise ValueError('Minimum relevance must be from 1 to 5.')
        if type(q.refresh) is not bool or type(q.include_demo) is not bool:
            raise ValueError('Refresh/demo options must be Booleans.')
        if not isinstance(q.filters, dict) or set(q.filters) - FILTERS or any(not isinstance(x, str) or len(x)>300 for x in q.filters.values()):
            raise ValueError('Invalid advanced criteria.')
        q.filters = {k:v.strip() for k,v in q.filters.items() if v.strip()}
        return q

    @property
    def semantic(self):
        return bool(self.context or self.preset != 'general')


def keyword_hits(text: str, keywords: list[str]) -> list[str]:
    return KeywordPlan.create(keywords,'any_phrases').match(text)['hits']


def eligibility(meta: dict, q: Query) -> tuple[str, list[str]]:
    """Unknown metadata is reported separately from a proven criterion mismatch."""
    unknown = []
    date = meta.get('delivery_date', '')
    if q.date_from or q.date_to:
        if not date:
            unknown.append('delivery_date')
        elif (q.date_from and date < q.date_from) or (q.date_to and date > q.date_to):
            return 'excluded', ['date']
    if meta.get('retrieval_language') not in q.languages:
        return 'excluded', ['document_language']
    if meta.get('doc_type') not in q.types:
        return 'excluded', ['doc_type']
    if meta.get('court') not in q.courts:
        return 'excluded', ['court']
    for key, value in q.filters.items():
        field_name = 'case_numbers' if key == 'case_number' else key
        found = meta.get(field_name)
        if not found:
            unknown.append(key)
            continue
        if key == 'case_number':
            from .extractor import case_id
            if case_id(value) not in [case_id(x) for x in found]:
                return 'excluded', [key]
        elif key in {'celex','ecli','language_of_case','original_language','case_status'}:
            a,b = normalise_search(str(found)), normalise_search(value)
            if key == 'ecli':
                a,b = a.removeprefix('ecli:'), b.removeprefix('ecli:')
            if a != b:
                return 'excluded', [key]
        elif normalise_search(value) not in normalise_search(' '.join(found) if isinstance(found, list) else str(found)):
            return 'excluded', [key]
    return ('metadata-unresolved', unknown) if unknown else ('eligible', [])


def case_groups(rows: list[dict]) -> list[dict]:
    """Shared own-case numbers join related documents, not citations in their reasoning."""
    parents = {}
    def find(x):
        parents.setdefault(x,x)
        if parents[x] != x:
            parents[x] = find(parents[x])
        return parents[x]
    for row in rows:
        ids = row.get('case_numbers') or [row['doc_id']]
        for i in ids:
            parents[find(i)] = find(ids[0])
    groups = {}
    for row in rows:
        key = find((row.get('case_numbers') or [row['doc_id']])[0])
        groups.setdefault(key, []).append(row)
    out = []
    for docs in groups.values():
        assessed = [d for d in docs if type(d.get('score')) is int and d.get('status')!='keyword-excluded']
        pending = [d for d in docs if d.get('status')!='keyword-excluded']
        best = max(assessed, key=lambda d:d['score']) if assessed else (pending[0] if pending else docs[0])
        out.append({'case_numbers': sorted({i for d in docs for i in d.get('case_numbers', [])}),
                    'case_name': best.get('case_name',''), 'score': best.get('score'),
                    'label': best.get('label','Not assessed'), 'best_document': best['doc_id'],
                    'assessment_complete': all(d.get('status') in {'assessed','keyword-excluded'} for d in docs),
                    'documents': docs})
    return sorted(out, key=lambda x:(-(x['score'] or 0),x['case_numbers']))
