"""Request one additional reading when source cues and a first rating disagree."""
from __future__ import annotations

import json
import re
from dataclasses import replace

from .attribution import LANGUAGE_CUE, PRINCIPLE, SPECIFIC, passage_role
from .context import frame_for, source_actor


SPECIFIC_RELATION = re.compile(
    r'except for|unlike|whereas|differs?|different|all (?:the )?language|other language versions|'
    r'in (?:some|the .{0,35}) language versions|(?:language versions?).{0,80}(?:use|term|word|mean)|'
    r'(?:wording|expression|term|word).{0,60}(?:french|german|polish|english|dutch)|'
    r'confirmed by|same wording|plupart|contrairement|während|hingegen|invece|terwijl', re.I)


def specific_source_passage(p):
    text=p.get('text','')
    if not LANGUAGE_CUE.search(text):return False
    if re.search(r'wikipedia|encyclop(?:aedia|edia)',text,re.I) and not re.search(r'compar(?:e[ds]?|ing|ison)|other language versions|different language versions',text,re.I):return False
    if not re.search(r'language.{0,16}versions?|linguistic.{0,10}versions?|versions? linguistiques?|sprachfass|taalversi|version[ie] linguistic|versiones? lingüístic|vers[õã]es? linguístic|(?:French|English|German|Polish|Dutch).{0,15}version',text,re.I):return False
    if passage_role(text) in {'party_argument','referring_court_comparison','general_multilingual_principle'}:
        return False
    if source_actor(text) in {'party','referring_court','advocate_general'}:return False
    return bool(SPECIFIC_RELATION.search(text) and (SPECIFIC.search(text) or re.search(r'other language versions|all language versions',text,re.I)))


def review_reason(answer, passages, query):
    """A cue triggers another reading, not an automatic score increase."""
    frame=frame_for(query)
    if frame['specific_language_comparison']:
        concrete=[p for p in passages if specific_source_passage(p)]
        if answer['score']<=3 and concrete:
            return 'The supplied text contains a specific language-version observation that needs a closer reading.'
        if answer['score']>=4 and answer.get('context_checks',{}).get('evidence_actor') in {'unknown','referring_court','party'}:
            return 'The evidence attribution needs a second check.'
    if answer.get('guard_adjustments') and answer.get('model_score',answer['score'])>=4 and len(passages)>1:
        roles={source_actor(p['text']) for p in passages}
        if 'deciding_court' in roles and roles-{'unknown','deciding_court'}:
            return 'The passages include more than one actor; the requested action needs a second check.'
    return ''


def review_packet(text,query,lang,config,budget,original):
    from .screening import select_evidence
    complete,_=select_evidence(text,replace(query,depth='full'),lang,config,budget=budget)
    blocks=[p for group in complete for p in group]
    by_id={p['id']:p for p in blocks}
    anchors=sorted((p for p in blocks if specific_source_passage(p)),key=lambda p:(p['id'] not in {x['id'] for x in original},p['id']))
    if not anchors:anchors=[by_id[x['id']] for x in original if x['id'] in by_id]
    if not anchors:return original
    chosen=[]
    # The first anchor and its following explanation are prioritised, then further anchors.
    priority=[]
    for anchor in anchors[:2]:
        priority += [anchor,by_id.get(anchor['id']+1),by_id.get(anchor['id']-1)]
    priority += anchors[2:] + original
    for p in priority:
        if p and p['id'] not in {x['id'] for x in chosen}:
            proposed=chosen+[p]
            if len(json.dumps(proposed,ensure_ascii=False).encode())<=budget:
                chosen=proposed
            if len(chosen)>=config['snippets']:break
    return chosen or original
