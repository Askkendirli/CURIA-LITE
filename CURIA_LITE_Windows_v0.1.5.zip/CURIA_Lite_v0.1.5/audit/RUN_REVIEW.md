# Review of run 7078f20c51dc4546

Release prepared: **0.1.5**, 15 October 2026.

## Evidence and scope

The supplied JSON describes a search from 1 January 2025 through 1 January 2026, English judgments from both courts, `any_phrases` with `language version; language versions`, and the context “cases where the court compared language versions”. The minimum display grade was 1, so all graded keyword candidates were included in the saved shortlist.

The review examined the collection counts, every recorded failure and the saved evidence/answers for all 55 assessed documents. Full source files were not attached. The recorded passages therefore support an evidence-level review, not a fresh exhaustive legal analysis or a recall calculation across every judgment.

## Recorded run counts

| Observation | Count |
|---|---:|
| Requested document-language versions | 927 |
| Downloaded and accepted | 700 |
| Reused local source versions | 0 |
| Requested English versions unlisted in checked publication records | 215 |
| Unresolved downloads | 12 |
| Documents satisfying the literal phrase condition | 55 |
| Documents excluded by that condition | 645 |
| Completed actual model requests in the supplied run | 55 |

The acquisition counts reconcile: 700 + 215 + 12 = 927. The 215 unlisted versions are not retrieval failures, accepted documents or negative relevance decisions. Their language-version texts were outside the analysed material.

Acquisition took 5,677.58 seconds, screening 287.692 seconds and the entire run 5,980.805 seconds. The saved score distribution is 15 Very high, 23 High, one Medium, 12 Low and four Very low. Successful model responses do not by themselves validate the assigned scores.

## The twelve retrieval failures

| CELEX | Recorded problem | Change implemented |
|---|---|---|
| 62022TJ0830 | The returned English text begins “In Cases T-830/22 and T-156/23”, but the old own-case reader rejected it. | Anchored plural own-case recognition retains both identifiers. |
| 62023CJ0645 | English judicial heading begins `ENJUDGMENT`. | A matching two-letter language prefix can precede the standalone heading. |
| 62023CJ0733 | Same attached-prefix issue. | Same bounded heading correction. |
| 62024CJ0099 | A “case” expression in the introductory subject description interfered with own-case identification. | Own-case labels must begin the relevant heading line. |
| 62024CJ0643 | Same introductory-reference problem. | Actual own-case heading is selected rather than the earlier prose reference. |
| 62024TJ0534 | The heading is “Judgment (Chamber giving preliminary rulings)”. | Recognised when nearby General Court and T-case identity markers also agree. |
| 62023TJ0167 | Catalogue data contained no file items and the independent tree route was skipped. | All-empty data triggers the independent RDF publication-tree check. |
| 62023TJ0295 | Same inconclusive catalogue path. | Same independent-tree correction. |
| 62023TJ0399 | Same inconclusive catalogue path. | Same independent-tree correction. |
| 62024CJ0292 | The RDF reader reported an unsupported `parseType` without identifying the value. | Standard Literal and Collection syntax supported; other unsupported values named in the error. |
| 62024CJ0280 | Same RDF-reader rejection. | Same parser correction and clearer diagnostic. |
| 62024CJ0541 | Same RDF-reader rejection. | Same parser correction and clearer diagnostic. |

The six retained English header previews now pass identity/date/type parsing in regression tests. This is a replay of the saved response previews, not evidence of successful fresh downloading of complete judgments.

A separate HTTP 406 response explicitly states that `application/pdf` does not match the selected resource’s `application/pdf;type=pdfa2a`. The collector now preserves advertised PDF/A media types and selects HTML/XHTML before PDF when both have file links. The official CELLAR publication documentation lists these parameterised media types. A safe retry may use a recognised PDF subtype reported in a 406 response.

The previous RDF error did not record the exact unsupported parseType value. It cannot be established from that log alone that all three notices used the newly supported standard forms. Those notices still need a live retry. Entity, size, nesting and triple-count safeguards remain in place.

## Rating review

The 38 High/Very high answers generally cite concrete comparisons in the supplied passages. Those passages include differences and agreement, lexical and grammatical observations, and comparisons of administrative or judicial texts. The distinction between High and Very high is ordinal prioritisation, not a calibrated measure of correctness.

Several Low answers understate their own source evidence:

| Case and paragraph | Saved grade | Evidence-level finding |
|---|---:|---|
| C-346/23, §44 | 2 | The Court identifies Dutch as the exception to a plural formulation and uses that observation to discuss consumer interests. This supports the requested specific comparison. |
| C-405/24, §§31–32 | 2 | Polish “Member State” is compared with versions using an indefinite article; the following paragraph draws the interpretive consequence. |
| C-570/24, §38 | 2 | A concrete observation contrasts language formulations of the legal relationship. A Low/background answer needs a closer reading of that passage and its surroundings. |
| T-409/24, §§56 and 129 | 2 | The Court compares “Aji” in the other versions with French “Ali Najib Ibrahim” and discusses the legal consequence. This is not merely correcting one version from its own context. |

A targeted second reading is now requested for low/partial Fast answers when the supplied text contains such concrete cues. The initial response is retained and no score increase is assigned merely because a cue matched. The review can increase, decrease or retain the grade.

Two application guards also affected the saved answers:

- **C-416/24 and C-417/24 (On Air):** the original model’s partial-relationship grade 3 was forced down to 2. Partial support is now retained as Medium. The available mixed linguistic/publication evidence is eligible for a closer reading.
- **C-567/24:** a selected referring-court passage caused another selected, unresolved passage of current judicial reasoning to be overridden. A single recognised actor no longer overwrites all other unknown passages. Replaying the saved answer retains its original grade 4; this is not a new model judgment.

C-717/23, C-422/24 and T-614/24 remain candidates for review because the saved packets leave the role or significance of the linguistic observation uncertain. C-217/23 and C-685/23 contain less specific multilingual statements and should not receive High solely from general concordance wording. The lower grades for party-only material in T-298/23 and T-573/23, and incidental language references in T-1026/23 and T-338/24, are consistent with the requested current-court comparison criterion on the supplied evidence.

Strong examples include C-203/22 (§§40–42, multilingual information/logic terminology), C-410/23 (§57, French versus other contract-termination wording), T-657/24 (§32, terms relating to negotiation), and T-553/23 (the current General Court’s comparison of French and English wording of an earlier judgment). The latter illustrates the difference between the actor performing a comparison and the earlier text being compared.

`RECORDED_RESPONSE_REPLAY.json` records validation of all 55 stored model responses. Eight of those saved packets trigger an additional reading under the new rules. No new local model was available in this audit, so the file contains no invented second-pass scores. A real repeat search can select a different packet after re-extraction; eight is not a guaranteed forecast of future calls.

## Interface and exports

Individual hover, focus and click explanations cover every progress/result counter. Collection counts refer to document-language versions. “Unlisted” means the successfully checked publication records provide no readable full-text file for the requested version; available file languages and check time remain inspectable. It does not mean the case has no relevance.

New Word exports contain the Collection and screening guide. `collection_status.csv` and JSON `status_guide` preserve the same definitions and counts. Historical exports are not rewritten automatically.

## Larger interval preparation

Pending worker tasks are bounded, candidate text is opened when a worker needs it, the recent-search menu uses small run indexes, and publication details are paged. Existing source and assessment caches remain reusable when their content/settings agree. A versioned parser re-extracts existing raw bytes locally. Each flagged Fast document can receive at most one additional model reading; the setting is adjustable.

The dedicated `examples/remaining_12_documents.json` supplies the twelve failed identifiers for a small retrieval retry. The 215 unlisted English versions remain a separate publication-coverage consideration. No claim is made that a larger date interval will have zero unavailable versions, download errors or imperfect ratings.
