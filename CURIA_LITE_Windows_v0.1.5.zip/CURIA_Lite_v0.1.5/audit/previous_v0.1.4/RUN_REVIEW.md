# Review of the 15 October run and changes in v0.1.4

Input: `1055a34f941c4629_results.json`. The complete uploaded JSON was parsed. This document distinguishes the operator's recorded run from development tests of the revised software. The full uploaded result file is not redistributed in this repository.

## Recorded search and execution

| Item | Recorded value |
|---|---|
| Decision dates | 1 January–15 March 2026 |
| Courts / type / document language | Court of Justice and General Court; judgments; English |
| Keywords | `language version; language versions` |
| Operator | Any word · OR |
| Context | `cases where the court compared language versions` |
| Display minimum | 1, Very low |
| Discovery records | 181 |
| Available documents | 147 |
| Retrieval failures | 34, the same identifiers as the earlier two uploads |
| Model calls | 147, all completed; no cached assessments |
| Acquisition time | 421.018 seconds |
| Screening time | 354.750 seconds |
| Total time | 778.289 seconds |

The operator correctly interpreted the unquoted input as the alternatives `"language"`, `"version"`, and `"versions"`. All 147 documents matched, frequently through the procedural-language footnote. The low display threshold then included all grades. This behaviour follows the selected operator; Any phrase is the appropriate selection when the intended alternatives are the two complete expressions `"language version"` and `"language versions"`.

The grades were: 117 Very low, 20 Low, 3 Medium, 2 High and 5 Very high. Their successful generation does not independently establish semantic accuracy.

## Retrieval regression in v0.1.3

All 34 unresolved documents produced a catalogue HTTP 500. The same expanded catalogue query was requested twice for each document, giving 68 catalogue failures. There were zero publication-tree attempts. The additional retrieval routes then returned 404s, empty/verification responses, or unrecognised CURIA links.

The v0.1.3 query had introduced unbounded bidirectional `owl:sameAs` property paths at several levels of the publication graph. The supplied log proves that this query was rejected, but did not retain the response body needed to establish the exact server-side cause. In addition, the independent RDF-tree call was inside the catalogue-success control path; an HTTP 500 skipped that fallback entirely. The previous fix therefore introduced a regression rather than completing the intended independent check.

### Changes

- The catalogue query now uses bounded, explicit work/expression/format/file relations and declared work identifiers. Unbounded equivalent-identifier paths were removed from the remote query.
- Equivalent identifiers are reconciled locally from the returned RDF tree. Nested RDF resource representations are supported under size, depth and declaration checks.
- The publication-tree request is attempted independently when catalogue lookup fails or leaves the requested file unlisted.
- The identical catalogue query is not repeated at the end of the failed attempt chain.
- HTTP error response excerpts are retained, including the server's explanation when available.
- The publication-cache version changed so the new lookup is not suppressed by old cached availability records.
- Configured EUR-Lex/CURIA/PDF alternatives are checked before an unresolved requested language is recorded as unlisted. A failed metadata request or an advertised file that cannot be read remains a retrieval problem.
- CURIA checks both ordinary and appeal case-number forms where relevant, both recognised official hosts, and records page titles, resolved URLs and link counts for diagnosis.

`examples/remaining_34_documents.json` contains the official identifiers, dates and discovery locations for a focused retry of this failed set. It does not contain retrieved judgments or imply that every English full text exists.

### Publication gaps and real download failures

The Court's official language policy explains that some judgments are provided only in the language of the case and the drafting language, usually French. An English description, case-page label or Official Journal notice is not evidence that a full English judgment was published. The collector therefore keeps a checked publication-file gap distinct from failure to download an advertised file. It never fills an English slot with French text, a notice, a summary or a machine-generated translation.

The source-service hosts could not be resolved from this development environment. Recovery of all 34 English texts has not been demonstrated. The revised software must be tested against the live sources on the Windows installation; genuinely unlisted versions may remain as publication gaps.

## Relevance findings from the actual retained passages

The review below concerns the evidence saved with the run, not a complete re-reading of all 147 judgments.

| Case / passage | Recorded result | Evidence-based assessment |
|---|---|---|
| C-382/22 P, paragraph 184 | High, 4 | Corrects a reference in the language-of-case judgment using its context. The cited passage contains no comparison with a different language version. High is not supported for this particular comparison question. The revised explicit single-version guard caps the same evidence at Low. |
| C-18/24, paragraph 52 | Medium, 3 | Explicitly lists corresponding wording across named languages. A finding of agreement is still a specific comparison. A direct-evidence rating is appropriate if the actor and requested relationship are confirmed. |
| C-367/22 P, paragraph 128 | Medium, 3 | Uses named language formulations to confirm the classification as limitation periods. The reason for withholding a direct-evidence grade is not supported by the cited passage. |
| C-379/22 P, paragraph 237 | Low, 2 | The same form of specific multilingual confirmation was labelled a general principle and reduced by the old guard. This should be reassessed under the direct-evidence rubric. |
| C-286/24, paragraphs 29–30 | Very high, 5 | This run supplies specific contrasting versions. Unlike the earlier run that cited only a general principle, the saved evidence supports a strong comparison candidate. |
| T-379/23, paragraph 41; C-313/24, paragraphs 29–31; T-69/25, paragraph 44; T-177/25, paragraph 31 | Very high, 5 | The saved passages contain concrete multilingual comparisons and support their inclusion as strong candidates. |
| C-619/24, paragraph 21 | Medium, 3 | The passage attributes the observation to the referring court. Further current-court reasoning is needed for the narrower attribution claim. |
| T-195/25, paragraph 79 | Low, 2 | The cited comparison is the Commission's argument. The current attribution qualification is appropriate for the saved passage. |
| T-619/24, paragraphs 45, 46 and 59 | High, 4 | Analyses English/German versions of registration applications. The broad wording of the context does not exclude this subject matter. |

The four public excerpts added to the regression fixtures are test material for evidence-handling rules. Simulated corrected classifications are explicitly supplied by tests; they are not new outputs from a loaded model. No precision, recall, false-positive percentage or overall legal-accuracy rate is calculated from this partial evidence set.

## General contextual screening

Every context is now passed through a common subject/action/actor/outcome/condition rubric. The model returns its interpretation of the requested actor, the actor supported by the evidence, and the strength of the relationship, in addition to its score, category, source IDs and short reason. The same checks therefore apply to aid recovery, party requests, judicial outcomes, statutory interpretation and other research questions, not only a recognised language-comparison phrase.

An optional actor control can specify the deciding court, referring court, party, Advocate General, public authority, legislature or an earlier cited court. The original context remains intact. Wording-based hints help preview a query but are not the sole method for evaluating an arbitrary context.

Direct evidence can be High or Very high; partial support is capped at Medium, background at Low, and contradicted/absent support at Very low. Explicit actor mismatches are qualified. Specific multilingual agreement is not demoted simply because no divergence exists. The original model score/category/reason and any adjustment remain inspectable.

The default model, weights and runtime budget were not changed. This release improves prompt instructions, the response schema, evidence selection and validation. No model-weight fine-tuning was performed and no new model-quality benchmark result is claimed.

## Additional diagnostic

`Test_Context_Windows.cmd`, or the interface's context-check button, sends eight short artificial English examples through the configured local model. It tests requested judicial outcomes, party attribution, the opposite outcome, broad topic relevance, an AG proposal, agreement between language versions and correction within a single version. Inputs, raw outputs, expected ranges and checks are written to `diagnostics/context-check.json`.

The developer test of this helper used injected responses. A real-model result must come from running the helper on the target machine. The ten-example literal keyword helper remains separate and makes no model calls.

## Interface language

Operator explanations now quote the example words and show semicolon-separated complete phrase examples. Any phrase and All phrases explain respectively that at least one or every complete phrase must occur. Hover and keyboard help use the same definitions. Grey keyword and context placeholders start with “Example:” in English, with French and German equivalents. No replacement was inserted for the previously removed coverage slogan.
