# Verification record — CURIA LITE v0.1.4

Date: 15 October 2026. Baseline: the distributed Windows v0.1.3 ZIP.

## Executed checks

| Check | Result / scope |
|---|---|
| Baseline ZIP and hashes | ZIP CRC passed; 110 baseline file checksums matched |
| Baseline automated suite | 223 tests passed |
| Revised automated suite | **282 tests passed** |
| Python compilation | Passed for application, scripts and tests |
| JavaScript syntax | `node --check` passed |
| Revised SPARQL syntax | Parsed locally with rdflib; this is syntax evidence, not an executed live endpoint query |
| Wheel build | Passed with `pip wheel --no-deps --no-build-isolation` |
| Independent installed package | Imported outside the source tree from a separate install target; assets present; literal tests and synthetic contextual pipeline/exports passed |
| Keyword diagnostic | Ten artificial examples passed; zero source requests and zero model calls |
| Context diagnostic | Eight artificial examples passed with injected model responses; no real model weights executed |
| UI behaviour | Actual Chromium 144.0.7559.96 executed the bundled JavaScript with a bridge to the actual loopback application server; operator hover/selection, unrelated context preview, actor selector, diagnostic button, results, settings and EN/FR/DE examples passed without page errors |
| Native browser navigation | Attempted; blocked by administrator policy. The browser policy was not bypassed. A fresh blank page was used for the subsequent bridged DOM test. |
| DOCX shortlist | Final synthetic one-page export rendered and visually inspected; JSON and CSV files also produced |
| Live sources | CELLAR, CURIA and EUR-Lex DNS resolution failed in the development container |
| Real local model | No service on the loopback Ollama port; no new inference quality claim |
| Native Windows | Not executed here; Windows/Ubuntu CI and Windows launchers remain supplied |

The installed package reused available dependency libraries. It was not a fresh network installation. The UI transport bridge allows actual JavaScript, HTTP handler and processing behaviour to be tested without representing blocked browser navigation as successful. An initial rerun encountered a destroyed page context after blocked navigation; the test harness was corrected to create a fresh page before the bridged test. This adjustment does not modify the distributed application or browser security policy.

## Test coverage added in this release

New cases cover bounded catalogue queries, independent RDF checks after catalogue HTTP 500, local/nested equivalent-identifier parsing, 34-set identification, fallback ordering, cached availability invalidation, capture of server error text, and maintenance of source-language/identity checks. Contextual cases cover shared actor/action/outcome requirements, explicit actor selection, subject-only versus direct support, party/court/AG distinctions, contradictions and negation, agreement across specific versions, single-version corrections, strict typed response fields, complete input retention, and diagnostic cancellation/concurrency. A final rerun exposed a completion race in which the HTTP response could arrive before the diagnostic lock was released; the lock is now released before the response is sent. The failing rerun and corrected final suite are retained separately.

Some existing tests were intentionally updated to reflect corrected requirements: nested RDF resources are now read; configured alternate providers are checked before publication status is concluded; simulated production classifier responses include the three new contextual fields. The change list and source diff identify those edits. Test counts are software test cases, not a count of legal decisions independently validated by humans.

The public excerpt fixtures replay narrowly specified evidence checks. The model was not trained on them. Human-specified expected classifications in these tests must not be presented as fresh Ministral results.

## Actual user-run evidence

The uploaded v0.1.3 run contains 181 discovered records, 147 available English texts, the same 34 retrieval failures, and 147 completed local inference calls. Its acquisition took 421.018 seconds and screening took 354.750 seconds. Those measurements describe the user's old run; they are not speed measurements for v0.1.4. See RUN_REVIEW.md and INPUT_REVIEW.json for the analysis.

## Remaining acceptance

Run Setup_Windows.cmd in a separate extracted application folder while preserving the existing data folder. Start v0.1.4, run the keyword helper, and run the new context helper on the configured model. For retrieval diagnosis, import the selection in `examples/remaining_34_documents.json` and retry those documents rather than re-running contextual inference over the whole archive. Inspect both publication-file availability and unresolved retrievals.

Genuinely unlisted requested-language judgments may remain unavailable. Successful syntax/unit testing does not establish that every official portal currently serves every language version. Full legal accuracy, complete corpus recall, native Windows performance and a measured speed-up remain unestablished. Fast screening retains its passage-selection limitation.

## Reproducibility

Fresh evidence is in this audit directory. Older v0.1.2/v0.1.3 audits remain in explicitly named historical subdirectories. The checksum manifest covers the distributed snapshot and is regenerated only after final review. No user archive, model weights, private correspondence or complete uploaded search export is included in the public package.
