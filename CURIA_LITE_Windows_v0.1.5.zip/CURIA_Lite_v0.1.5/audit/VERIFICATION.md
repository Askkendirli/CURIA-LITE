# CURIA LITE 0.1.5 — verification record

Date: 15 October 2026. Baseline: the supplied Windows v0.1.4 distribution.

## Executed checks

| Check | Result |
|---|---|
| Baseline ZIP/checksums | CRC valid; 138 distributed hashes matched before changes. |
| Unchanged baseline suite | 282 tests passed. |
| Final revised suite | **326 tests passed**, repeated after the final source changes. |
| Python compilation / JavaScript syntax | Passed. |
| Reported English header previews | All six reproduced header/identity failures pass the revised reader. |
| Recorded relevance responses | All 55 supplied responses inspected/replayed; eight packets trigger additional review. No new model outputs generated. |
| Bounded task queue | A 5,000-item synthetic workload test checks the in-flight limit; source/inference behaviour is not benchmarked by this test. |
| Independent installed wheel | Built and imported outside the source folder; offline demo ingestion, literal search, exports, status definitions and packaged web assets checked. Dependencies inherited from the audit environment. |
| Actual local interface | Chromium 144.0.7559.96 executed the shipped HTML/CSS/JavaScript through a bridge to the actual local HTTP server. Hover/focus/Escape, three interface languages, review setting and collection-guide export checked without page errors. |
| Direct browser navigation | Attempted and blocked by administrator policy. No bypass was attempted. |
| Word export | A two-page synthetic shortlist rendered; both final pages visually inspected, including definitions and publication details. |
| Live source network | CELLAR and EUR-Lex DNS resolution failed from the application environment. No successful live recovery of the twelve failures is claimed. |
| Actual local model | Ollama loopback connection refused. The 55 completed real requests are evidence from the supplied user run, not from this development environment. |
| Native Windows / hosted CI | Not executed here. Existing Windows/Ubuntu CI and Windows launchers remain provided. |

The tests include original operator, API, storage, cache, import, model-stream, source-validation and cancellation checks. Added regressions cover plural/short/prefixed headings, subtitle identity traps, PDF/A media types and format order, all-empty catalogue fallback, safe standard RDF Literal/Collection handling, paragraph dates, mixed source actors, partial evidence, bounded additional review and caching, second-pass downgrade, Wikipedia-only references, localised counter definitions and Word/JSON/CSV status guides.

The additional reading tests use controlled model answers and recorded judicial excerpts. They establish application behaviour; they do not establish legal precision, recall or universal scoring correctness. The six header fixtures contain response previews from the supplied logs, not complete newly fetched files. RDF parseType values missing from the old log cannot be retrospectively verified.

## Preserved evidence

- `INPUT_REVIEW.json`: counts, query, timing and failure classes derived from the latest JSON.
- `RECORDED_RESPONSE_REPLAY.json`: per-case saved-score validation and extra-reading triggers.
- `TEST_RESULTS.txt`, `TEST_RESULTS_REPEAT.txt`: fresh final test output.
- `ENVIRONMENT.json`, `CONNECTIVITY.json`: runtime/dependencies and actual connection attempts.
- `UI_CHECK.json`, `EXPORT_QA.json`: interface transport and rendering checks.
- `INSTALLED_WORKFLOW.json`, `WHEEL_BUILD.txt`, `WHEEL_SOURCE_MATCH.json`: build/install evidence.
- `SOURCE_CHANGES.diff`, `CHANGED_FILES.json`: exact source differences from v0.1.4.
- `previous_v0.1.4/` and earlier directories: historical audit records, not current-run evidence.

## Acceptance on the Windows machine

Back up the existing workspace, install in a separate application folder and confirm v0.1.5. Run Test keyword matching, then the twelve-example contextual diagnostic. Retry the supplied twelve-document selection with no context before starting a large inference run. Review the separately listed unavailable language versions and failed requests.

A checksum validates distribution bytes. The native deployment, source services and selected model still require actual target-machine use. The software does not claim failure-free access to every published language version.
