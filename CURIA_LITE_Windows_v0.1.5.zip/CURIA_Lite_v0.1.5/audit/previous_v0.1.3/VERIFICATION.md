# Verification — CURIA LITE 0.1.3

15 October 2026. This release addresses repeated publication-file retrieval attempts and the first submitted local-AI contextual run. The detailed run interpretation is in RUN_REVIEW.md. Existing keyword operators and model runtime defaults remain unchanged.

## Implemented changes

The catalogue resolver now follows equivalent work, expression, manifestation and item identifiers, and separately reads documented RDF publication-tree notices. A missing file is recorded as unlisted only when the checked tree supports that observation for the supplied work addresses. English descriptive metadata is kept distinct from an English publication file. Inconclusive graph shapes, failed notices, source conflicts and failed advertised items continue to produce visible follow-up records. Recent reconciled observations can be cached with an expiry and explicit recheck. Every requested language version remains accounted for.

Embedded-text PDFs are accepted as official source alternatives with original bytes, language, type and identity validation preserved. PDFs without usable text remain rejected; OCR is not used. Configurable CURIA fallback and a bounded retry of interrupted body transfers supplement the existing HTTP routes.

The explicit context “cases where the court compared language versions” now applies the same current-court rubric as the dedicated preset, with a preview of the recognised purpose. Checks address clearly attributed party/referring-court evidence and general multilingual principles. They preserve the original model answer and do not replace a full legal review. All supplied evidence passages and packet assessments are recorded. Literal-match evidence receives priority in Fast selection. The reader also cleans incidental prefixes from rapporteur metadata and recognises General Court party headings.

Previous semantic caches are separated by the new prompt/reader versions. Old runs retain their historical results. The local workspace, keyword semantics and runtime model settings are preserved on update; the new PDF reader is installed by Setup.

## Executed checks

| Check | Result and qualification |
|---|---|
| Unchanged v0.1.2 baseline | 170 tests passed |
| Complete v0.1.3 regression suite | **223 tests passed** |
| Existing keyword acceptance helper | Ten synthetic scenarios passed, with zero source-site or model calls; included in the suite |
| New publication checks | Tested alias recovery, metadata-only reconciliation, failed notices, all-empty/unsupported graphs, untyped item links, advertised-file failures, expiry/refresh, changed provider and valid-local precedence |
| Embedded-text PDF | Artificial PDF parsed, identity/language validated, bytes preserved, and advertised PDF route exercised; textless PDF rejected |
| User-record replay | Nine retained answers checked against their original cited public passages; no new inference used |
| Context/input checks | Explicit intent preview, exact-keyword anchor priority, source-role bounds, original-answer preservation, full input/evidence recording and cache reuse |
| Interrupted HTTP body | Controlled streaming failure followed by successful bounded retry |
| Python / JavaScript | Compilation and JavaScript syntax checks passed |
| Actual interface | Chromium executed bundled UI assets with a bridge to the actual loopback application server; settings, focus preview, operator hover, publication details and evidence panels checked |
| Browser navigation | Restricted by administrator policy; bridge execution is recorded separately |
| Word export | Two-page display fixture using retained public passages and synthetic status data rendered and visually inspected |
| Installable package | Wheel built and independently installed outside the source directory; existing audit dependencies reused |
| Native Windows | Not executed in this environment; Windows launchers and CI retained |
| Real local inference | The supplied user run contains nine successful real requests. No model was loaded during this independent audit |
| Live collection | Container DNS requests to source hosts failed; retrieval improvements remain to be confirmed on the target Windows installation |

The 223 passing cases are software regressions. They do not represent 223 legal cases, recovered English texts or independent model-quality observations. The deterministic source-role replay is not a new model benchmark. The current audit records keep implementation evidence separate from the actual user-run evidence.

## Integrity and distribution

The final archive is checked for ZIP corruption, and its distributed files are covered by SHA256SUMS.json. `scripts/verify_integrity.py` verifies that snapshot. Source changes relative to v0.1.2 are preserved in SOURCE_CHANGES.diff. Earlier verification records are retained under previous_v0.1.2.

The repository contains no user workspace, full private run exports, model weights, signed declaration, academic paper or font files. The small regression fixture contains only retained public legal passages and their historical model classifications.

## Target-machine acceptance

Close the old application, back up the data folder, install v0.1.3 in a separate application folder, and confirm the version in the interface. Run the keyword helper, then repeat the two saved queries. Inspect Publication-file availability and any remaining failed items. For a broader AI-only question, clear the exact phrase or include singular/plural alternatives explicitly. Fresh classification results should be checked against both cited and fully supplied input passages, especially the actor attribution.

A run can finish processing its selected records while leaving unlisted requested full texts outside the analysed collection. Those publication details remain visible; they must not be reported as recovered sources or as evidence that an absent text contains no relevant material.
