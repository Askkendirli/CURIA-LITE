# Review of the two submitted searches

15 October 2026. The supplied JSON exports were read programmatically in full, and their stored evidence was inspected. This record separates observations from the original runs, retrospective source-role checks, and changes implemented in 0.1.3.

## What actually ran

| Measure | Literal run `371374214e9b41ff` | Context run `2ec53f3eea6048fe` |
|---|---:|---:|
| Decision dates | 1 January–15 March 2026 | Same |
| Requested version | English | English |
| Discovered document identifiers | 181 | 181, same saved discovery set |
| Available documents | 147 | 147 |
| Retrieval failures | 34 | The same 34 |
| Exact keyword | `language version` | `language version` |
| Keyword candidates | 9 | 9 |
| Keyword exclusions | 138 | 138 |
| Model calls | 0 | 9 |
| Recorded inference failures | 0 | 0 |
| Acquisition time | 812.702 seconds | 512.344 seconds |
| Screening time | 1.349 seconds | 38.418 seconds |
| Total run time | 816.654 seconds | 551.082 seconds |

The context was “cases where the court compared language versions”, with General purpose and Fast screening selected. The actual local model was `ministral-3:8b`, digest `1922accd5827ebe6829e536369195db25eaf664528dc66206d646ea3bb386b71`. Settings recorded 8,192 context tokens, 256 output tokens, 5,600 evidence bytes, four passages and one model worker. All nine classification requests completed. Their median recorded call time was 3.727 seconds. No speedup against another model or a manual research baseline was measured.

The AI reviewed the nine exact-keyword candidates, not all 147 available texts. For a broader contextual search, the keyword field can be cleared or Any phrase can include both `language version` and `language versions`. Their different coverage is intentional under the exact whole-word operator.

## Retrieval pattern

All 34 failed English versions share the same pattern in their stored catalogue entries: an English language record exists, but its `formats` and `items` arrays are empty. One or more other languages have actual file links. Several speculative aliases then returned 404. EUR-Lex returned repeated 2,038-byte responses without an identified judicial heading or usable body text.

These records do not prove that all 34 English texts are absent from every official portal. They demonstrate that the old downloader was repeatedly trying to resolve metadata-only language entries through unproductive file addresses. The new resolver follows equivalent WEMI identifiers and checks an independent official RDF publication tree before recording a scoped unlisted-file observation. A successfully advertised new English HTML/PDF can therefore still be retrieved. Incomplete notices, unrecognised RDF structures, conflicting sources and failed advertised files remain follow-up issues.

A reconciled observation is cached for 24 hours by default. Retry/Refresh forces a new check; a valid already saved document always takes priority. The UI records requested but unlisted texts separately, shows the actual file languages, and keeps those texts outside the analysed-document count. An empty file or failed HTTP response is never converted into a negative relevance score.

## Review of the nine AI answers

The following is a replay of the recorded classifications against their retained evidence. The new display bounds are validation results on those supplied passages; they are not newly generated model answers or final relevance findings about every passage in a judgment.

| Case | Original result | Review of retained evidence | New bound when the same answer/evidence is replayed |
|---|---|---|---|
| C‑524/23 | 1, no evidence | No positive evidence was retained in the AI export. The literal run retained a French-wording passage, so the explanation “No mention…” needs closer input inspection. | 1 remains possible for the contextual criterion; the matched phrase and all new input passages are shown. |
| T‑379/23 | 5, applied comparison | Paragraph 41 compares named language formulations of Article 13(2)(b). | 5 |
| C‑18/24 | 5, applied comparison | Paragraph 52 compares named versions and finds identical wording. | 5 |
| C‑286/24 | 5, general multilingual principle | The model's own category is a general principle. Cited paragraph 31 provides the general multilingual-interpretation rule. | 2 |
| C‑313/24 | 5, applied comparison | The retained material includes specific variants, alongside general interpretive principles. | 5 |
| C‑619/24 | 5, applied comparison | Paragraphs 20–21 attribute the observation to the referring court; paragraph 22 supplies a general principle. Later EU-court reasoning needs inspection. | 3, referring-court comparison |
| T‑69/25 | 5, applied comparison | Paragraph 44 contrasts German/Finnish and other versions of the relevant note. | 5 |
| T‑177/25 | 5, applied comparison | Paragraph 31 compares specific language formulations concerning correction/amendment. | 5 |
| T‑195/25 | 5, applied comparison | Paragraph 79 expressly presents the Commission's submission about English and German wording. That citation alone does not establish the deciding Court's adoption. | 2, party argument |

The official English T‑195/25 judgment was also retrieved through the web research tool and paragraph 79 confirms the attribution to the Commission. The Court's subsequent reasoning must be distinguished from that submission. This review does not claim that the entire case is legally irrelevant. For C‑524/23, official paragraph 72 confirms a French-version wording reference; a low contextual score may still be appropriate, but “no mention” is not an adequate global explanation.

The original raw source files and full model-input packets were not attached. Their complete original selection cannot be reconstructed from the retained evidence alone. Version 0.1.3 records every submitted passage, every packet result, the original score/category when adjusted, and the selection/focus version. Exact matching passages receive priority over frequent generic context words such as “court”.

## Interpretation

The first local AI run demonstrates successful structured inference on the user's machine and short classification times for this nine-document candidate set. It does not establish perfect attribution accuracy. Two clear category/evidence problems and one referring-court ambiguity prompted the additional checks. The remaining plausible positive examples are useful pilot material, not a representative accuracy/recall benchmark.

Supporting machine-readable counts and replay details: `UPLOADED_RUN_REVIEW.json`. The complete private exports are not redistributed with the repository.
