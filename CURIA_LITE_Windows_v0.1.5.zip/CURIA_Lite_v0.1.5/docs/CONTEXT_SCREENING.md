# Contextual evidence checks

The complete context is supplied to the classifier for every topic. Its structured response records the requested actor, evidence actor, and degree of support for the requested action, subject, outcome, negation and conditions. An actor choice can be supplied explicitly, while Automatic leaves interpretation to the model. Local wording patterns provide hints and display previews; they are not the only path to contextual checking.

A general query can use direct_requested_relationship, partial_requested_relationship, contextual_background or contradicted_request. More specific categories distinguish court language comparisons, party arguments, AG reasoning, referring-court observations and quoted precedents. The shared support scale is direct 4–5, partial at most 3, background at most 2, contradicted/absent 1.

Evidence ID checks establish that a passage was supplied. Textual role checks can identify clear party/referring-court statements and express adoption by the deciding court. They remain conservative and preserve original model fields when a display score changes. Positive and negative readings ultimately require source review: this is a research aid, not weight-fine-tuned or legally certified inference.

The old requirement to choose a special preset for certain checks has been removed. The version-comparison preset remains convenient, and specific language checks supplement the general framework. In particular, agreement between specified versions can be a real comparison, whereas correcting one version from its context alone does not establish comparison.

The twelve-example local check in context_check.py exercises diverse questions. It can be run in the UI or via Test_Context_Windows.cmd and stores its own source/expected outcomes, raw answers and diagnostics. The release's software tests use injected responses; the actual model check is performed only when executed on a machine with Ollama and the chosen weights.

Model weights and runtime budgets remain unchanged in v0.1.5. The new prompt version invalidates old classification caches while leaving historical run files intact.

## Targeted evidence review in 0.1.5

Fast screening can schedule one additional reading when a concrete source observation conflicts with a low or partial first rating, or neighbouring passages make the actor unclear. The request remains within the configured byte and output limits. The first answer is retained; the reviewed grade can increase or decrease. A deterministic source cue initiates review rather than assigning a higher grade.

The built-in test now contains twelve artificial examples, adding plural/singular and indefinite-article comparisons, mixed referring/current-court evidence, and a current court’s comparison of versions of an earlier judgment. Test inputs are deliberately small and do not establish corpus-wide legal accuracy.
