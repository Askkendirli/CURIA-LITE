# Keyword operators

Hover an operator or focus it with the keyboard to read its explanation. The preview shows the expressions used by the search.

## Exact phrase

Example input: `language version`. The words "language" and "version" must appear together in that order. Capitalisation and line wrapping do not affect matching. The singular "version" does not match the plural "versions".

## Any word · OR

Example input: `language version`. A document matches when it contains "language", "version", or both, anywhere in the extracted text. The words do not need to be next to each other.

## All words · AND

Example input: `language version`. Both "language" and "version" must occur somewhere in the same document. They may appear in different sentences or in either order.

## Any phrase

Separate phrases with a semicolon: `language version; legal certainty`. At least one complete phrase must occur: "language version", "legal certainty", or both. Finding only the word "language" does not satisfy this example.

## All phrases

Use the same input: `language version; legal certainty`. Both complete phrases are required. The words inside each phrase must stay together; the two phrases themselves can occur in separate paragraphs.

For singular and plural alternatives, choose Any phrase and enter `language version; language versions`. All phrases would instead require both forms.

## Nearby words · NEAR

Example input: `language version`, distance 5. The terms "language" and "version" can occur in either order within one paragraph, with no more than five intervening words. Distance 0 requires adjacency. Two quoted phrases can be used instead of individual words.

## Quotes and exclusions

In word-based operators, `"language version" customs` treats "language version" as one expression and "customs" as another. Double quotes in this input have a functional meaning; the quotes around example words in this guide identify the words being discussed.

Exclude expressions are separated with semicolons. Example: `customs; import duties` removes a document containing either "customs" or the complete phrase "import duties".

## Context and document language

Keywords remain literal filters when a context is supplied. Any word OR can match the footer "Language of the case". The AI then checks the contextual question; a lexical match can still receive low contextual relevance. Clear keywords for a context-only search.

No keyword translation or stemming is performed. "version" is a word in both English and French, so an OR search containing it may legitimately match French text. Whole-word matching and Unicode normalisation are unchanged from v0.1.2.
