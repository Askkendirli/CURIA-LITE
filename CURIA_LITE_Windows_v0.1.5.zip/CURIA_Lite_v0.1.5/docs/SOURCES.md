# Official sources and retrieval

CELLAR supplies discovery metadata and publication content. EUR-Lex and CURIA are explicit recovery providers; embedded-text PDFs are supported. Raw bytes and provider/URL/language/identifier records remain preserved.

## Catalogue and publication tree

The v0.1.3 user log showed HTTP 500 for the expanded SPARQL query for each of the 34 unresolved English documents. That query used unbounded equivalent-identifier paths. The independent publication-tree route was incorrectly placed after a successful catalogue request, so it did not execute when the query failed.

Version 0.1.4 uses a bounded direct-link query and separately attempts the documented RDF-tree route even after catalogue errors. Equivalent identifiers and nested RDF resources are followed locally. A repeated catalogue attempt at the end of the same failed download has been removed. Server response excerpts are retained for future diagnosis.

Advertised source files are tried first and must pass the existing heading, language, type, identifier and date checks. An alternate source's valid file can still be accepted when the CELLAR record leaves it unlisted. Advertised items that fail validation or cannot be read remain retrieval issues. A failed publication notice is not converted into a claim of absence.

The catalogue and tree can establish that a requested file is not listed in the checked source records. Such observations include the check time and actual file languages, remain separate from successfully analysed documents, and expire after the configured interval. Retry refreshes unresolved runs. A count of processed records is not presented as a count of downloaded English judgments.

## Publication languages

The Court's site-language policy explains that some judgments have full text only in the language of the case and the language in which they were drafted, usually French. Titles, summaries and Official Journal notices can be available in English even when the full judgment is not. The downloader must not treat them as substitutes for the requested judgment.

For example, the user-run catalogue for C-206/23 listed Bulgarian and French full-text items, while English expression metadata had no file links. The official search record also distinguishes the judgment from its later Official Journal notice. This supports checking publication status carefully; it does not establish every missing file's current availability without a fresh per-file check.

An explicit additional language can be selected for broader case coverage. The source retains its actual language. The Lite application does not translate case documents.

## Scope and access

Discovery is by decision/document date and selected judicial publication types. It records identifiers, date bounds, source locations, pagination and errors. It does not infer year-wide completeness from one imported document. Requests are rate-limited and restricted to approved official hosts. Visible-browser support can handle permitted interactive verification; access controls are not bypassed.

Actual portal responses change over time. The code contains tested handling for the submitted failures, but the development environment could not make live DNS requests to the source hosts. No new recovery count on the user's machine is asserted.

## Primary documentation consulted 15 October 2026

- Court publication-language policy: https://curia.europa.eu/site/jcms/d2_5170/en/site-language-policy
- CELLAR metadata-tree request: https://op.europa.eu/en/web/cellar/cellar-data/metadata/metadata-notices
- CELLAR WEMI/SPARQL guidance: https://op.europa.eu/en/web/cellar/cellar-data/metadata/knowledge-graph
- Official C-206/23 case listing: https://infocuria.curia.europa.eu/tabs/redirect/juris/liste.jsf?language=en&num=C-206%2F23

Web documentation was consulted separately from the container's unsuccessful direct source probes.


## Reader and format handling in 0.1.5

The Accept header preserves listed PDF/A subtypes, including `application/pdf;type=pdfa2a`, and readable HTML/XHTML items are attempted before PDF when available. A 406 retry is restricted to recognised PDF media types.

A plural `In Cases` header, a heading beginning `ENJUDGMENT`, and the General Court’s abbreviated preliminary-ruling heading are accepted when the accompanying identity and court markers agree. Case references embedded in an introductory subject description are excluded from the own-case heading match.

An all-empty language catalogue is inconclusive and triggers the independent RDF tree. RDF `parseType="Literal"` is treated as a value, without interpreting its embedded markup as links; standard `parseType="Collection"` is supported. XML entity, size, depth and triple-count limits remain enforced. An unsupported value is reported explicitly.

References: CELLAR content documentation, https://op.europa.eu/en/web/cellar/cellar-data/publications ; W3C RDF/XML syntax, https://www.w3.org/TR/rdf-syntax-grammar/ .
