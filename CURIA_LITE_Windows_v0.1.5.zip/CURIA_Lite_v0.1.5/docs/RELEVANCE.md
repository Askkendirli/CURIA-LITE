# Understanding relevance

The visible rating helps prioritise cases for reading. The underlying input passages, model answer and any evidence-check adjustment can be inspected in the browser and JSON export.

## Literal search

An empty context in General search uses the deterministic keyword operators only. Ratings describe the strength of the literal match. Whole-word, phrase, exclusion and proximity rules are documented in KEYWORD_OPERATORS.md. A failed keyword condition excludes that document from the shortlist even when lower ratings are displayed.

## Every contextual search

The full question is supplied to the model. The shared schema identifies the requested actor, the actor supported by the cited evidence, and the extent to which the requested subject, action, outcome, negation and conditions are established. Automatic actor interpretation can be overridden in the form.

- Very low (1): no supporting evidence in the supplied passages, or a contradiction of the requested event.
- Low (2): incidental/background material, or a clearly different actor for an actor-specific question.
- Medium (3): a plausible or partial relationship, with unresolved conditions or actor attribution.
- High (4): direct support for the requested relationship.
- Very high (5): detailed direct support.

A question about an applicant's request can properly give a party submission a high grade. The same passage cannot by itself establish that the deciding court granted the request. A question about refusal must distinguish a refused remedy from a granted one. An earlier judgment quoted by the current court is tracked separately.

## Language-version comparisons

This preset remains convenient, while the same general contextual checks apply to all topics. A specific comparison finding agreement between named versions is just as capable of supporting a high grade as one finding divergence. A general principle concerning multilingual interpretation, a party's comparison, and a correction to a single version from context alone require different treatment.

The application checks clear source-role contradictions and inconsistent structured support. It retains original model fields when an assessment is adjusted. These checks help prevent identifiable mistakes but do not establish legal accuracy on their own.

## Evidence coverage and testing

Fast mode chooses substantive passages before procedural-language footnotes, except when procedural language is the requested topic. Full-text keyword matching is unchanged, so an OR query for "language" can still match "Language of the case". Complete-text mode supplies all extracted blocks in bounded requests.

All actual input passages are retained. A low result based on Fast excerpts is not proof that the entire judgment lacks the phenomenon. Check the fuller source where coverage matters.

The optional twelve-example contextual check uses the selected local model and records its real answers. Software regression tests use controlled responses separately. No weight training was performed for this release.


### Reviewing a conflicting assessment

A concrete comparison can concern grammar, names, punctuation, shared wording or different wording. The review prompt asks what relationship the current court actually examines, including whether a conclusion relies on an earlier court’s text as the object of comparison. It keeps that distinction separate from merely citing an earlier interpretation. A partially supported requested relationship remains Medium; it is not automatically reduced to background.

An additional review is recorded separately from the initial assessment. Both source packets and raw answers are retained. The application does not assign High merely because a comparison marker is found.
