# Examples

`keyword_query.json` searches locally for phrases. The comparison request is intended to run with a small identifier selection:

```powershell
.\.venv\Scripts\python.exe -m curia_lite search examples\comparison_query.json --selection examples\known_cases.json
```

`known_cases.json` supplies official identifiers for a small retrieval trial. `selection_with_metadata.json` illustrates additional inspected fields.

**Load synthetic demo**, or the CLI `demo` command, installs four fictional French, English and German documents for trying the interface. They illustrate an applied comparison, a multilingual principle and a party argument. The documents are clearly labelled and are included only when the demonstration option is selected.
