from __future__ import annotations

import base64
import json
import mimetypes
import re
import secrets
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib.resources import files
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from .common import read_optional_object
from .keywords import KeywordPlan
from .keyword_check import run_keyword_check
from . import __version__
from .demo import install_demo
from .diagnostics import diagnose
from .engine import Jobs
from .settings import load, save
from .store import Store


class Application:
    def __init__(self,home):
        self.home=Path(home).resolve()
        load(self.home)
        self.jobs=Jobs(self.home)
        self.token=secrets.token_hex(24)


def handler_class(app):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,fmt,*args):
            return

        def send(self,value,status=200,ctype='application/json; charset=utf-8',filename=None):
            raw=value if isinstance(value,bytes) else json.dumps(value,ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header('Content-Type',ctype)
            self.send_header('Content-Length',str(len(raw)))
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Referrer-Policy','no-referrer')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self'; object-src 'none'; frame-ancestors 'none'")
            if filename:self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
            self.end_headers()
            self.wfile.write(raw)

        def secure(self,api=False):
            port=self.server.server_port
            allowed={f'127.0.0.1:{port}',f'localhost:{port}'}
            if self.headers.get('Host') not in allowed:
                self.send({'error':'Only loopback host access is allowed.'},403);return False
            origin=self.headers.get('Origin')
            if origin and origin not in {f'http://{x}' for x in allowed}:
                self.send({'error':'Cross-origin requests are not allowed.'},403);return False
            if api and self.headers.get('X-Curia-Token')!=app.token:
                self.send({'error':'Invalid local session token. Reload the application page.'},403);return False
            return True

        def do_GET(self):
            parsed=urlsplit(self.path);path=parsed.path
            if not self.secure(api=path.startswith('/api/')):return
            try:
                if path in {'/','/index.html','/app.js','/style.css'}:
                    name='index.html' if path=='/' else path[1:]
                    raw=files('curia_lite').joinpath('web',name).read_bytes()
                    if name=='index.html':raw=raw.replace(b'__SESSION_TOKEN__',app.token.encode())
                    content_types={'index.html':'text/html','app.js':'application/javascript','style.css':'text/css'}
                    self.send(raw,ctype=content_types[name]+'; charset=utf-8');return
                if path=='/api/config':
                    self.send({'settings':load(app.home),'workspace':str(app.home),'version':__version__});return
                if path=='/api/stats':self.send(Store(app.home).stats());return
                if path=='/api/status':self.send(app.jobs.status());return
                if path=='/api/recent':self.send(app.jobs.recent());return
                if path=='/api/source':
                    id=parse_qs(parsed.query).get('id',[''])[0]
                    meta,text=Store(app.home).read(id)
                    self.send({'metadata':meta,'text':text});return
                match=re.fullmatch(r'/api/run/([a-f0-9]{16})',path)
                if match:
                    value=read_optional_object(app.home/'runs'/match[1]/'results.json')
                    self.send(value if value else {'error':'Run not found.'},200 if value else 404);return
                match=re.fullmatch(r'/api/export/([a-f0-9]{16})/(results.json|shortlist.csv|shortlist.docx)',path)
                if match:
                    p=app.home/'runs'/match[1]/match[2]
                    if not p.is_file():self.send({'error':'Export not found.'},404);return
                    self.send(p.read_bytes(),ctype=mimetypes.guess_type(p.name)[0] or 'application/octet-stream',filename=p.name);return
                self.send({'error':'Not found'},404)
            except Exception as exc:self.send({'error':str(exc)},400)

        def do_POST(self):
            if not self.secure(api=True):return
            try:
                length=int(self.headers.get('Content-Length','0'))
                if length<2 or length>64*1024*1024:raise ValueError('Invalid request size (maximum 64 MiB).')
                data=json.loads(self.rfile.read(length))
                if not isinstance(data,dict):raise ValueError('An object request is required.')
                path=urlsplit(self.path).path
                if path=='/api/settings':
                    if app.jobs.status().get('active'):raise ValueError('Wait for the active search before changing settings.')
                    self.send(save(app.home,data));return
                if path=='/api/keyword-preview':
                    self.send(KeywordPlan.create(data.get('keywords',[]),data.get('logic','phrase'),
                        data.get('exclude',[]),data.get('near_distance',5)).describe());return
                if path=='/api/keyword-check':
                    if app.jobs.status().get('active'):raise ValueError('Wait for the active search before running the keyword check.')
                    self.send(run_keyword_check(app.home,load(app.home)));return
                if path=='/api/search':
                    selection=data.pop('_selection',None)
                    ident=app.jobs.start(load(app.home),data,selection=selection)
                    self.send({'run_id':ident});return
                if path=='/api/retry':
                    ident=data.get('run_id','')
                    if not isinstance(ident,str) or not re.fullmatch(r'[a-f0-9]{16}',ident):
                        raise ValueError('Choose a saved search to retry.')
                    request=read_optional_object(app.home/'runs'/ident/'request.json')
                    prior=read_optional_object(app.home/'runs'/ident/'results.json')
                    if not isinstance(request.get('query'),dict):raise ValueError('The saved search settings could not be read.')
                    query=dict(request['query'])
                    if (not prior.get('discovery',{}).get('complete') or prior.get('unavailable_versions')) and query.get('source_mode')=='auto':
                        query['refresh']=True
                    new_id=app.jobs.start(load(app.home),query,selection=request.get('selection'))
                    self.send({'run_id':new_id});return
                if path=='/api/cancel':
                    app.jobs.cancel.set();self.send({'status':'cancellation-requested'});return
                if path=='/api/diagnostics':
                    sources=bool(data.get('sources'))
                    if sources and app.jobs.status().get('active'):
                        raise ValueError('Finish or stop the current search before checking source access.')
                    self.send(diagnose(app.home,load(app.home),models=not sources,smoke=bool(data.get('smoke')),
                                       sources=sources,source_language=data.get('language','en'),
                                       celex=data.get('celex','62024CJ0313')));return
                if path=='/api/demo':
                    if app.jobs.status().get('active'):raise ValueError('Wait for the active search before importing.')
                    self.send({'imported':len(install_demo(Store(app.home)))});return
                if path=='/api/import':
                    if app.jobs.status().get('active'):raise ValueError('Wait for the active search before importing.')
                    sources=data.get('files')
                    if not isinstance(sources,list):raise ValueError('A file list is required.')
                    store=Store(app.home);result={'imported':[],'failed':[]}
                    for item in sources:
                        try:
                            raw=base64.b64decode(item['data'],validate=True)
                            if len(raw)>load(app.home)['max_file_mb']*1024*1024:raise ValueError('Imported file exceeds max_file_mb.')
                            meta=store.ingest(raw,language=item.get('language',''),celex=item.get('celex',''),
                                side=item.get('metadata',{}),filename=item.get('name',''))
                            result['imported'].append(meta)
                        except Exception as exc:result['failed'].append({'name':item.get('name',''),'error':str(exc)})
                    self.send(result);return
                self.send({'error':'Not found'},404)
            except Exception as exc:self.send({'error':str(exc)},400)
    return Handler


def serve(home: Path,port=8765,open_browser=True):
    app=Application(home)
    server=ThreadingHTTPServer(('127.0.0.1',port),handler_class(app))
    server.daemon_threads=True
    url=f'http://127.0.0.1:{server.server_port}'
    print(f'CURIA LITE: {url}\nWorkspace: {app.home}\nKeep this window open. Ctrl+C stops the local server.')
    if open_browser:threading.Timer(0.7,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:
        app.jobs.cancel.set();server.server_close()
