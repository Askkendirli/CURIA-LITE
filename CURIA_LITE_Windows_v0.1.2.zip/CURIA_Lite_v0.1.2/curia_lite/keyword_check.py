"""A small offline acceptance check that runs the real archive and export pipeline."""
from __future__ import annotations
import html
import tempfile
from pathlib import Path
from .common import utc_now, write_json

FIXTURES = [
    ('en',9001,'The language version sets out the customs rule.'),
    ('en',9002,'The language of the request differs from the version of the rule.'),
    ('en',9003,'The language determines the applicable wording.'),
    ('en',9004,'This version provides the applicable wording.'),
    ('en',9005,'The language versions are discussed together.'),
    ('fr',9006,'Le tribunal analyse les versions linguistiques de la règle.'),
    ('fr',9007,'La version française précise la règle applicable.'),
]


def fixture(language,number,body):
    title='JUDGMENT OF THE COURT' if language=='en' else 'ARRÊT DE LA COUR'
    date='15 January 2025' if language=='en' else '15 janvier 2025'
    own='In Case' if language=='en' else 'Dans l’affaire'
    filler=('This fictional material is included solely to check the search controls and source handling. ' if language=='en' else
            'Ce document fictif est fourni pour vérifier le fonctionnement des contrôles de recherche et le traitement des sources. ')
    return (f'<html lang="{language}"><body><h1>{title}</h1><p>{date}</p><p>{own} C-{number}/25</p>'
            f'<p>SYNTHETIC DEMO</p><p>DEMO Applicant</p><p>1 {html.escape(body)}</p><p>2 {filler*3}</p></body></html>').encode()


def run_keyword_check(home,config):
    from .engine import execute
    from .store import Store
    class NoModel:
        def ready(self):raise AssertionError('The keyword check attempted to call a model.')
    checks = [
        ('Exact phrase in English','en','phrase','language version',[],5,[9001]),
        ('Exact phrase in French','fr','phrase','language version',[],5,[]),
        ('English-only word in French','fr','any_words','language',[],5,[]),
        ('Any word in English','en','any_words','language version',[],5,[9001,9002,9003,9004,9005]),
        ('All words in English','en','all_words','language version',[],5,[9001,9002]),
        ('Two phrases','en','all_phrases','language version; customs',[],5,[9001]),
        ('Quoted OR expression','en','any_words','"language version" customs',[],5,[9001]),
        ('Exclude a word','en','any_words','language version',['customs'],5,[9002,9003,9004,9005]),
        ('Adjacent NEAR','en','near','language version',[],0,[9001]),
        ('Shared French/English spelling','fr','any_words','version',[],5,[9007]),
    ]
    output={'at':utc_now(),'release':'0.1.2','source':'synthetic fixtures','network_calls':0,'model_calls':0,'checks':[]}
    with tempfile.TemporaryDirectory(prefix='curia-keyword-check-') as temporary:
        store=Store(Path(temporary))
        for lang,num,body in FIXTURES:
            store.ingest(fixture(lang,num,body),language=lang,celex=f'62025CJ{num}',side={'is_demo':True})
        for name,lang,logic,words,exclude,distance,expected in checks:
            q={'source_mode':'local','languages':[lang],'query_language':'en','keywords':words,
               'logic':logic,'exclude':exclude,'near_distance':distance,'min_score':1,'include_demo':True}
            try:
                result=execute(store.home,config,q,client=NoModel())
                found=sorted(int(d['case_numbers'][0].split('-')[1].split('/')[0]) for d in result['documents'] if d['status']=='assessed')
                ok=found==expected and not result['failures'] and result['summary']['model_calls']==0
                output['checks'].append({'name':name,'passed':ok,'expected':expected,'observed':found,
                    'operator':result['keyword_definition'],'failures':result['failures']})
            except Exception as exc:output['checks'].append({'name':name,'passed':False,'error':str(exc)})
    output['passed']=all(c['passed'] for c in output['checks'])
    output['status']='passed' if output['passed'] else 'failed'
    write_json(Path(home)/'diagnostics'/'keyword-check.json',output)
    return output
