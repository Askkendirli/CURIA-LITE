from __future__ import annotations

import csv
import io
import json
import re
from pathlib import Path

from docx import Document
from docx.shared import Cm, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

from .keywords import OPERATORS, LEGACY
from .common import atomic_write, write_json


def selected_cases(result):
    q=result['query']
    # The document assessments and unresolved entries remain in the JSON even when the visible list is filtered.
    return [{**c,'documents':[d for d in c['documents'] if d.get('status')!='keyword-excluded']}
            for c in result['cases'] if c.get('score') is not None and c['score']>=q['min_score']
            and any(d.get('status') in {'assessed','partial-assessment'} for d in c['documents'])]


def csv_cell(value):
    s=str(value or '')
    # Formula-like strings are escaped for safe spreadsheet opening; JSON remains lossless.
    return "'"+s if s.lstrip().startswith(('=','+','-','@','\t','\r')) else s


def xml_text(value):
    """Control characters forbidden by XML are excluded from the Word representation."""
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]", "", str(value or ""))


def word_view(value):
    if isinstance(value, str):
        return xml_text(value)
    if isinstance(value, list):
        return [word_view(item) for item in value]
    if isinstance(value, dict):
        return {key: word_view(item) for key,item in value.items()}
    return value


def write_exports(result: dict, directory: Path):
    directory.mkdir(parents=True,exist_ok=True)
    cases=selected_cases(result)
    q=result['query']
    write_json(directory/'results.json',result)
    stream=io.StringIO(newline='')
    fields=['case_numbers','case_name','relevance','document_type','date','language','ecli','celex','status','basis','reason','source_url']
    writer=csv.DictWriter(stream,fieldnames=fields); writer.writeheader()
    for case in cases:
        for d in case['documents']:
            writer.writerow({k:csv_cell(v) for k,v in {
                'case_numbers':' ; '.join(case['case_numbers']),'case_name':d.get('case_name'),
                'relevance':d.get('label'),'document_type':d.get('doc_type'),'date':d.get('delivery_date'),
                'language':d.get('retrieval_language'),'ecli':d.get('ecli'),'celex':d.get('celex'),
                'status':d.get('status'),'basis':d.get('basis'),'reason':d.get('reason'),
                'source_url':d.get('resolved_url') or d.get('source_url')}.items()})
    atomic_write(directory/'shortlist.csv',b'\xef\xbb\xbf'+stream.getvalue().encode('utf-8'))
    result=word_view(result)
    q=result['query']
    cases=selected_cases(result)
    doc=Document()
    sec=doc.sections[0]
    sec.page_width=Cm(21);sec.page_height=Cm(29.7)
    sec.top_margin=sec.bottom_margin=Cm(1.8);sec.left_margin=sec.right_margin=Cm(2)
    normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(10)
    normal.paragraph_format.space_after=Pt(5)
    doc.core_properties.author='Ahmet Şadan Kutay Kendirli'
    doc.core_properties.title='CURIA LITE — Case shortlist'
    doc.add_heading('CURIA LITE',0)
    doc.add_paragraph('CASE SHORTLIST',style='Subtitle')
    if any(d.get('is_demo') for c in cases for d in c['documents']):
        doc.add_paragraph('SYNTHETIC DEMONSTRATION — this list includes fictional training examples.')
    status={'completed-selected-snapshot':'Search complete','completed-local-subset':'Local search complete','completed-with-unavailable-versions':'Search complete; some language versions are unavailable','partial':'Some items need attention','cancelled':'Search stopped','failed':'Search interrupted'}.get(result['status'],result['status'])
    doc.add_paragraph(f"Run {result['run_id']} | {result['started_at']} | {status}")
    doc.add_paragraph(f"Decision dates: {q['date_from'] or 'open'} to {q['date_to'] or 'open'} | Versions: {', '.join(q['languages'])}")
    doc.add_paragraph(f"Keywords — {OPERATORS.get(LEGACY.get(q['logic'],q['logic']), (q['logic'],''))[0]}: {'; '.join(q['keywords']) or '(none)'}\nExclude: {'; '.join(q.get('exclude',[])) or '(none)'}\nBrief context: {q['context'] or '(none)'}\nPreset: {q['preset']} | Screening: {q['depth']}")
    doc.add_paragraph(f"{len(cases)} case group{'s' if len(cases)!=1 else ''} {'meet' if len(cases)!=1 else 'meets'} the displayed threshold ({q['min_score']}/5). "
                      f"{len(result.get('failures',[]))} retrieval/processing failures; "
                      f"{len(result.get('metadata_unresolved',[]))} documents require metadata. "
                      'The five relevance levels help prioritise reading. Review the cited passages before using a case in research.')
    if result.get('unavailable_versions'):
        doc.add_paragraph(f"{len(result['unavailable_versions'])} requested language versions are unlisted or unavailable as HTML in the source catalogue. The JSON export contains the availability details.")
    if result.get('warnings'):
        doc.add_paragraph(' | '.join(result['warnings']))
    table=doc.add_table(rows=1,cols=4); table.style='Light Shading Accent 1'
    for c,t in zip(table.rows[0].cells,['Case','Date / type','Version','Relevance']): c.text=t
    trPr=table.rows[0]._tr.get_or_add_trPr(); header=OxmlElement('w:tblHeader'); trPr.append(header)
    for case in cases:
        best=next(d for d in case['documents'] if d['doc_id']==case['best_document'])
        cells=table.add_row().cells
        for cell,text in zip(cells,[' / '.join(case['case_numbers']),
                f"{best.get('delivery_date','')}\n{best.get('doc_type','')}",
                ', '.join(sorted({d['retrieval_language'] for d in case['documents']})),case['label']]): cell.text=text
        p=OxmlElement('w:cantSplit'); cells[0]._tc.getparent().get_or_add_trPr().append(p)
    for case in cases:
        doc.add_heading(' / '.join(case['case_numbers']),2)
        doc.add_paragraph(case['case_name'][:450])
        for d in case['documents']:
            doc.add_paragraph(f"{'SYNTHETIC DEMO · ' if d.get('is_demo') else ''}{d.get('retrieval_language','')} · {d.get('doc_type','')} · {d.get('delivery_date','')} · {d.get('label','Not assessed')} · {d.get('status','')}")
            doc.add_paragraph(d.get('reason',''))
            for e in d.get('evidence',[])[:2]:
                location=f"paragraph {e['paragraph']}" if e.get('paragraph') else f"extracted block {e['id']}"
                doc.add_paragraph(f"[{location}] {e['text'][:600]}")
            ident=' | '.join(x for x in [d.get('ecli'),d.get('celex'),d.get('resolved_url') or d.get('source_url')] if x)
            if ident: doc.add_paragraph(ident)
    if result.get('failures') or result.get('metadata_unresolved'):
        doc.add_heading('Documents needing attention',1)
        for failure in result.get('failures',[]):
            doc.add_paragraph(f"{failure.get('celex') or failure.get('doc_id','')} {failure.get('language','')}: {failure.get('error','')}")
        for meta in result.get('metadata_unresolved',[]):
            doc.add_paragraph(f"{meta.get('case_id','')}: missing {', '.join(meta.get('missing_fields',[]))}")
    buffer=io.BytesIO();doc.save(buffer)
    atomic_write(directory/'shortlist.docx',buffer.getvalue())
    return {'json':'results.json','csv':'shortlist.csv','docx':'shortlist.docx'}
