from __future__ import annotations

import platform
import sqlite3
import sys
import tempfile
from pathlib import Path

from .common import utc_now, write_json
from .screening import Ollama


def diagnose(home: Path, config: dict, *, models=False, smoke=False, sources=False, source_language="en", celex="62024CJ0313"):
    result={'at':utc_now(),'python':sys.version,'platform':platform.platform(),'checks':{}}
    checks=result['checks']
    home.mkdir(parents=True,exist_ok=True)
    try:
        with tempfile.TemporaryDirectory(prefix='.preflight-',dir=home) as temp:
            p=Path(temp)/'storage.sqlite3'
            con=sqlite3.connect(p)
            try:
                con.execute('CREATE TABLE probe (value TEXT)')
                con.execute('INSERT INTO probe VALUES (?)',('français – sécurité juridique',));con.commit()
                assert con.execute('SELECT value FROM probe').fetchone()[0]=='français – sécurité juridique'
            finally:con.close()
            p.rename(p.with_suffix('.closed'))
        checks['sqlite_storage']={'status':'passed'}
    except Exception as exc:checks['sqlite_storage']={'status':'failed','error':str(exc)}
    try:
        from docx import Document
        import bs4, requests
        checks['dependencies']={'status':'passed'}
    except Exception as exc:checks['dependencies']={'status':'failed','error':str(exc)}
    checks['ollama']={'status':'not-run'}
    checks['real_inference']={'status':'not-run'}
    if models or smoke:
        try:
            client=Ollama(config); model_digest=client.ready()
            checks['ollama']={'status':'passed','model':config['model'],'digest':model_digest}
            if smoke:
                value,metrics=client.chat([{'role':'user','content':'Run a brief connection test. Return {"score":1,"category":"no_evidence","evidence":[],"reason":"Interface test completed"}.'}])
                if value.get('score')!=1 or value.get('category')!='no_evidence':
                    raise ValueError('The model did not produce the expected smoke-test structure.')
                checks['real_inference']={'status':'passed','response':value,'metrics':metrics}
        except Exception as exc:
            checks['real_inference' if smoke else 'ollama']={'status':'failed','error':str(exc)}
    checks['source_access']={'status':'not-run'}
    if sources:
        from .sources import Network, fetch_record
        from .extractor import html_content, parse_metadata
        network=Network(config)
        try:
            raw,requested,resolved=fetch_record({'celex':celex},source_language,config,network)
            text,detected=html_content(raw.decode('utf-8-sig'))
            meta=parse_metadata(text,celex_hint=celex,retrieval_language=source_language)
            checks['source_access']={'status':'passed','celex':celex,'language':detected,'bytes':len(raw),
                                     'characters':len(text),'case':meta['case_id'],
                                     'requested_url':requested,'resolved_url':resolved}
        except Exception as exc:
            checks['source_access']={'status':'failed','celex':celex,'language':source_language,
                                     'error':str(exc),'attempts':getattr(exc,'attempts',[])}
        checks['source_access']['network_trace']=network.trace()
        write_json(home/'diagnostics'/'source-check.json',checks['source_access'])
    result['ok']=not any(c['status']=='failed' for c in checks.values())
    return result
