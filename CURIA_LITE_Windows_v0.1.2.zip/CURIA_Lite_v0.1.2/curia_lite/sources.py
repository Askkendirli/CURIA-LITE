from __future__ import annotations

import datetime as dt
import json
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlencode, urljoin, urlsplit, parse_qsl, urlunsplit

import requests
from bs4 import BeautifulSoup

from .common import digest, trusted_url, utc_now, write_json
from .extractor import CELEX, html_content, parse_metadata, document_heading
from .query import Query

ENDPOINT = 'https://publications.europa.eu/webapi/rdf/sparql'
LANG3 = dict(zip('bg es cs da de et el en fr ga hr it lv lt hu mt nl pl pt ro sk sl fi sv'.split(),
                'bul spa ces dan deu est ell eng fra gle hrv ita lav lit hun mlt nld pol por ron slk slv fin swe'.split()))
KINDS = {'CJ':'judgment','CC':'opinion','CO':'order','TJ':'judgment','TO':'order','FJ':'judgment','FO':'order'}


class Cancelled(RuntimeError):
    pass


class Network:
    """Request approved official sources and retain a per-thread redirect history."""
    def __init__(self, config, cancel=None):
        self.c=config;self.cancel=cancel or threading.Event();self.lock=threading.Lock()
        self.next_request=0.0;self.local=threading.local()

    def check(self):
        if self.cancel.is_set():
            raise Cancelled('Search stopped. Completed downloads are saved.')

    def reset_trace(self):
        self.local.trace=[]

    def trace(self):
        return list(getattr(self.local,'trace',[]))

    def note(self,**values):
        if not hasattr(self.local,'trace'):self.reset_trace()
        self.local.trace.append({'at':utc_now(),**values})

    def get(self, url, *, params=None, headers=None):
        if params:url += ('&' if '?' in url else '?')+urlencode(params)
        with requests.Session() as session:
            session.headers['User-Agent']='CURIA-Lite/0.1.2 (scholarly case-law research)'
            for attempt in range(3):
                try:current=trusted_url(url,cellar=True)
                except ValueError as exc:
                    self.note(requested_url=url,error=str(exc));raise
                visited=set()
                for redirect in range(8):
                    self.check()
                    if current in visited:
                        self.note(requested_url=url,url=current,error='Redirect loop')
                        raise ValueError(f'The source repeated a redirect to {current}.')
                    visited.add(current)
                    with self.lock:
                        wait=max(0,self.next_request-time.monotonic())
                        if self.cancel.wait(wait):self.check()
                        self.next_request=time.monotonic()+self.c['request_interval']
                    try:
                        response=session.get(current,headers=headers or {},allow_redirects=False,stream=True,
                                             timeout=(10,self.c['network_timeout']))
                    except requests.RequestException as exc:
                        self.note(requested_url=url,url=current,attempt=attempt+1,error=str(exc))
                        if isinstance(exc,(requests.Timeout,requests.ConnectionError)) and attempt<1:
                            self.cancel.wait(1);self.check();break
                        raise
                    with response:
                        info={'requested_url':url,'url':current,'attempt':attempt+1,'status':response.status_code,
                              'accept':(headers or {}).get('Accept',''),'language':(headers or {}).get('Accept-Language','')}
                        if response.status_code in {301,302,303,307,308}:
                            location=response.headers.get('Location','')
                            info['location']=location
                            if not location:
                                self.note(**info,error='Redirect has no destination')
                                raise ValueError('The source returned a redirect without a destination.')
                            try:next_url=trusted_url(urljoin(current,location),cellar=True)
                            except ValueError as exc:
                                self.note(**info,error=str(exc));raise
                            self.note(**info,next_url=next_url)
                            current=next_url;continue
                        self.note(**info)
                        if response.status_code in {429,502,503,504} and attempt<2:
                            retry=response.headers.get('Retry-After','3')
                            delay=min(60,int(retry)) if retry.isdigit() else 3*(attempt+1)
                            self.cancel.wait(delay);break
                        response.raise_for_status()
                        chunks=[];size=0;started=time.monotonic()
                        for block in response.iter_content(65536):
                            self.check()
                            if time.monotonic()-started>self.c['network_timeout']*2:
                                raise TimeoutError('The document transfer took too long. Retry this item or reduce the date range.')
                            size+=len(block)
                            if size>self.c['max_file_mb']*1024*1024:
                                raise ValueError('The document exceeds the file-size limit in Settings.')
                            chunks.append(block)
                        data=b''.join(chunks)
                        if not data:raise ValueError('The source returned an empty file. Another document address will be checked.')
                        return data,current,dict(response.headers)
                else:
                    raise ValueError('The source returned too many redirects.')
            raise RuntimeError('The source is still unavailable after three attempts. Retry the download later.')


def type_codes(q: Query):
    return [k for k,v in KINDS.items() if k[0] in q.courts and v in q.types]


DISCOVERY_VERSION = 2
PAGE_SIZE = 200


def discovery_query(q: Query, offset=0, count=False, *, cursor=None):
    """Page by stable document identifiers; preserve the available CELLAR locations."""
    codes = '|'.join(type_codes(q)) or 'NO_MATCH'
    extra = ''
    celex = q.filters.get('celex','').upper()
    if celex:
        if not CELEX.fullmatch(celex):
            raise ValueError('Enter a valid case-law CELEX identifier.')
        extra = 'FILTER(?celex = '+json.dumps(celex)+')'
    body = f'''?work cdm:resource_legal_id_celex ?identifier; cdm:work_date_document ?documentDate.
    BIND(STR(?identifier) AS ?celex)
    BIND(SUBSTR(STR(?documentDate),1,10) AS ?date)
    FILTER(?date >= "{q.date_from}" && ?date <= "{q.date_to}")
    FILTER(REGEX(?celex, "^6[0-9]{{4}}({codes})[0-9]{{4}}$")) {extra}'''
    prefix = 'PREFIX cdm: <http://publications.europa.eu/ontology/cdm#>\n'
    if count:
        return prefix + 'SELECT (COUNT(*) AS ?total) WHERE { { SELECT DISTINCT ?celex ?date WHERE { '+body+' } } }'
    if cursor:
        key, day = cursor
        if not CELEX.fullmatch(key):
            raise ValueError('The discovery cursor contains an invalid identifier.')
        dt.date.fromisoformat(day)
        body += '\nFILTER(?celex > '+json.dumps(key)+' || (?celex = '+json.dumps(key)+' && ?date > '+json.dumps(day)+'))'
    # The former offset argument is accepted for API compatibility, but discovery uses a cursor.
    if offset and cursor is None:
        raise ValueError('Discovery resumes from its last document identifier. A numeric offset is no longer used.')
    return (prefix + 'SELECT ?celex ?date (GROUP_CONCAT(DISTINCT STR(?work); separator="|") AS ?work_uris) WHERE { '
            + body + ' } GROUP BY ?celex ?date ORDER BY ?celex ?date LIMIT '+str(PAGE_SIZE))


def merge_records(records):
    """Equivalent source locations are retained together under one CELEX identifier."""
    merged = {}
    for raw in records:
        if not isinstance(raw, dict) or not isinstance(raw.get('celex'), str) or not CELEX.fullmatch(raw['celex'].upper()):
            raise ValueError('Each selected document needs a valid case-law CELEX identifier.')
        record = dict(raw); record['celex'] = record['celex'].upper()
        if record.get('delivery_date'):
            dt.date.fromisoformat(record['delivery_date'])
        uris = record.get('work_uris', [])
        if not isinstance(uris, list) or any(not isinstance(x, str) for x in uris):
            raise ValueError('work_uris must be a list of CELLAR resource addresses.')
        uris = ([record['work_uri']] if record.get('work_uri') else []) + uris
        for u in uris:
            safe = trusted_url(u, cellar=True)
            parsed = urlsplit(safe)
            if parsed.hostname != 'publications.europa.eu' or not parsed.path.startswith('/resource/cellar/'):
                raise ValueError('A CELLAR work location must identify a Publications Office resource.')
        record['work_uris'] = list(dict.fromkeys(uris))
        if uris:record['work_uri'] = uris[0]
        for key in ['curia_url','source_url']:
            if record.get(key):record[key] = trusted_url(record[key],cellar=True)
        previous = merged.get(record['celex'])
        if previous:
            a,b=previous.get('delivery_date'),record.get('delivery_date')
            if a and b and a!=b:
                raise ValueError(f'Conflicting document dates for {record["celex"]}: {a} / {b}.')
            previous['work_uris']=list(dict.fromkeys(previous.get('work_uris',[])+record['work_uris']))
            if previous['work_uris']:previous['work_uri']=previous['work_uris'][0]
            for key,value in record.items():
                if not previous.get(key) and value:previous[key]=value
        else:
            merged[record['celex']]=record
    return list(merged.values())


def discover(q: Query, config, store, network: Network, progress):
    scope = [q.date_from,q.date_to,sorted(type_codes(q)),q.filters.get('celex','').upper()]
    prefix = 'discovery-v2:'
    key = prefix+digest(json.dumps(scope))
    old = store.cached(key)
    if not q.refresh:
        options = ([old] if isinstance(old,dict) else []) + store.cached_objects(prefix)
        for candidate in options:
            previous=candidate.get('scope',[])
            if not candidate.get('complete') or candidate.get('discovery_version')!=DISCOVERY_VERSION or len(previous)!=4:
                continue
            try:
                age=(dt.datetime.now(dt.timezone.utc)-dt.datetime.fromisoformat(candidate['at'])).total_seconds()/3600
                usable=(0<=age<config['discovery_ttl_hours'] and previous[0]<=scope[0] and previous[1]>=scope[1]
                        and set(scope[2])<=set(previous[2]) and (not previous[3] or previous[3]==scope[3]))
                if not usable:continue
                rows=[r for r in candidate['records'] if scope[0]<=r['delivery_date']<=scope[1]
                      and r['celex'][5:7] in scope[2] and (not scope[3] or r['celex']==scope[3])]
                rows=merge_records(rows)
            except (ValueError,KeyError,TypeError):
                continue
            progress('discovery',f'Using saved search details for {len(rows)} documents.')
            return {**candidate,'scope':scope,'parent_scope':previous,'records':rows,'expected':len(rows),'cached':True}
    manifest = {'scope':scope,'at':utc_now(),'complete':False,'cached':False,'records':[],'errors':[],
                'source':'CELLAR document metadata','discovery_version':DISCOVERY_VERSION,
                'pagination':'document-key-cursor','duplicate_rows_ignored':0}
    auditdir = store.home/'discovery'/('v2-'+digest(json.dumps(scope))[:16])
    def fetch(count=False,page=0,cursor=None):
        sparql = discovery_query(q,count=count,cursor=cursor)
        from .common import atomic_write
        filename=('count-'+str(page)) if count else ('page-'+str(page))
        atomic_write(auditdir/(filename+'.rq'),sparql)
        data,_,_ = network.get(ENDPOINT,params={'query':sparql,'format':'application/sparql-results+json'},
                              headers={'Accept':'application/sparql-results+json','Cache-Control':'no-cache'})
        obj=json.loads(data)
        write_json(auditdir/(filename+'.json'),obj)
        return obj['results']['bindings']
    try:
        total=int(fetch(True,0)[0]['total']['value']);manifest['expected']=total
        seen=set();cursor=None;finished=False;stalled=0
        for page in range(10000):
            network.check() if hasattr(network,'check') else None
            rows=fetch(False,page,cursor)
            if not rows:
                finished=True;break
            before=cursor;batch=[]
            for row in rows:
                celex,date=row['celex']['value'],row['date']['value'][:10]
                if not CELEX.fullmatch(celex) or not q.date_from<=date<=q.date_to or celex[5:7] not in type_codes(q):
                    raise ValueError('A search response contained an unexpected document identifier or date.')
                dt.date.fromisoformat(date)
                k=(celex,date)
                locations=row.get('work_uris',{}).get('value','').split('|')
                locations=[x for x in locations if x]
                if row.get('work'):locations.append(row['work']['value'])
                record={'celex':celex,'delivery_date':date,'work_uris':list(dict.fromkeys(locations))}
                if locations:record['work_uri']=locations[0]
                if k in seen or (before is not None and k<=before):
                    manifest['duplicate_rows_ignored']+=1
                    # Useful alternative locations on an overlapping page are still retained.
                    if k in seen:batch.append(record)
                    continue
                seen.add(k);batch.append(record)
                if cursor is None or k>cursor:cursor=k
            manifest['records']=merge_records(manifest['records']+batch)
            progress('discovery',f'Found {len(manifest["records"])} of {total} document records.')
            manifest['last_cursor']=list(cursor) if cursor else None
            write_json(auditdir/'latest.json',manifest)
            if cursor==before:
                stalled+=1
                if stalled>=2:
                    manifest['errors'].append('The source repeated the same page. The saved records can be retried after refreshing the search.')
                    break
            else:stalled=0
        else:
            manifest['errors'].append('The search reached its 10,000-page safety limit. Select a shorter date range to continue.')
        after=int(fetch(True,1)[0]['total']['value']);manifest['expected_after']=after
        manifest['complete']=finished and len(seen)==total==after and not manifest['errors']
        if not manifest['complete'] and not manifest['errors']:
            manifest['errors'].append(f'The source catalogue changed during this search: {total} records initially, {after} afterwards, {len(seen)} collected. Refresh to check again.')
    except Cancelled:
        raise
    except Exception as exc:
        manifest['errors'].append(str(exc))
    write_json(auditdir/'latest.json',manifest)
    if manifest['complete']:store.cache(key,manifest)
    return manifest


def manifest_records(data):
    records=data if isinstance(data,list) else data.get('records') if isinstance(data,dict) else None
    if not isinstance(records,list):
        raise ValueError('The selection file needs a records list.')
    return merge_records(records)


def browser_fetch(url, config, cancel, headers=None):
    """An optional visible browser is used without bypassing challenges or policies."""
    from playwright.sync_api import sync_playwright
    url=trusted_url(url,cellar=True)
    with sync_playwright() as pw:
        opts={'headless':False}
        if config['browser_executable']:
            opts['executable_path']=config['browser_executable']
        browser=pw.chromium.launch(**opts)
        try:
            page=browser.new_page(extra_http_headers=headers or {})
            page.goto(url,wait_until='domcontentloaded',timeout=config['network_timeout']*1000)
            deadline=time.monotonic()+90
            while time.monotonic()<deadline:
                if cancel.is_set():
                    raise Cancelled('Browser retrieval cancelled.')
                raw=page.content()
                text,_=html_content(raw)
                if re.search(r'arr[eê]t|judgment|urteil|sentenza|sentencia|acórdão|arrest van|conclusions|schlussantr',text[:3000],re.I):
                    return raw.encode('utf-8'),trusted_url(page.url,cellar=True),{}
                page.wait_for_timeout(750)
            raise TimeoutError('No valid document appeared. Save official HTML manually and import it; the failed item remains visible.')
        finally:
            browser.close()


def curia_language_url(url, lang):
    """Requested source language is carried into each discovered CURIA document URL."""
    parts = urlsplit(trusted_url(url))
    params = dict(parse_qsl(parts.query))
    params.update(doclang=lang.upper(), language=lang)
    return urlunsplit(parts._replace(query=urlencode(params)))


class DownloadError(ValueError):
    def __init__(self,celex,lang,attempts):
        self.attempts=attempts
        reasons=list(dict.fromkeys(a.get('error','') for a in attempts if a.get('error')))
        details='; '.join(reasons[-3:])
        super().__init__(f'Could not retrieve {celex} ({lang}). '+details)


def cellar_item_query(record,lang):
    """Resolve published HTML items for the requested language through the WEMI links."""
    celex=record['celex']
    if not CELEX.fullmatch(celex):raise ValueError('Invalid CELEX identifier.')
    code=LANG3[lang].upper()
    # These URI values identify RDF resources; HTTPS is applied when a download is requested.
    return f'''PREFIX cdm: <http://publications.europa.eu/ontology/cdm#>
PREFIX owl: <http://www.w3.org/2002/07/owl#>
SELECT DISTINCT ?item ?format WHERE {{
 {{ ?work cdm:resource_legal_id_celex "{celex}" . }}
 UNION {{ ?work owl:sameAs <http://publications.europa.eu/resource/celex/{celex}> . }}
 ?expression cdm:expression_belongs_to_work ?work ;
             cdm:expression_uses_language <http://publications.europa.eu/resource/authority/language/{code}> .
 ?manifestation cdm:manifestation_manifests_expression ?expression ; cdm:manifestation_type ?format .
 ?item cdm:item_belongs_to_manifestation ?manifestation .
 FILTER(REGEX(LCASE(STR(?format)), "(^|[/#])(x?html)([_-](simplified|conv))?$"))
}} ORDER BY STR(?item) LIMIT 100'''


def resolve_cellar_items(record,lang,network):
    data,_,_=network.get(ENDPOINT,params={'query':cellar_item_query(record,lang),'format':'application/sparql-results+json'},
                         headers={'Accept':'application/sparql-results+json'})
    rows=json.loads(data)['results']['bindings']
    urls=[]
    for row in rows:
        value=row.get('item',{}).get('value','')
        target=trusted_url(value,cellar=True)
        if urlsplit(target).hostname!='publications.europa.eu' or not urlsplit(target).path.startswith('/resource/'):
            raise ValueError('The metadata service returned an unexpected document address.')
        if target not in urls:urls.append(target)
    return urls


class VersionUnavailable(ValueError):
    def __init__(self,celex,language,catalogue,attempts):
        self.attempts=attempts;self.catalogue=catalogue
        self.reason_code='language-not-listed' if language not in catalogue['languages'] else 'html-not-listed'
        self.available_languages=sorted(catalogue['languages'])
        self.formats=catalogue['languages'].get(language,{}).get('formats',[])
        detail='The requested language is not listed in the source catalogue.' if self.reason_code=='language-not-listed' else 'The source catalogue lists this language in other formats; HTML and XHTML are unavailable.'
        super().__init__(f'{celex} ({language}): {detail}')


def catalogue_query(record):
    """Request the published language/format map for one exact document."""
    celex=record['celex']
    if not CELEX.fullmatch(celex):raise ValueError('Invalid CELEX identifier.')
    locations=[]
    for value in record.get('work_uris',[]) + ([record['work_uri']] if record.get('work_uri') else []):
        value=trusted_url(value,cellar=True)
        parts=urlsplit(value)
        if parts.hostname!='publications.europa.eu' or not re.fullmatch(r'/resource/cellar/[a-zA-Z0-9-]+',parts.path):
            raise ValueError('Invalid CELLAR work identifier.')
        locations.append('http://publications.europa.eu'+parts.path)
    exact=json.dumps(celex)
    candidates='{{ ?work cdm:resource_legal_id_celex ?id . FILTER(STR(?id) = '+exact+') }}'
    candidates+=' UNION {{ ?work owl:sameAs <http://publications.europa.eu/resource/celex/'+celex+'> }}'
    candidates+=' UNION {{ <http://publications.europa.eu/resource/celex/'+celex+'> owl:sameAs ?work }}'
    if locations:candidates+=' UNION {{ VALUES ?work {{ '+' '.join('<'+u+'>' for u in dict.fromkeys(locations))+' }} }}'
    # The braces above are ordinary SPARQL braces; no string-template evaluation follows.
    candidates=candidates.replace('{{','{').replace('}}','}')
    return '''PREFIX cdm: <http://publications.europa.eu/ontology/cdm#>
PREFIX owl: <http://www.w3.org/2002/07/owl#>
SELECT DISTINCT ?work ?expression ?language ?format ?item WHERE {
 { '''+candidates+''' }
 { ?expression cdm:expression_belongs_to_work ?work } UNION { ?work cdm:work_has_expression ?expression }
 ?expression cdm:expression_uses_language ?language .
 OPTIONAL {
  { ?manifestation cdm:manifestation_manifests_expression ?expression }
  UNION { ?expression cdm:expression_manifested_by_manifestation ?manifestation }
  OPTIONAL { ?manifestation cdm:manifestation_type ?format }
  OPTIONAL { { ?item cdm:item_belongs_to_manifestation ?manifestation }
             UNION { ?manifestation cdm:manifestation_has_item ?item } }
 }
} ORDER BY ?language ?format ?item'''


def resolve_catalogue(record,network):
    query=catalogue_query(record)
    raw,_,_=network.get(ENDPOINT,params={'query':query,'format':'application/sparql-results+json'},
                       headers={'Accept':'application/sparql-results+json'})
    rows=json.loads(raw)['results']['bindings']
    if not isinstance(rows,list):raise ValueError('The publication catalogue returned invalid rows.')
    result={'celex':record['celex'],'at':utc_now(),'languages':{},'established':False,'query':query}
    reverse={v.upper():k for k,v in LANG3.items()}
    for row in rows:
        code=reverse.get(row.get('language',{}).get('value','').rstrip('/').rsplit('/',1)[-1].upper())
        if not code:continue
        entry=result['languages'].setdefault(code,{'formats':[],'items':[]})
        fmt=row.get('format',{}).get('value','').rstrip('/').rsplit('/',1)[-1].rsplit('#',1)[-1].lower()
        if fmt and fmt not in entry['formats']:entry['formats'].append(fmt)
        item=row.get('item',{}).get('value')
        if item and re.fullmatch(r'x?html(?:[_-](?:simplified|conv))?',fmt):
            target=trusted_url(item,cellar=True)
            if urlsplit(target).hostname!='publications.europa.eu' or not urlsplit(target).path.startswith('/resource/'):
                raise ValueError('Unexpected source address in the publication catalogue.')
            obj={'url':target,'format':fmt}
            if obj not in entry['items']:entry['items'].append(obj)
    result['established']=bool(result['languages'])
    return result


def fetch_record(record, lang, config, network):
    celex=record['celex']
    if not isinstance(celex,str) or not CELEX.fullmatch(celex):raise ValueError('Invalid document CELEX.')
    if lang not in LANG3:raise ValueError('Invalid document language.')
    provider=config['provider'];attempts=[];visited=set();catalogue=None;payload_seen=False
    common={'Accept-Language':LANG3[lang], 'Accept-Max-Cs-Size':str(config['max_file_mb']*1024*1024)}
    eurlex=f'https://eur-lex.europa.eu/legal-content/{lang.upper()}/TXT/HTML/?uri=CELEX:{celex}'

    def validate_response(raw,resolved):
        nonlocal payload_seen
        # A response page must identify the requested document before it can enter the archive.
        text,detected=html_content(raw.decode('utf-8-sig'))
        if detected==lang and document_heading(text):payload_seen=True
        if detected!=lang:
            raise ValueError(f'The returned language was {detected or "unrecognised"}; {lang} was requested.')
        metadata=parse_metadata(text,celex_hint=celex,retrieval_language=lang)
        if record.get('delivery_date') and metadata.get('delivery_date') and metadata['delivery_date']!=record['delivery_date']:
            raise ValueError('The document date differs from the search record.')
        if record.get('ecli') and metadata.get('ecli') and record['ecli']!=metadata['ecli']:
            raise ValueError('The document ECLI differs from the selected identifier.')
        trusted_url(resolved,cellar=True)

    def attempt(url, preferred=None):
        url=trusted_url(url,cellar=True)
        key=(url,preferred or '')
        if key in visited:return None
        visited.add(key)
        # A single exact MIME value is used for the CELLAR negotiation. XHTML is retried on 406.
        accept=preferred or ('text/html' if urlsplit(url).hostname=='publications.europa.eu' else 'text/html,application/xhtml+xml;q=0.9')
        formats=[accept]
        for fmt in formats:
            entry={'url':url,'accept':fmt,'language':lang}
            try:
                raw,resolved,headers=network.get(url,headers={**common,'Accept':fmt})
                entry['resolved_url']=resolved
                entry['response_bytes']=len(raw)
                entry['content_type']=headers.get('Content-Type','')
                try:
                    preview,detected=html_content(raw.decode('utf-8-sig'))
                    entry['detected_language']=detected
                    entry['identified_heading']=document_heading(preview)
                    entry['response_preview']=preview[:1200]
                except Exception:pass
                validate_response(raw,resolved)
                attempts.append({**entry,'status':'saved'})
                return raw,url,resolved
            except Cancelled:raise
            except Exception as exc:
                entry['error']=str(exc)
                status=getattr(getattr(exc,'response',None),'status_code',None)
                if status:entry['http_status']=status
                attempts.append(entry)
                if status in {404,406} and fmt=='text/html':formats.append('application/xhtml+xml')
        return None

    if provider=='cellar':
        # Discovery already supplies work addresses. Use the catalogue to go directly to a language-specific item.
        if record.get('work_uri') or record.get('work_uris'):
            try:
                catalogue=resolve_catalogue(record,network)
                attempts.append({'url':ENDPOINT,'stage':'language-catalogue','catalogue':catalogue})
                for item in catalogue['languages'].get(lang,{}).get('items',[]):
                    mime='application/xhtml+xml' if item['format'].startswith('xhtml') else 'text/html'
                    found=attempt(item['url'],mime)
                    if found:return found
            except Cancelled:raise
            except Exception as exc:attempts.append({'url':ENDPOINT,'stage':'language-catalogue','error':str(exc)})
        known_absence=bool(catalogue and catalogue['established'] and (
            lang not in catalogue['languages'] or (catalogue['languages'][lang]['formats'] and
            not any(re.fullmatch(r'x?html(?:[_-](?:simplified|conv))?',f) for f in catalogue['languages'][lang]['formats']))))
        urls=[f'https://publications.europa.eu/resource/celex/{celex}']
        work_uris=record.get('work_uris',[])
        if not isinstance(work_uris,list):raise ValueError('work_uris must be a list of resource addresses.')
        for u in ([record['work_uri']] if record.get('work_uri') else [])+work_uris:
            target=trusted_url(u,cellar=True)
            if urlsplit(target).hostname!='publications.europa.eu' or not urlsplit(target).path.startswith('/resource/cellar/'):
                raise ValueError('Unexpected CELLAR work address.')
            if target not in urls:urls.append(target)
        if not known_absence:
            for url in urls:
                found=attempt(url)
                if found:return found
            # The documented language query is a fallback for aliases that ignore headers.
            for url in urls:
                found=attempt(url+('?' if '?' not in url else '&')+urlencode({'language':LANG3[lang]}),'application/xhtml+xml')
                if found:return found
            try:
                for url in resolve_cellar_items(record,lang,network):
                    found=attempt(url)
                    if found:return found
            except Cancelled:raise
            except Exception as exc:attempts.append({'url':ENDPOINT,'stage':'resolve-language-files','error':str(exc)})
        if config.get('eurlex_fallback',True):
            found=attempt(eurlex)
            if found:return found
            # The ordinary TXT endpoint can expose the full document when the bare HTML endpoint does not.
            found=attempt(eurlex.replace('/TXT/HTML/','/TXT/'))
            if found:return found
    elif provider=='eurlex':
        found=attempt(eurlex)
        if found:return found
        found=attempt(eurlex.replace('/TXT/HTML/','/TXT/'))
        if found:return found
    else:
        if record.get('curia_url'):urls=[curia_language_url(record['curia_url'],lang)]
        else:
            year,number,court=int(celex[1:5]),int(celex[7:11]),celex[5]
            own=f'{court}-{number}/{str(year)[-2:]}' if year>=1989 or court!='C' else f'{number}/{str(year)[-2:]}'
            search='https://curia.europa.eu/juris/liste.jsf?'+urlencode({'num':own,'language':lang})
            try:
                raw,resolved,_=network.get(search)
            except Exception as exc:
                if isinstance(exc,Cancelled):raise
                raise DownloadError(celex,lang,[{'url':search,'error':str(exc)}]) from exc
            urls=[]
            for a in BeautifulSoup(raw,'html.parser').find_all('a',href=True):
                target=urljoin(resolved,a['href'])
                if '/juris/document/' in target or '/tabs/document' in target:
                    try:
                        target=curia_language_url(target,lang)
                        if target not in urls:urls.append(target)
                    except ValueError:pass
            if not urls:attempts.append({'url':search,'error':'No document links were recognised on the CURIA page. Try CELLAR or EUR-Lex in Settings.'})
        for url in urls:
            found=attempt(url)
            if found:return found
    # Visible browser assistance is attempted once, on a readable official page.
    if config['browser_fallback']:
        use_eurlex=provider=='eurlex' or (provider=='cellar' and config.get('eurlex_fallback',True))
        browser_url=eurlex if use_eurlex else (urls[0] if urls else '')
        if browser_url:
            try:
                raw,resolved,_=browser_fetch(browser_url,config,network.cancel,headers=common)
                validate_response(raw,resolved)
                return raw,browser_url,resolved
            except Cancelled:raise
            except Exception as exc:attempts.append({'url':browser_url,'stage':'browser','error':str(exc)})
    if provider=='cellar' and not payload_seen:
        if not catalogue:
            try:catalogue=resolve_catalogue(record,network)
            except Cancelled:raise
            except Exception as exc:attempts.append({'url':ENDPOINT,'stage':'language-catalogue','error':str(exc)})
        if catalogue and catalogue['established']:
            selected=catalogue['languages'].get(lang)
            if selected is None or (selected['formats'] and not any(re.fullmatch(r'x?html(?:[_-](?:simplified|conv))?',f) for f in selected['formats'])):
                raise VersionUnavailable(celex,lang,catalogue,attempts)
    raise DownloadError(celex,lang,attempts)


def obtain(records, q, config, store, network, progress):
    docs=[]; failures=[]; unavailable=[]; cached=0
    # Each selected language version is requested; no silent first-language or top-N cap exists.
    records=merge_records(records)
    pairs=[(r,lang) for r in records for lang in q.languages]
    missing=[]
    for record,lang in pairs:
        network.check()
        old=store.lookup(record['celex'],lang)
        if old and (not record.get('delivery_date') or old.get('delivery_date')==record['delivery_date']):
            from .store import SIDE_FIELDS
            extra={k:v for k,v in record.items() if k in SIDE_FIELDS and v not in (None,'',[])}
            if any(old.get(k)!=v for k,v in extra.items()):
                try:
                    old=store.ingest((store.home/old['source_path']).read_bytes(),language=lang,celex=record['celex'],
                        source_url=old.get('source_url',''),resolved_url=old.get('resolved_url',''),side=extra)
                except Exception as exc:
                    failures.append({'celex':record['celex'],'language':lang,'stage':'metadata','error':str(exc)})
                    continue
            docs.append(old); cached+=1
        else:
            missing.append((record,lang))
    progress('cache',f'{cached} documents are already saved. Downloading {len(missing)} more.', cached=cached,missing=len(missing))
    def task(pair):
        record,lang=pair
        if hasattr(network,'reset_trace'):network.reset_trace()
        log={'celex':record['celex'],'language':lang,'provider_requested':config['provider'],'at':utc_now()}
        try:
            raw,requested,resolved=fetch_record(record,lang,config,network)
            side={k:v for k,v in record.items() if k not in {'celex','work_uri','work_uris','curia_url','source_url'}}
            meta=store.ingest(raw,language=lang,celex=record['celex'],source_url=requested,resolved_url=resolved,side=side)
            log.update(status='saved',requested_url=requested,resolved_url=resolved,provider_used=meta['provider'])
            return meta
        except Exception as exc:
            log.update(status='version-unavailable' if isinstance(exc,VersionUnavailable) else 'failed',error=str(exc),attempts=getattr(exc,'attempts',[]))
            if isinstance(exc,VersionUnavailable):log['catalogue']=exc.catalogue
            raise
        finally:
            log['network_trace']=network.trace() if hasattr(network,'trace') else []
            write_json(store.home/'downloads'/(record['celex']+'_'+lang+'.json'),log)
    workers=1 if config['browser_fallback'] else config['download_workers']
    with ThreadPoolExecutor(max_workers=workers) as pool:
        pending={pool.submit(task,pair):pair for pair in missing}
        for future in as_completed(pending):
            record,lang=pending[future]
            try:
                docs.append(future.result())
            except VersionUnavailable as exc:
                unavailable.append({'celex':record['celex'],'language':lang,'stage':'availability',
                    'reason':str(exc),'reason_code':exc.reason_code,'available_languages':exc.available_languages,
                    'formats':exc.formats,'checked_at':exc.catalogue['at'],'source':'CELLAR publication catalogue',
                    'diagnostics_file':'downloads/'+record['celex']+'_'+lang+'.json'})
            except Exception as exc:
                failures.append({'celex':record['celex'],'language':lang,'stage':'download','error':str(exc),'attempts':getattr(exc,'attempts',[]),
                                 'diagnostics_file':'downloads/'+record['celex']+'_'+lang+'.json'})
            progress('download',f'Checked {len(docs)+len(failures)+len(unavailable)} of {len(pairs)} documents: {len(docs)-cached} downloaded, {cached} already saved, {len(failures)} need attention, {len(unavailable)} versions are unlisted.', downloaded=len(docs)-cached,failed=len(failures))
            if network.cancel.is_set():
                for f in pending:
                    f.cancel()
    return {'documents':list({d['doc_id']:d for d in docs}.values()),'failures':failures,
            'cached':cached,'requested':len(pairs),'downloaded':len(docs)-cached,'unavailable':unavailable}
