from __future__ import annotations

import copy
import json
import threading
import time
import uuid
from pathlib import Path

from .common import read_optional_object, utc_now, write_json
from .export import write_exports
from .keywords import KeywordPlan
from .query import Query, case_groups, eligibility
from .screening import screen
from .sources import Cancelled, Network, discover, manifest_records, obtain, type_codes, merge_records
from .store import Store


def execute(home: Path, config: dict, data: dict, *, cancel=None, progress=None, network=None,
            client=None, selection=None, run_id=None):
    q=Query.parse(data,config)
    cancel=cancel or threading.Event()
    progress=progress or (lambda *args,**kwargs:None)
    store=Store(home)
    run_id=run_id or uuid.uuid4().hex[:16]
    directory=store.home/'runs'/run_id
    result={'schema':'curia-lite.results/1','run_id':run_id,'query':q.to_dict(),'started_at':utc_now(),
            'status':'running','warnings':[],'failures':[],'metadata_unresolved':[],'unavailable_versions':[],
            'keyword_definition':KeywordPlan.create(q.keywords,q.logic,q.exclude,q.near_distance).describe(),
            'criteria_excluded':0,'cases':[],'documents':[],'timings':{},'model_config':{
                k:config[k] for k in ['model','native_languages','num_ctx','num_predict','think','evidence_bytes','snippets','llm_workers']}}
    write_json(directory/'request.json',{'query':q.to_dict(),'selection':selection,'settings':config})
    start=time.monotonic()
    try:
        if q.source_mode=='local':
            docs=store.documents(q.include_demo)
            result['discovery']={'complete':False,'source':'local archive'}
            result['warnings'].append('This search used the documents already in the local archive.')
        else:
            network=network or Network(config,cancel)
            if selection is not None:
                manifest={'complete':True,'records':manifest_records(selection),'source':'imported CELEX selection'}
            else:
                progress('discovery','Looking up documents for the selected dates.')
                manifest=discover(q,config,store,network,progress)
            result['discovery']=manifest
            if not manifest['complete']:
                result['warnings'].append('The catalogue search ended early. Retry to look for the remaining documents.')
            records=[r for r in manifest['records'] if r['celex'][5:7] in type_codes(q)
                     and (not r.get('delivery_date') or (q.date_from<=r['delivery_date']<=q.date_to))
                     and (not q.filters.get('celex') or r['celex']==q.filters['celex'].upper())]
            # Deduplicate works exposed through more than one equivalent metadata URI.
            records=merge_records(records)
            acquired=obtain(records,q,config,store,network,progress)
            docs=acquired.pop('documents')
            result['failures'].extend(acquired['failures'])
            result['unavailable_versions']=acquired.get('unavailable',[])
            result['acquisition']=acquired
        result['timings']['acquisition_seconds']=round(time.monotonic()-start,3)
        eligible=[]
        for meta in docs:
            try:meta,_=store.read(meta['doc_id'])
            except Exception as exc:
                result['failures'].append({'doc_id':meta['doc_id'],'stage':'source-validation','error':str(exc)})
                continue
            state,why=eligibility(meta,q)
            if state=='eligible':eligible.append(meta)
            elif state=='metadata-unresolved':result['metadata_unresolved'].append({**meta,'missing_fields':why})
            else:result['criteria_excluded']+=1
        progress('filter',f'{len(eligible)} documents match the filters. {len(result["metadata_unresolved"])} need additional information.',eligible=len(eligible))
        before=time.monotonic()
        assessments=screen(eligible,q,config,store,cancel,progress,client=client)
        result['timings']['screening_seconds']=round(time.monotonic()-before,3)
        result['documents']=assessments
        result['cases']=case_groups(assessments)
        for a in assessments:
            if a.get('status') in {'not-assessed','partial-assessment'}:
                result['failures'].append({'doc_id':a['doc_id'],'stage':'assessment','error':a.get('errors') or a.get('reason')})
        if cancel.is_set():
            result['status']='cancelled'
        elif result['failures'] or result['metadata_unresolved'] or (q.source_mode=='auto' and not result['discovery']['complete']):
            result['status']='partial'
        elif result['unavailable_versions']:
            result['status']='completed-with-unavailable-versions'
        else:
            result['status']='completed-local-subset' if q.source_mode=='local' else 'completed-selected-snapshot'
        if q.semantic and q.depth=='fast':
            result['warnings'].append('Fast screening checked selected passages. Complete-text screening provides a more thorough review and takes longer.')
        if not q.semantic:
            result['warnings'].append('Matching passages are shown with each result.')
        result['summary']={'documents_in_scope':len(docs),'eligible_documents':len(eligible),
            'case_groups':len(result['cases']),'unavailable_versions':len(result['unavailable_versions']),'assessed_documents':sum(d.get('status')=='assessed' for d in assessments),
            'keyword_excluded':sum(d.get('status')=='keyword-excluded' for d in assessments),
            'model_calls':sum(d.get('model_calls',0) for d in assessments),
            'cache_hits':sum(d.get('cache_hits',0) for d in assessments)}
    except Cancelled as exc:
        result['status']='cancelled';result['warnings'].append(str(exc))
    except Exception as exc:
        result['status']='failed';result['failures'].append({'stage':'run','error':str(exc)})
    result['finished_at']=utc_now()
    result['timings']['total_seconds']=round(time.monotonic()-start,3)
    progress('export','Saving the case list and download details.')
    result['exports']={'json':'results.json','csv':'shortlist.csv','docx':'shortlist.docx'}
    write_exports(result,directory)
    return result


class Jobs:
    def __init__(self,home):
        self.home=Path(home);self.lock=threading.RLock();self.current={};self.cancel=threading.Event()

    def start(self,config,data,selection=None):
        Query.parse(data,config)
        with self.lock:
            if self.current.get('active'):
                raise ValueError('A search is already running. Stop it before starting another.')
            ident=uuid.uuid4().hex[:16]
            self.cancel=threading.Event()
            self.current={'run_id':ident,'active':True,'stage':'queued','message':'Search queued.'}
        def progress(stage,message,**stats):
            with self.lock:self.current.update(stage=stage,message=message,**stats)
        def work():
            try:
                result=execute(self.home,copy.deepcopy(config),data,cancel=self.cancel,progress=progress,selection=selection,run_id=ident)
                with self.lock:self.current.update(active=False,stage=result['status'],result=result)
            except Exception as exc:
                with self.lock:self.current.update(active=False,stage='failed',message=str(exc))
        threading.Thread(target=work,daemon=True).start()
        return ident

    def status(self):
        with self.lock:return copy.deepcopy(self.current)

    def recent(self):
        directory=self.home/'runs'
        paths=sorted(directory.glob('*/results.json'),key=lambda p:p.stat().st_mtime,reverse=True) if directory.exists() else []
        out=[]
        for p in paths[:10]:
            obj=read_optional_object(p)
            if obj:out.append({'run_id':obj['run_id'],'started_at':obj['started_at'],'query':obj['query'],'status':obj['status']})
        return out
