from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import re
import tempfile
import unicodedata
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any
from urllib.parse import urlparse, unquote

LANGUAGES = dict(zip(
    'bg es cs da de et el en fr ga hr it lv lt hu mt nl pl pt ro sk sl fi sv'.split(),
    'Bulgarian Spanish Czech Danish German Estonian Greek English French Irish Croatian Italian Latvian Lithuanian Hungarian Maltese Dutch Polish Portuguese Romanian Slovak Slovenian Finnish Swedish'.split()))


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')


def digest(value: bytes | str) -> str:
    return hashlib.sha256(value.encode('utf-8') if isinstance(value, str) else value).hexdigest()


def atomic_write(path: str | Path, value: str | bytes) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.cl-', suffix='.tmp', dir=target.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(value.encode('utf-8') if isinstance(value, str) else value)
        os.replace(name, target)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def write_json(path: str | Path, value: Any) -> None:
    atomic_write(path, json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def normalise_search(text: str) -> str:
    # Source characters remain unchanged; this representation is used only for matching.
    text = unicodedata.normalize('NFKC', text).casefold()
    text = text.translate(str.maketrans({'’': "'", '‐': '-', '‑': '-', '–': '-', '—': '-'}))
    return re.sub(r'\s+', ' ', text).strip()


def safe_name(text: str, length: int = 80) -> str:
    text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode()
    text = re.sub(r'[^A-Za-z0-9_-]+', '-', text).strip('-')
    return (text or 'document')[:length]


def language_code(value: str) -> str:
    value = value.lower().strip()
    if value not in LANGUAGES:
        raise ValueError(f'Unsupported EU language code: {value!r}')
    return value


def date_range(start: str, end: str) -> tuple[str, str]:
    if start:
        dt.date.fromisoformat(start)
    if end:
        dt.date.fromisoformat(end)
    if start and end and start > end:
        raise ValueError('The starting date must not follow the ending date.')
    return start, end


def trusted_url(url: str, *, cellar: bool = False) -> str:
    """Resolve the documented CELLAR HTTP identifiers through HTTPS before requesting them."""
    if not isinstance(url, str) or not url or any(ord(c) <= 32 for c in url) or "\\" in url:
        raise ValueError('The source address is invalid.')
    parsed = urlparse(url)
    hosts = {'curia.europa.eu', 'juris.curia.europa.eu', 'infocuria.curia.europa.eu', 'eur-lex.europa.eu'}
    if cellar:
        hosts.add('publications.europa.eu')
    host = parsed.hostname
    try:
        port = parsed.port
    except ValueError as exc:
        raise ValueError('The source address has an invalid port.') from exc
    if host not in hosts or parsed.username is not None or parsed.password is not None:
        raise ValueError(f'The source address uses an unrecognised host: {host or "missing hostname"}.')
    if any(ord(c) < 32 for c in unquote(parsed.path)):
        raise ValueError('The source path contains invalid characters.')
    if parsed.scheme == 'http' and cellar and host == 'publications.europa.eu' and parsed.path.startswith('/resource/') and port in (None, 80):
        parsed = parsed._replace(scheme='https', netloc=host)
    elif parsed.scheme != 'https' or port not in (None, 443):
        raise ValueError(f'A secure source address is required for {host}.')
    return parsed._replace(netloc=host, fragment='').geturl()


def read_optional_object(path: str | Path) -> dict:
    """Damaged optional recovery records are cache misses, never trusted results."""
    try:
        obj = json.loads(Path(path).read_text(encoding='utf-8-sig'))
    except (OSError, ValueError, UnicodeError):
        return {}
    return obj if isinstance(obj, dict) else {}


def workspace_path(root: str | Path, relative: str) -> Path:
    """Portable archive paths accept legacy Windows separators without escaping the root."""
    if not isinstance(relative, str) or not relative:
        raise ValueError('An archive-relative path is required.')
    raw = relative.replace('\\', '/')
    if PureWindowsPath(relative).drive or PurePosixPath(raw).is_absolute():
        raise ValueError('Absolute paths are not valid archive-relative paths.')
    parts = PurePosixPath(raw).parts
    if '..' in parts:
        raise ValueError('An archive path must remain inside its workspace.')
    base = Path(root).resolve()
    result = base.joinpath(*parts).resolve()
    if not result.is_relative_to(base):
        raise ValueError('An archive path must remain inside its workspace.')
    return result


def prepare_console() -> None:
    """UTF-8 output is retained when Windows commands are redirected to a file."""
    import sys
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, 'reconfigure'):
            try:
                stream.reconfigure(encoding='utf-8', errors='backslashreplace')
            except (OSError, ValueError):
                pass
