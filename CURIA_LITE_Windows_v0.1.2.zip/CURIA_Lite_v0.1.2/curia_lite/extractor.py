from __future__ import annotations

import re
from pathlib import Path

from bs4 import BeautifulSoup

from .common import LANGUAGES, normalise_search

EXTRACTOR_VERSION = 2

CASE = re.compile(r'(?<![\w/])(?:[CTF]\s*[-‐‑–—]\s*)?\d{1,4}\s*/\s*\d{2,4}(?:\s+P(?:\s*\(R\))?)?(?![\w/])')
ECLI = re.compile(r'(?:ECLI:)?EU:[CTF]:\d{4}:\d+')
CELEX = re.compile(r'6\d{4}(?:CJ|CC|CO|TJ|TO|FJ|FO)\d{4}(?:\(\d+\))?', re.I)
MONTHS = {v: i for i, v in enumerate(['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'], 1)}
MONTHS.update({v: i for i, v in enumerate(['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'], 1)})
# Common authentic-version headings and genitive month forms are recognised explicitly.
for names in [
    'Januar Februar März April Mai Juni Juli August September Oktober November Dezember',
    'gennaio febbraio marzo aprile maggio giugno luglio agosto settembre ottobre novembre dicembre',
    'ianuarie februarie martie aprilie mai iunie iulie august septembrie octombrie noiembrie decembrie',
    'stycznia lutego marca kwietnia maja czerwca lipca sierpnia września października listopada grudnia',
    'enero febrero marzo abril mayo junio julio agosto septiembre octubre noviembre diciembre',
    'janeiro fevereiro março abril maio junho julho agosto setembro outubro novembro dezembro',
    'januari februari maart april mei juni juli augustus september oktober november december',
    'ledna února března dubna května června července srpna září října listopadu prosince',
]:
    MONTHS.update({name.casefold(): i for i, name in enumerate(names.split(), 1)})
HEADING_LANGS = {
    'fr': r'arr[eê]t de la cour|arr[eê]t du tribunal|conclusions de l.avocat|ordonnance (?:du (?:vice[- ]pr[eé]sident|pr[eé]sident) |de la (?:vice[- ]pr[eé]sidente|pr[eé]sidente) )?(?:de la cour|du tribunal)',
    'en': r'judgment of the (?:court|general court)|opinion of (?:the )?advocate general|order of (?:the )?(?:(?:vice[- ]president|president) of (?:the )?)?(?:court|general court)',
    'it': r'sentenza (?:della corte|del tribunale)|conclusioni dell.avvocat[oa] generale|ordinanza (?:della corte|del tribunale)',
    'de': r'urteil des (?:gerichtshofs|gerichts)|schlussantr[aä]ge (?:des generalanwalts|der generalanwältin)|beschluss des (?:gerichtshofs|gerichts)',
    'pt': r'acórdão (?:do tribunal|da corte)|conclusões d[oa] advogad[oa]|despacho do tribunal',
    'nl': r'arrest van (?:het hof|het gerecht)|conclusie van (?:de )?advocaat|beschikking van (?:het hof|het gerecht)',
    'ro': r'hotărârea curții|concluziile avocatului general|ordonanța curții',
    'pl': r'wyrok trybunału|opinia rzecznika generalnego|postanowienie trybunału',
    'es': r'sentencia del tribunal (?:de justicia|general)|conclusiones (?:del abogado|de la abogada) general|auto del tribunal (?:de justicia|general)',
    'cs': r'rozsudek soudního dvora|stanovisko generálního advokáta|usnesení soudního dvora',
}
OWN_CASE_LABEL = r'(?:Affaires?\s+jointes?|Dans\s+l.affaire|Affaire|Joined\s+Cases?|In\s+Case|Case|Nella\s+causa|Cause\s+riunite|causa|In\s+der\s+Rechtssache|Rechtssache|În\s+cauza|Cauzele\s+conexate|W\s+sprawie|Sprawa|En\s+el\s+asunto|Asuntos\s+acumulados|Ve\s+věci|No\s+processo|Processos\s+apensos|In\s+zaak|Gevoegde\s+zaken)'
NAMES = dict(zip('fr en de it ro pl cs es el pt nl bg hr da et fi ga lv lt hu mt sk sl sv'.split(),
                 ['français', 'anglais', 'allemand', 'italien', 'roumain', 'polonais', 'tchèque', 'espagnol', 'grec', 'portugais', 'néerlandais', 'bulgare', 'croate', 'danois', 'estonien', 'finnois', 'irlandais', 'letton', 'lituanien', 'hongrois', 'maltais', 'slovaque', 'slovène', 'suédois']))
LANG_NAME = {normalise_search(v): k for k, v in NAMES.items()}
LANG_NAME.update({normalise_search(v): k for k, v in LANGUAGES.items()})
LANG_NAME.update({'italiano':'it', 'tedesco':'de', 'francese':'fr', 'română':'ro', 'germană':'de', 'franceză':'fr', 'deutsch':'de', 'französisch':'fr', 'italienisch':'it', 'polski':'pl', 'włoski':'it', 'niemiecki':'de', 'español':'es', 'francés':'fr'})

LANG_NAME.update({'português':'pt','neerlandês':'nl','francês':'fr','alemão':'de','inglês':'en','espanhol':'es', 'nederlands':'nl','frans':'fr','duits':'de','engels':'en','spaans':'es','italiaans':'it','portugees':'pt'})


def clean(text: str) -> str:
    # Punctuation and accents in evidence are retained rather than rewritten.
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', text).replace('\r\n', '\n').replace('\r', '\n')
    return '\n'.join(re.sub(r'[ \t\u00a0\u202f]+', ' ', line).strip() for line in text.splitlines()).strip()


def case_id(value: str) -> str:
    value = re.sub(r'\s*[-‐‑–—]\s*', '-', value.upper())
    value = re.sub(r'\s*/\s*', '/', value)
    return re.sub(r'\s+', ' ', value).strip()



def document_heading(text: str):
    """Locate the earliest standalone judicial heading across the supported languages."""
    candidates=[]
    for code,pattern in HEADING_LANGS.items():
        for m in re.finditer(r'(?m)^\s*(?:'+pattern+r')',text[:10000],re.I):
            title=m[0].strip()
            if re.match(r'conclusions|opinion|conclusioni|schlussantr|concluziile|opinia|conclusiones|stanovisko|conclusões|conclusie',title,re.I):
                kind='opinion'
            elif re.match(r'ordonnance|order|ordinanza|beschluss|ordonanța|postanowienie|auto|usnesení|despacho|beschikking',title,re.I):
                kind='order'
            else:kind='judgment'
            candidates.append({'start':m.start(),'end':m.end(),'language':code,'kind':kind,'heading':title})
            break
    return min(candidates,key=lambda x:x['start']) if candidates else None

def html_content(raw: str) -> tuple[str, str]:
    soup = BeautifulSoup(raw, 'html.parser')
    selected = None
    for selector in ['#TexteOnly', '#document1', '#document', '.document_content', '.texte']:
        candidate = soup.select_one(selector)
        if candidate and len(candidate.get_text()) > 100:
            selected = candidate
            break
    root = selected if selected is not None else (soup.body or soup)
    declared = root.get('lang', '').lower().split('-')[0]
    if not declared and selected is None and soup.html:
        declared = soup.html.get('lang', '').lower().split('-')[0]
    for tag in list(root.find_all(['script', 'style', 'noscript', 'nav'])):
        tag.decompose()
    paragraphs = []
    block_names = ['p', 'h1', 'h2', 'h3', 'h4', 'tr', 'li', 'pre']
    for tag in root.find_all(block_names):
        if any(parent.name in block_names for parent in tag.parents if parent is not root):
            continue
        text = clean(tag.get_text(' ', strip=True))
        if text:
            paragraphs.append(text)
    text = '\n\n'.join(paragraphs) if paragraphs else clean(root.get_text('\n', strip=True))
    # A case heading is more reliable than the interface language of an EUR-Lex page.
    heading=document_heading(text)
    if heading:declared=heading['language']
    return clean(text), declared if declared in LANGUAGES else ''




def validate_document(text: str) -> None:
    opening = normalise_search(text[:1200])
    blocked = ['verify you are not a robot', 'access denied', 'captcha', 'vérifier que vous êtes', 'just a moment', 'requested document does not exist']
    if len(text.strip()) < 200 or any(marker in opening for marker in blocked):
        raise ValueError('The response is empty, incomplete, missing or a verification page; it was not ingested.')
    if not document_heading(text):
        raise ValueError('The source does not contain an identifiable legal-document heading.')


def labelled_language(text: str, original: bool = False) -> str:
    label = r'(?:Langue\s+originale|Original\s+language|Lingua\s+originale|Originalsprache|Limba\s+originală|Język\s+oryginału|Lengua\s+original|Língua\s+original|Oorspronkelijke\s+taal)' if original else r'(?:Langue\s+(?:de\s+(?:l.affaire|procédure))|Language\s+of\s+the\s+case|Lingua\s+processuale|Verfahrenssprache|Limba\s+de\s+procedură|Język\s+postępowania|Lengua\s+de\s+procedimiento|Língua\s+do\s+processo|Procestaal)'
    hits = re.findall(label + r'\s*[:：]\s*([\wÀ-ÿ -]+)', text, re.I)
    for hit in reversed(hits):
        for name, code in LANG_NAME.items():
            if normalise_search(hit).startswith(name):
                return code
    return ''


def date_in_header(header: str) -> str:
    matches = re.finditer(r'(?<!\d)(\d{1,2})(?:er|\.)?\s+(?:de\s+)?([^\W\d_]+)\s+(?:de\s+)?(\d{4})', header)
    for m in matches:
        month = MONTHS.get(m[2].casefold())
        if month:
            from datetime import date
            try:
                return date(int(m[3]), month, int(m[1])).isoformat()
            except ValueError:
                continue
    return ''


def parse_metadata(text: str, filename: str = '', *, celex_hint: str = '', retrieval_language: str = 'fr', **kwargs) -> dict:
    validate_document(text)
    celex_hint = celex_hint.strip().upper()
    if celex_hint and not CELEX.fullmatch(celex_hint):
        raise ValueError('Invalid CELEX hint.')
    # Only the own-case introductory area is examined for identity, not cited cases in the reasoning.
    heading_match=document_heading(text)
    start=heading_match['start'] if heading_match else 0
    header = text[start:start + 8000]
    body_start = re.search(r'\n\s*1[.\s]+(?:La |Le |Par |This |The |By |Dans )', header)
    if body_start:
        header = header[:body_start.start()]
    line = re.search(OWN_CASE_LABEL + r'\s+([^\n]{1,180})', header, re.I)
    ids = [case_id(m[0]) for m in CASE.finditer(line[1])] if line else []
    if not ids:
        # A strictly validated CELEX hint can identify the case even in older unprefixed texts.
        celex_match = CELEX.fullmatch(celex_hint)
        if celex_match:
            year, court, number = celex_hint[1:5], celex_hint[5], int(celex_hint[7:11])
            prefix = '' if int(year) < 1989 and court == 'C' else court + '-'
            ids = [f'{prefix}{number}/{year[-2:]}']
    if not ids:
        raise ValueError('Own-case identifier not identified; a CELEX hint or a properly headed source is required.')
    kind=heading_match['kind']
    if celex_hint:
        expected_year, expected_court = celex_hint[1:5], celex_hint[5]
        expected_number = int(celex_hint[7:11])
        def same_case(identifier: str) -> bool:
            match = re.fullmatch(r'(?:(?P<court>[CTF])-)?(?P<number>\d+)/(?P<year>\d{2,4})(?: P(?: \(R\))?)?', identifier)
            return bool(match and (match['court'] or 'C') == expected_court
                        and int(match['number']) == expected_number
                        and match['year'][-2:] == expected_year[-2:])
        if not any(same_case(identifier) for identifier in ids):
            raise ValueError('The CELEX hint does not identify the extracted case.')
        expected_type = {'CJ': 'judgment', 'CC': 'opinion', 'CO': 'order', 'TJ': 'judgment',
                         'TO': 'order', 'FJ': 'judgment', 'FO': 'order'}[celex_hint[5:7]]
        if kind != expected_type:
            raise ValueError(f'The selected CELEX requires {expected_type}; the document heading identifies {kind}: {heading_match["heading"]}.')
    ec = ECLI.search(header)
    if not ec:
        # A standalone footer ECLI is considered only when unique across the whole document.
        standalone = re.findall(r'(?m)^\s*(ECLI:EU:[CTF]:\d{4}:\d+)\s*$', text)
        ecli = standalone[0] if len(set(standalone)) == 1 else ''
    else:
        ecli = ec[0] if ec[0].startswith('ECLI:') else 'ECLI:' + ec[0]
    own_date = date_in_header(header[:1400])
    language = labelled_language(text)
    original = labelled_language(text, original=True)
    title = ''
    party_match = re.search(OWN_CASE_LABEL + r'[^\n]*\n+(.+?)(?=\n+(?:LA COUR|LE TRIBUNAL|THE COURT|LA CORTE|DER GERICHTSHOF|CURTEA|TRYBUNAŁ|EL TRIBUNAL|ayant pour objet|\[|\())', header, re.I | re.S)
    if party_match:
        title = re.sub(r'\s+', ' ', party_match[1]).strip()[:700]
    if not title:
        title = kwargs.get('case_name', '') or ' / '.join(ids)
    judge = re.search(r'([A-ZÀ-Ý][\wÀ-ÿ.\- ‑’]+?)\s*\((?:rapporteur|reporting judge|berichterstatter(?:in)?|relatore|ponente|relator)\)', header, re.I)
    ag = re.search(r'(?:(?:avocat(?:e)? général(?:e)?|advocate general|avvocato generale|generalanwältin|generalanwalt|abogado general|advogado.geral|advocaat.generaal)\s*:\s*)([^\n,;]+)', header, re.I)
    if kind == 'opinion' and not ag:
        ag = re.search(r'CONCLUSIONS DE L.AVOCAT(?:E)? GÉNÉRAL(?:E)?\s*\n+([^\n]+)', header, re.I)
    authority = 'unconfirmed'
    if kind in {'judgment', 'order'} and language:
        authority = 'language-of-case-version' if language == retrieval_language else 'published-translation'
    if kind == 'opinion':
        authority = ('original-opinion' if original == retrieval_language else 'translated-opinion') if original else 'original-language-unconfirmed'
    return {'extractor_version':EXTRACTOR_VERSION,'identified_heading':heading_match['heading'],'case_id': ' / '.join(dict.fromkeys(ids)), 'case_numbers': list(dict.fromkeys(ids)),
            'case_name': title, 'ecli': ecli, 'celex': celex_hint.upper(), 'doc_type': kind,
            'delivery_date': own_date, 'retrieval_language': retrieval_language,
            'language_of_case': language, 'original_language': original, 'authority_status': authority,
            'judge_rapporteur': judge[1].strip() if judge else '',
            'advocate_general': ag[1].strip() if ag else '',
            'formation': (re.search(r'(?:ARRÊT|ORDONNANCE) DE LA COUR\s*\(([^)]+)\)', header, re.I).group(1)
                          if re.search(r'(?:ARRÊT|ORDONNANCE) DE LA COUR\s*\(([^)]+)\)', header, re.I) else '')}


def paragraphs(text: str) -> list[dict]:
    blocks = [b.strip() for b in re.split(r'\n\s*\n', text) if b.strip()]
    if len(blocks) == 1:
        blocks = [b.strip() for b in re.split(r'\n(?=\d+[.\s])', text) if b.strip()]
    result = []
    for i, block in enumerate(blocks, 1):
        m = re.match(r'^(\d{1,3})[.\s]+', block)
        result.append({'index': i, 'legal_paragraph': m[1] if m else '', 'text': block})
    return result


def hard_chunks(text: str, max_chars: int = 1800, overlap: int = 150) -> list[str]:
    if max_chars < 50 or overlap < 0 or overlap >= max_chars:
        raise ValueError('Chunk size must exceed overlap and be at least 50.')
    result, pos = [], 0
    while pos < len(text):
        end = min(pos + max_chars, len(text))
        if end < len(text):
            split = text.rfind(' ', pos + max_chars // 2, end)
            if split > pos:
                end = split
        result.append(text[pos:end])
        if end == len(text):
            break
        pos = max(pos + 1, end - overlap)
    return result
