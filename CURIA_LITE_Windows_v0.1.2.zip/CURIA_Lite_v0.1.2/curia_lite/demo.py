from __future__ import annotations

from .store import Store

EXAMPLES = [
    ('0901','fr','ARRÊT DE LA COUR','Dans l’affaire C-901/25,','Le laboratoire fictif A contre le service fictif B.',
     '31 La version française vise un établissement, tandis que la version anglaise peut désigner une activité. La Cour compare ces versions linguistiques et retient le sens lié à l’établissement dans le présent litige.'),
    ('0902','fr','ARRÊT DE LA COUR','Dans l’affaire C-902/25,','Le laboratoire fictif C contre le service fictif D.',
     '22 Selon une jurisprudence constante, les diverses versions linguistiques font également foi. La présente demande est toutefois irrecevable et aucune disposition multilingue n’est interprétée.'),
    ('0903','en','JUDGMENT OF THE COURT','In Case C-903/25,','Fictional Laboratory E v Fictional Office F.',
     '28 The applicant alleges that the French language version differs from the English version. The Court does not decide that question, because the application is inadmissible.'),
    ('0904','de','URTEIL DES GERICHTSHOFS','In der Rechtssache C-904/25,','Fiktives Labor G gegen Fiktive Stelle H.',
     '19 Die französische Sprachfassung bezeichnet einen Betrieb, während die englische Sprachfassung eine Tätigkeit erfassen kann. Der Gerichtshof vergleicht die Sprachfassungen und legt die Vorschrift im vorliegenden Fall im Sinne eines Betriebs aus.'),
]


def install_demo(store: Store):
    out=[]
    for number,lang,heading,case,title,body in EXAMPLES:
        date={'fr':'14 octobre 2025','en':'14 October 2025','de':'14. Oktober 2025'}[lang]
        html=f'''<!doctype html><html lang="{lang}"><body><h1>{heading}</h1><p>{date}</p>
        <p>{case}</p><p>{title}</p><p>DEMONSTRATION SYNTHETIC FIXTURE. Fictional example for exploring the interface.</p>
        <p>{body}</p><p>100 End of the fictional example used to demonstrate the search controls.</p></body></html>'''
        out.append(store.ingest(html.encode(),language=lang,celex=f'62025CJ{number}',
                   side={'is_demo':True,'case_name':title},filename=f'DEMO_{number}.html'))
    return out
