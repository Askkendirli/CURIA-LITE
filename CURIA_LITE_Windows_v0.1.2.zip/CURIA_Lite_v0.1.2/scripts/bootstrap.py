"""Create a project-local Windows environment without changing system policy."""
from __future__ import annotations

import argparse
import os
import platform
import struct
import subprocess
import sys
import venv
from pathlib import Path


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--browser',action='store_true',help='Install optional Playwright/Chromium assistance.')
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]
    if not (3,11)<=sys.version_info[:2]<(3,14) or struct.calcsize('P')!=8:
        raise SystemExit('64-bit Python 3.11, 3.12, or 3.13 is required. Suggested command: py -3.12 scripts\\bootstrap.py')
    env=root/'.venv';python=env/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    if env.exists():
        if not python.is_file():
            raise SystemExit('Existing .venv is incomplete or from another OS. Preserve it and use a separate project folder.')
        check=subprocess.run([str(python),'-c','import sys,struct; assert (3,11)<=sys.version_info[:2]<(3,14); assert struct.calcsize("P")==8'],capture_output=True)
        if check.returncode:raise SystemExit('The existing environment needs a different Python version. Keep it and install this release in a fresh folder.')
    else:venv.EnvBuilder(with_pip=True).create(env)
    subprocess.run([str(python),'-m','pip','install','--upgrade','pip'],check=True)
    target=str(root)+('[browser]' if args.browser else '')
    subprocess.run([str(python),'-m','pip','install',target],check=True)
    if args.browser:subprocess.run([str(python),'-m','playwright','install','chromium'],check=True)
    subprocess.run([str(python),'-m','curia_lite','doctor'],check=True)
    print('\nSetup completed. Start_Windows.cmd opens the application. For contextual searches, install the selected model with Ollama.')


if __name__=='__main__':
    try:main()
    except subprocess.CalledProcessError as exc:
        raise SystemExit(f'Setup stopped with exit code {exc.returncode}; the environment was preserved for retry.')
