"""Check the release files, or update their checksum list after reviewed changes."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath

ROOT=Path(__file__).resolve().parents[1]
MANIFEST=ROOT/'SHA256SUMS.json'
EXCLUDED={'.git','.venv','__pycache__','.pytest_cache','build','dist','workspace','platform-results'}


def sha256(path):
    h=hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda:handle.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write',action='store_true',help='Create a new checksum list after reviewing and testing source changes.')
    args=parser.parse_args()
    if args.write:
        records={}
        for p in sorted(ROOT.rglob('*')):
            rel=p.relative_to(ROOT)
            if not p.is_file() or p==MANIFEST or p.is_symlink():continue
            if any(s in EXCLUDED or s.endswith('.egg-info') for s in rel.parts):continue
            if p.suffix in {'.pyc','.pyo','.sqlite3','.db'} or p.name=='settings.json':continue
            records[rel.as_posix()]=sha256(p)
        MANIFEST.write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
        print(f'Created checksums for {len(records)} release files.')
        return 0
    try:
        manifest=json.loads(MANIFEST.read_text('utf-8'))
        if not isinstance(manifest,dict) or not manifest:raise ValueError('The checksum list is empty or unreadable.')
        failed=[]
        for name,expected in manifest.items():
            rel=PurePosixPath(name)
            if rel.is_absolute() or '..' in rel.parts or '\\' in name or ':' in name:raise ValueError('An invalid path occurs in the checksum list.')
            path=ROOT.joinpath(*rel.parts).resolve()
            if not path.is_relative_to(ROOT) or not path.is_file() or sha256(path)!=expected:failed.append(name)
        print(json.dumps({'checked':len(manifest),'failed':failed},indent=2))
        return 2 if failed else 0
    except (OSError,ValueError,TypeError) as exc:
        print(f'Integrity check could not complete: {exc}')
        return 2


if __name__=='__main__':raise SystemExit(main())
