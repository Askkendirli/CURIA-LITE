# Verification — CURIA LITE 0.1.1

Checked 15 October 2026. This update responds to the submitted English-document download log and the request for clearer interface wording.

## Findings from the submitted run

The report contains 800 discovery rows covering 517 distinct CELEX identifiers. All 517 English downloads failed: 423 were rejected by the application's URL validator and 94 returned HTTP 404. Discovery stopped with a repeated-page message and an initial raw-row count of 1,089.

The log omits the destinations rejected during redirect handling. The old validator was separately tested against the HTTP-form CELLAR resource identifiers published in the official documentation; it produced the reported rejection. This supports the routing correction while leaving the precise cause of each old redirect rejection unassigned. The new download logs preserve those destinations.

The revised record merger accepted all 800 submitted resource locations, retaining them under 517 document entries. Their download addresses were normalised to HTTPS. The complete user report is excluded from the public repository; `REPORTED_RUN_CHECK.json` retains the aggregate analysis.

## Changes checked

The downloader recognises CELLAR resource identifiers and requests them over HTTPS. The approved-host, credentials and port checks remain active. It tries discovered alternative work addresses after an unavailable CELEX address, retries XHTML when appropriate, resolves language-specific HTML item links, and can use EUR-Lex through the new fallback setting. Every successful response must still match the selected language and source identity.

Discovery now groups CELEX/date entries and advances from the last identifier/date pair. Multiple addresses are preserved together. Overlapping entries are merged; a source that stops making progress produces a partial result for retry. Earlier catalogue caches are refreshed through the new query path, while valid source files and classifications remain reusable.

A download-check button and retry action were added. Download records include requested and resolved URLs, status codes, redirect destinations and fallback failures. The removed footer sentence has no replacement counterpart. Headings, help text, messages, the README and the Word-list copy were revised. The stored result schema and model configuration remain compatible with 0.1.0.

## Results

| Check | Observed result |
|---|---|
| Original 0.1.0 suite | 69 passed |
| Initial 15 regression checks against unchanged 0.1.0 | 11 failed, 4 passed |
| Final 0.1.1 suite | **98 passed** |
| Python compilation | Passed |
| Git checkout with Windows-style line-ending settings | All compared release files remained byte-identical |
| JavaScript syntax | Passed |
| SPARQL syntax and local RDF fixtures | Four queries parsed; three work entries correctly produced two unique document entries and a one-document cursor page |
| Submitted catalogue record merging | All 800 locations retained under 517 CELEX entries |
| Wheel construction | Passed |
| Installed-wheel workflow outside source folder | Passed: settings upgrade, synthetic ingestion, local keyword search, two case groups, zero model calls, Word/CSV/JSON exports |
| Actual loopback HTTP application | Used by the tests for tokens, configuration, demo, saved results and retry |
| Chromium UI | Bundled HTML/CSS/JS executed through offline DOM with a test fetch bridge to the loopback API; version, footer, settings, source-check button, synthetic search, retry and English/French/German labels passed |
| Source-check UI response | Simulated during the UI test |
| Word shortlist | Rendered and visually inspected; one page |
| Official-source requests from this environment | DNS resolution failed for Publications Office and EUR-Lex |
| Real Ollama inference | Local service unavailable; not executed |
| Native Windows installation and browser navigation | Still require target-machine checks |

The installed package reused the development environment's dependency libraries. The UI test deliberately substituted browser fetch transport and used a simulated source-check response. Those checks exercise application behaviour; live retrieval and native Windows operation remain to be confirmed with the included download check.

## Reproducing checks

From an installed development environment:

```text
python -m pytest -q
python -m compileall -q curia_lite scripts tests
node --check curia_lite/web/app.js
python scripts/verify_integrity.py
```

`FINAL_TEST_RESULTS.txt`, `INSTALLED_SMOKE.json`, `UI_DOM_CHECK.json`, `DOCX_QA.json`, `SPARQL_QUERY_CHECK.json` and `LIVE_PROBES.json` contain the corresponding records. `SOURCE_AND_TEXT_CHANGES.diff` and `WORDING_CHANGES.json` show the code and text changes. After reviewed development changes, `python scripts/verify_integrity.py --write` updates the release file list.

## First check after updating

Close 0.1.0, set up 0.1.1 in a separate folder, and start it with the same data location. Select English under Document versions, then choose Settings → Test a document download. The check saves `diagnostics/source-check.json`. Once a document is retrieved successfully, open the previous search under Recent searches and select Retry this search. The first new catalogue lookup uses the corrected paging method.
