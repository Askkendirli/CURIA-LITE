# Verification — CURIA LITE 0.1.2

15 October 2026. This release focuses on document retrieval and literal keyword selection. Context-model scoring rules and runtime settings are retained for the next testing stage.

## Submitted searches

The French and English diagnostics both report a completed 71-document catalogue search for 1 January through 1 February 2026. The French file records two download failures. The English file records eighteen. The files contain discovery, download failures and missing-metadata details; they omit the original query definitions, returned shortlist and downloaded source bodies. REPORTED_RUN_SUMMARY.json preserves the counted findings without redistributing the complete submitted logs.

Both French failures include an XHTML response rejected for a document-type conflict. Three English documents include the same conflict (one at two alternative addresses). Other attempts report unavailable addresses, HTML/XHTML negotiation, a source timeout and an empty or verification response. These are different operations and retain separate records.

## Corrections and checks

The old reader classified a judgment as an order when a rectification note mentioned an order near its beginning. References to an Advocate General's conclusions could similarly replace its detected type. Language identification could prefer a later French quotation to an earlier English heading. The reader now takes language and type from the first standalone judicial heading. Matching dates, case identity and genuinely conflicting types remain checked.

BEFORE_AFTER_REGRESSIONS.json records a synthetic rectification example rejected by the actual 0.1.1 parser and accepted as a judgment by 0.1.2. It also records the former substring match of singular “language version” within plural “language versions”; the new whole-word phrase matcher excludes it. These reproductions demonstrate the implementation defects. They are not substitutes for the unavailable original response bodies.

The browser's lower-rating option previously permitted keyword-excluded documents into the visible results. Keyword exclusion now applies independently of the display threshold. Excluded language companions are removed from Word/CSV shortlisted groups and cannot become the group's best-rated source. JSON preserves all document outcomes.

The keyword menu now distinguishes Exact phrase, Any word/OR, All words/AND, All phrases, Any phrase and NEAR. Exclusions and quoted phrases are supported. Hover, keyboard and input-preview help explain the selected operation. Matching text is highlighted using source offsets. Legacy saved `all`/`any` settings become explicit phrase-combination operators on retry; the new default is Exact phrase.

The download path checks available language/format items and requests XHTML directly when advertised. Additional alias, language-query and EUR-Lex text-page routes remain available. Connection/response-header timeouts receive a bounded retry. A nonempty successful publication catalogue can identify an unlisted requested language or a language with only other formats. These availability outcomes retain the query time and source details. A bare 404, failed lookup or source-validation rejection remains unresolved. The release does not claim that all eighteen English versions are available or were recovered.

Previously indexed sources are re-extracted locally as required by the new reader; their raw bytes remain unchanged. Classifier cache identities include the resulting text hash and reader version. Existing model settings and the persistent workspace are retained.

## Executed validation

| Check | Result |
|---|---|
| Baseline regression suite | 98 passed on the unchanged 0.1.1 source |
| Current complete regression suite | **170 passed** |
| Python compilation | Application, setup scripts and tests passed |
| JavaScript syntax | Bundled app.js passed `node --check` |
| Exact parser/matcher regression reproduction | Passed; before/after record retained |
| Keyword acceptance helper | Ten synthetic scenarios passed; zero source-site and model calls |
| Browser interface | Chromium 144.0.7559.96 executed actual bundled JS/CSS; operator hovering, keyboard controls, phrase/OR/AND results, source highlighting, French negative controls, lower-rating exclusions, three-language labels and the self-check button passed |
| API transport for the browser check | Browser fetch was bridged to the actual loopback HTTP application server; API responses were produced by that application |
| Direct browser navigation | Administrator policy blocked navigation; recorded separately in UI_CHECK.json |
| Package build | Installable wheel built |
| Independent installed package | Ran outside the source tree using its installed wheel; ten-scenario helper, exact English shortlist, bundled assets and Word/CSV/JSON exports passed |
| Dependency installation | Audit dependencies were reused; a clean internet dependency installation was not performed |
| Word layout | One-page synthetic shortlist rendered and visually inspected |
| Live judicial download | Container DNS requests failed; target-machine download verification remains required |
| Native Windows | Not executed here; Windows scripts and hosted CI are supplied |
| Real AI inference | Not executed in this iteration |

The ten-scenario helper is part of the 170-test suite; it is not an additional ten model tests. The synthetic materials identify themselves as demonstrations. Actual model accuracy, live source availability and native Windows behaviour remain separate acceptance checks.

## A short acceptance sequence

1. Run Setup_Windows.cmd and Start_Windows.cmd from the new package. Confirm v0.1.2.
2. Select **Test keyword matching**. All ten checks should pass. The record is saved to `diagnostics/keyword-check.json` in the existing data folder.
3. Start a new local-only search with Exact phrase and `language version`, keeping the context empty and the general search purpose selected. Check the highlighted matches. OR and AND can be tested separately.
4. Repeat the January official-source search, reusing already downloaded files. Inspect any unavailable-language details or outstanding failures.
5. Continue to the AI-assisted context test after the literal workflow meets the research requirements.

The operator rules and source/format checks are detailed in docs/KEYWORD_OPERATORS.md and docs/SOURCES.md. Earlier audit files are retained under previous_v0.1.1 as historical records.
