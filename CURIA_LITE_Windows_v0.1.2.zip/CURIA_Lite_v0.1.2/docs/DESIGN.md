# Technical design

## Focused processing

CURIA LITE produces case lists. Keyword searches use the full extracted text locally. A contextual search adds a short classification containing `score`, `category`, `evidence` and `reason`. The default output ceiling is 256 tokens, and the model stays loaded for 30 minutes between requests.

Sources and assessments are cached to reduce repeat work. Every eligible document is scheduled. Fast mode submits selected passages; Complete text schedules all extracted blocks in bounded requests. Runtime depends on collection size, model loading, backend and hardware.

## Data flow

1. Validate languages, dates, document types and criteria.
2. Reuse suitable current catalogue details or perform a fresh CELLAR search.
3. Group CELEX/date entries and preserve alternative work addresses.
4. Reuse validated files and request missing language versions.
5. Check document identity, language and any known date or ECLI.
6. Apply the selected metadata and literal keyword filters.
7. Perform contextual screening when requested and validate its structured response.
8. Group related documents and save Word, CSV and JSON results.

## Retrieval revision

Discovery version 2 uses a CELEX/date cursor in place of numeric offsets. Repeated resource entries retain their alternative locations. Initial and final unique-document counts support detection of catalogue changes. Earlier catalogue cache entries are refreshed automatically after this update.

The downloader uses the CELEX endpoint, known work locations and language-specific item links. Recognised CELLAR HTTP identifiers are resolved through HTTPS. Optional EUR-Lex fallback adds a further official route. Download traces record redirects, status codes, attempted formats and the final provider.

## Storage and caches

Raw HTML and extracted text have SHA-256 hashes. Classification keys include source content, relevant metadata, query/prompt, model digest, tag, settings and schema version. Changing these inputs triggers a new assessment. The database schema and existing data location are retained in 0.1.1.

Database connections are explicitly closed. Atomic writes use a short temporary name and replacement. Each run retains its request, settings, results and errors. The Retry control loads that saved request and checks the outstanding work with the current configuration.

## Service boundaries

The standard-library HTTP server binds to 127.0.0.1. Host/origin checks and a per-process token protect API calls. Stored source text is displayed as text. Exports use validated identifiers and fixed file names; formula-like CSV values are escaped.

Ollama is accessed through a loopback endpoint. The application requires locally available model weights. Source requests use approved official hosts, secure transport, response-size limits, rate spacing and bounded retries. Browser assistance supports permitted manual interaction.

## Evaluation

The automated tests use labelled fictional sources and controlled HTTP responses to check application behaviour. A separate target-machine run is needed to assess live collection, model quality and runtime. The result files retain elapsed acquisition and screening times for that evaluation.
