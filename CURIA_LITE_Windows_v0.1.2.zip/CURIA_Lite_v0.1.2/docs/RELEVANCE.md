# Relevance levels

The five levels help decide which cases to read first. Their meaning depends on whether the search uses literal keywords or contextual assessment. Review the cited passages before using a case in research.

## Contextual assessment

| Level | Meaning |
|---|---|
| Very low (1) | No supporting evidence identified in the supplied material |
| Low (2) | An incidental or background connection |
| Medium (3) | Plausible or partial relevance requiring inspection |
| High (4) | Clear, direct evidence for the criterion |
| Very high (5) | Detailed, explicit evidence |

The comparison option looks for the current court applying a language-version comparison. General principles, party arguments, an Advocate General's own reasoning and quotations of precedent receive separate categories and a maximum Low rating. Uncertain classification is limited to Medium. A comparison finding agreement can still qualify.

Evidence identifiers point to the passages supplied for assessment. The full saved source is also available in the interface. Models can misinterpret wording or attribute an argument to the wrong participant, so checking the passage is important.

**Not assessed** records an interrupted or failed model operation. Partial assessment remains visible when only some text packets were completed.

## Literal keywords

The local search checks the full extracted text using the selected operator. A search unit is a word or a complete phrase, according to that operator. Grades describe unit coverage and occurrence counts:

- Unmatched keyword conditions and exclusion hits: `keyword-excluded`; retained in JSON and omitted from the shortlist.
- Any-word or any-phrase search with fewer than half of the units matched: Low.
- Any-word or any-phrase search with at least half of the units matched: Medium.
- All units matched once in total: Medium.
- All units matched in 2–4 total occurrences: High.
- All units matched in at least 5 total occurrences: Very high.

Choose Very low as the minimum to include all qualifying literal matches. NEAR counts qualifying nearby pairs. A contextual question can then assess the role of those expressions in the reasoning.

## Case groups and reading depth

The case group's headline score is the highest document score. Individual documents keep their own grades, types and languages. Fast mode selects useful passages for one short request. Complete text processes all extracted blocks and takes longer. JSON retains every assessment and the amount of text supplied.


## Literal-search operators in 0.1.2

The operator is applied before relevance ranking. Exact phrase is the default. Word, phrase-combination, proximity and exclusion controls are described in KEYWORD_OPERATORS.md. A failed keyword condition stays out of the shortlist even when lower ratings are displayed. A qualifying case keeps only its keyword-matched or pending document versions in Word/CSV; JSON retains all document-level outcomes.
