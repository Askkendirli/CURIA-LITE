# Troubleshooting

## Updating after failed downloads

Close the old application, extract version 0.1.1 to a new folder, then run `Setup_Windows.cmd` and `Start_Windows.cmd`. The existing data folder is reused. Check the version at the top of the page, then open Settings → **Test a document download**.

Once that succeeds, open the earlier run in Recent searches and select **Retry this search**. Saved documents and completed assessments are reused. An unfinished catalogue search is refreshed automatically.

## Source-address errors from 0.1.0

Version 0.1.0 could reject CELLAR resource redirects written as HTTP identifiers. Version 0.1.1 converts recognised Publications Office resource addresses to HTTPS and records the redirect chain. It also tries the work addresses found during discovery when the CELEX address returns 404.

A new address error includes the destination in `downloads/<CELEX>_<language>.json`. Preserve that log so the precise route can be examined.

## A document still returns 404 or 406

The requested language or file format may be unavailable at a particular address. The downloader checks alternate CELLAR locations and, when enabled, EUR-Lex. An HTTP 406 also triggers an XHTML request.

Review the download record to see which routes were attempted. Try the same CELEX and language in the official website. An HTML file saved from the official document page can be imported directly. Check that it contains the document rather than a search page or verification screen.

## Verification or an interactive page

Install browser support with `py -3.12 scripts\bootstrap.py --browser`, then enable browser assistance in Settings. Complete the provider's permitted verification in the visible window. Where automated navigation remains blocked, save the official HTML manually and import it.

## Repeated catalogue entries or an incomplete search

The new discovery process groups repeated document entries and resumes from the previous identifier. If the source catalogue changes while searching, the run records how many documents were collected and offers a retry. A shorter date range can simplify a first test and reduce the time spent collecting missing files.

## The app does not open

Run `Setup_Windows.cmd` first and check its last message. Keep the launch console open. If port 8765 is in use, run:

```powershell
.\.venv\Scripts\python.exe -m curia_lite serve --port 8766
```

## Model unavailable or slow

Start Ollama and run `ollama list`. The tag in Settings must match an installed local model. Install the default with `ollama pull ministral-3:8b`, then use **Check storage + model inventory** and **Test one real model request**.

Begin with one model worker. A first request can take longer while the model loads. `ollama ps` helps identify whether the model is using the intended processor. Closing unrelated loaded models may help. If generated JSON hits the output limit, try 384 or 512 output tokens. Increasing limits also increases possible processing time.

## An empty shortlist

Check the document dates and selected versions, then review download issues and missing metadata. Keywords are literal: a French expression requires French wording to be present. Broaden AND to OR, lower the rating threshold, or leave keywords blank for a context search.

For comparisons of language versions, choose the dedicated search purpose and read its supporting passages. Complete-text screening can help when the relevant discussion lies outside the passages chosen by Fast mode.

## Metadata needs attention

Some advanced filters depend on inspected information. Add the required details to the CELEX selection or a `document.html.metadata.json` sidecar. Confirm those values against the source before importing them.

## Local storage or changed-file errors

Choose a short, persistent local data folder with SQLite write access. Cloud-synchronised or network folders may cause locking problems. Back up the archive before moving it. If a source file has changed, preserve that copy separately and re-import the intended document.

## Sending useful feedback

Include the application version, the selected CELEX and document language, the visible error, and the corresponding download record. For model issues, include the model tag and diagnostics. The JSON result contains search settings and source details. Review these files for private research information before posting them publicly.


## The words appear separately

Select **Exact phrase** for `language version`. All words / AND intentionally allows the words to occur separately in one document. Any word / OR accepts either word. Hover over the menu options and check the preview. Matching source text is highlighted in the result.

## English keyword in French sources

Keep the context empty and choose the general search mode for a literal test. The exact phrase produces no matches when that phrase is absent from the source. Shared words such as `version`, or quoted English expressions, can legitimately appear in French documents.

## A few requested languages remain unavailable

Open the availability details to see the source catalogue’s language and format list. Some documents are not listed in the requested language or in HTML/XHTML. Retrieval errors, parser conflicts and unavailable versions remain separate records. Retry can check availability again later.

## Before testing contextual AI screening

Run **Test keyword matching** or **Test_Keywords_Windows.cmd**. Its ten temporary-archive checks need neither Ollama nor online sources. Send `diagnostics/keyword-check.json` if one fails. For a real search issue, send the run’s JSON export; the on-screen Technical details now also includes the query and parsed operator definition.
