# Source access

## The download sequence

CELLAR is the preferred source by default. A request carries the selected three-letter language code and an HTML format preference. Each redirect is checked, and recognised `http://publications.europa.eu/resource/...` addresses are converted to HTTPS before contact. Other hosts, credentials and unusual ports are rejected.

For a discovered document, the published catalogue supplies the available language versions, file formats and direct item addresses. XHTML items are requested using the corresponding format header. If necessary, the downloader continues through the CELEX address, alternative CELLAR work addresses, and the documented language-query form. HTML negotiation returning 404 or 406 can trigger an XHTML attempt. The configured EUR-Lex fallback checks both the HTML and ordinary text pages.

Every downloaded document is checked for readable text, source language, own-case identity, document type and any established date or ECLI. A catalogue response listing other available languages or formats is recorded separately when the requested HTML version is absent. Failed or empty catalogue responses remain retrieval problems. Versions missing from this search can be checked again later.

## Catalogue paging

The search groups equivalent CELLAR work addresses under a CELEX identifier and decision date. Each page continues from the last identifier/date pair. Overlapping entries are merged, keeping any useful source locations. Initial and final catalogue counts help identify updates made during the search.

A repeated page that makes no progress, a changing count, a network interruption or the page-safety limit produces a partial result with details for retry. Existing partial downloads remain saved. Catalogue caches created by 0.1.0 are refreshed through the new discovery path; valid source and classification caches are retained.

The selected publication types are CJ, CC, CO, TJ, TO, FJ and FO according to the court and document choices. The search uses document dates. Further publication types or historical formats may require a separate selection or an extended reader.

## Download records

For each requested language version, `downloads/<CELEX>_<language>.json` stores:

- the chosen provider and source addresses;
- response status codes, redirect destinations and HTTPS addresses actually requested;
- format/language negotiation and any fallback attempts;
- the final status or error.

The result JSON points to those records for unsuccessful downloads. `diagnostics/source-check.json` holds the most recent source-access test. Logs can contain research identifiers and source text; review them before sharing publicly.

## Official documentation consulted

Checked 15 October 2026:

- CELLAR resource structure: https://op.europa.eu/en/web/cellar/cellar-data
- Content and language negotiation: https://op.europa.eu/en/web/cellar/cellar-data/publications
- Metadata, expressions, manifestations and item links: https://op.europa.eu/en/web/cellar/cellar-data/metadata/knowledge-graph
- Metadata notices: https://op.europa.eu/en/web/cellar/cellar-data/metadata/metadata-notices
- InfoCuria: https://infocuria.curia.europa.eu/tabs/advanced_search

The implementation was checked against this documentation and the submitted failure report. Live availability from the target machine can be checked through Settings → Test a document download. The release test record describes the development environment's connection limits.


## Language catalogue and document headings (0.1.2)

The downloader can resolve a discovered work to its published language/format items before trying aliases. An advertised XHTML item is requested as XHTML. A 404 or 406 from HTML negotiation can trigger an XHTML attempt. The ordinary EUR-Lex TXT page is another route after the bare HTML page. Transient connection or response-header timeouts receive a bounded retry.

Document type and source language come from the first standalone judicial heading. Rectification notes, descriptions of earlier orders and references to an Advocate General’s Opinion remain part of the source and do not replace the current document’s heading. Original source bytes remain preserved during local re-extraction.

A successful catalogue response listing other language versions can establish that the requested language is unlisted there. Similarly, a listed language may have only formats other than HTML/XHTML. These cases appear under availability details, with the catalogue time and languages/formats. An empty catalogue, a network failure, or a document-validation conflict remains unresolved. Availability records are scoped to that catalogue response.

Request records include MIME type, source address, resolved address, detected language, identified heading and a short preview of a rejected response. This supports further debugging without treating every HTML page as a judicial document.
