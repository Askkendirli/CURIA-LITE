# Languages and search fields

## Language controls

**Interface language** changes the bundled core labels. English, French and German are available; detailed technical messages remain in English.

**Document versions** selects the texts to collect and analyse. The default profile includes French, English, German, Spanish, Italian, Portuguese and Dutch. The source reader recognises those languages and some additional Romanian, Polish and Czech headings. Enabling another language requires both an appropriate model and suitable source recognition.

**Query language** selects the language of the context and short model explanations. The chosen multilingual model receives the query and source text directly. Literal keywords search for their entered wording, so expressions in another language need to be provided explicitly.

**Language of the case** and **original Opinion language** describe the source's procedural or publication details. They have their own metadata filters. A French text may be a translation of an Italian-language judgment, while an Opinion may have been written originally in French.

## Field support

| Field | Where the value comes from |
|---|---|
| Decision date | Document heading, checked against catalogue metadata where available |
| Court and document type | Own-case identifiers, document heading and CELEX |
| CELEX and ECLI | Official catalogue/selection identifiers and document text |
| Case number | The document's own-case heading |
| Case or party name | Introductory material, subject to differences in historical layouts |
| Judge-Rapporteur / Advocate General | Recognised heading labels or inspected supplementary information |
| Formation or chamber | Document heading or inspected supplementary information |
| Language of case / original Opinion language | Explicit source label or inspected metadata |
| Procedure, subject, country, status, national/international context, cited provisions | Inspected selection or sidecar metadata |

Leaving a field blank includes all values. A known mismatch is excluded. When a selected filter needs information missing from a document, that item appears under **Needs metadata** for review.

For an exact advanced selection made on the official site, use a CELEX list with verified values in the format shown in `examples/selection_with_metadata.json`. Historical source formats and changes to the official interface can require additional field support.
