# Keyword operators

The default is **Exact phrase**. The operator menu explains each option on hover and keyboard focus, while a preview shows the parsed expressions before searching.

## Phrase versus words

`language version` with Exact phrase finds those words together and in that order. With Any word / OR it finds either word. With All words / AND it finds both words anywhere in one document. Combining matches from different documents or language versions never satisfies an AND condition.

A match uses whole words. `version` is distinct from `versions`, `conversion` and `versioning`. Capitalisation, Unicode whitespace, typographic apostrophes and soft hyphens are handled by the search normalisation. Accents remain significant. Exact phrases can span a line wrap within a paragraph, but cannot jump over punctuation or paragraph boundaries.

## Several expressions

Use **All phrases** or **Any phrase** with semicolon-separated expressions:

```text
language version; legal certainty
```

All phrases requires each expression intact, while allowing the expressions to occur in different parts of the same document. Any phrase requires at least one expression intact.

In Any word, All words and NEAR, double quotation marks keep expressions together:

```text
"language version" customs
```

Double quotation marks must be balanced. The preview and validation messages make malformed input visible. Operators are selected in the menu; inline Boolean formulas are not interpreted.

## Nearby expressions

NEAR accepts two different words or quoted expressions and a distance from 0 to 100 intervening words. Either order is accepted within one paragraph. A distance of zero means adjacency, allowing punctuation between the two expressions. Use Exact phrase when their exact order and punctuation matter.

## Exclusions

The Exclude field accepts individual words or complete phrases, separated with semicolons. A match to any exclusion removes that document, including before an optional AI assessment. Empty exclusions leave the positive search unchanged.

## Language tests

Keyword matching performs no translation. French `versions linguistiques` alone does not match the exact English phrase `language version`. The single word `version` can appear in both languages, so an OR search for it can legitimately match French text. An English expression actually quoted in a French judgment also matches. The document-language filter controls which source version is read.

## Results and traceability

Matched text is highlighted in source snippets. Search details save the selected operator, parsed expressions, exclusions and matching counts. The lower-ratings view keeps keyword-excluded documents out of the shortlist. JSON retains them with the status `keyword-excluded` for inspection.

Older saved requests with `logic: all` and `logic: any` map to All phrases and Any phrase, respectively. New requests use `phrase`, `any_words`, `all_words`, `all_phrases`, `any_phrases` or `near`. `keywords` and `exclude` accept text or expression arrays; `near_distance` defaults to five.

## Quick acceptance check

**Test keyword matching** runs ten checks in a temporary archive. The fixtures are synthetic and include a French negative control, a French shared-spelling example, one exact English phrase, separated English words, and English single-word examples. A passed result establishes the literal-search test conditions. AI-assisted context screening is a separate step.
