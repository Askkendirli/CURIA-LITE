from __future__ import annotations

import json
import threading
import pytest
import requests
from curia_lite.keywords import KeywordPlan, normalize, normalize_offsets
from curia_lite.query import Query, eligibility
from curia_lite.extractor import html_content,parse_metadata,EXTRACTOR_VERSION
from curia_lite.engine import execute
from curia_lite.keyword_check import fixture, run_keyword_check
from curia_lite.export import selected_cases
from curia_lite.sources import fetch_record, resolve_catalogue, VersionUnavailable, Network
from conftest import html


def test_exact_phrase_does_not_become_all_words():
    p=KeywordPlan.create('language version','phrase')
    assert p.match('The language version applies.')['qualified']
    assert not p.match('The language differs from the version.')['qualified']
    assert not p.match('The version of the language applies.')['qualified']


@pytest.mark.parametrize('mode,text,expected',[
 ('phrase','language versions',False),('phrase','LANGUAGE\u00a0version',True),
 ('phrase','language\nversion',True),('phrase','language\n\nversion',False),
 ('phrase','language, version',False),('phrase','language. Version',False),
 ('phrase','language-version',False),('phrase','sublanguage version',False),
 ('phrase','language versioning',False),('all_words','version with a different language',True),
 ('all_words','language\n\nThe version applies.',True),('all_words','language versions',False),
 ('any_words','language alone',True),('any_words','version seule',True),('any_words','conversion only',False),
 ('any_words','versions linguistiques',False),('any_words','La version française',True),
])
def test_operator_matrix(mode,text,expected):
    assert KeywordPlan.create('language version',mode).match(text)['qualified']==expected


@pytest.mark.parametrize('mode,query,text,expected',[
 ('all_phrases','language version; legal certainty','The language version provides legal certainty.',True),
 ('all_phrases','language version; legal certainty','The language differs from the version. Legal certainty.',False),
 ('any_phrases','language version; legal certainty','Legal certainty applies.',True),
 ('any_words','"language version" customs','A version in another language.',False),
 ('any_words','"language version" customs','Customs duties.',True),
 ('all_words','"language version" customs','Customs duties. The language version differs.',True),
 ('phrase','"language version"','A language version exists.',True),
])
def test_phrases_quotes(mode,query,text,expected):
    assert KeywordPlan.create(query,mode).match(text)['qualified']==expected


@pytest.mark.parametrize('text,distance,expected',[
 ('language version',0,True),('version language',0,True),('language of the version',1,False),
 ('language of the version',2,True),('version of this language',2,True),
 ('language\n\nversion',100,False),('language versions',100,False),
 ('language one two three four version',3,False),
])
def test_near_distance(text,distance,expected):
    assert KeywordPlan.create('language version','near',distance=distance).match(text)['qualified']==expected


def test_exclude_never_promotes_document():
    p=KeywordPlan.create('language version','phrase',['customs'])
    assert not p.match('The customs language version.')['qualified']
    assert p.match('The language version.')['qualified']


@pytest.mark.parametrize('value',['SÉCURITÉ\u00a0juridique','se\u0301curite\u0301 juridique','l’établissement','Straße','ver\u00adsion'])
def test_evidence_offsets_preserved(value):
    n,starts,ends=normalize_offsets(value)
    assert n==normalize(value)
    result=KeywordPlan.create(n,'phrase').match('Prefix '+value+' suffix')
    assert result['qualified']
    span=result['matches'][0]
    assert span['text'][span['start']:span['end']]==value


def test_accents_remain_distinct():
    assert not KeywordPlan.create('securite','phrase').match('sécurité')['qualified']


@pytest.mark.parametrize('query,mode',[('"language version','any_words'),('language;version','phrase'),('language','near'),('language version court','near')])
def test_bad_operator_input(query,mode):
    with pytest.raises(ValueError):KeywordPlan.create(query,mode)


@pytest.mark.parametrize('legacy,current',[('all','all_phrases'),('any','any_phrases')])
def test_saved_queries_have_explicit_legacy_mapping(cfg,legacy,current):
    q=Query.parse({'source_mode':'local','keywords':['language version','legal certainty'],'logic':legacy},cfg)
    assert q.logic==current


@pytest.mark.parametrize('lang,note',[('en','[Text rectified by order of 19 March 2026]'),
 ('fr','[Texte rectifié par ordonnance du 19 mars 2026]'),
 ('en','The order of the Vice-President is discussed in this appeal.'),
 ('fr','Les conclusions de l’avocat général sont discutées dans cette affaire.'),
 ('de','Der Beschluss wurde im Verfahren erlassen.')])
def test_judgment_type_comes_from_own_heading(store,lang,note):
    raw=html(lang=lang).decode()
    raw=raw.replace('</h1>', '</h1><p>'+note+'</p>',1) if '</h1>' in raw else raw.replace('</p>','</p><p>'+note+'</p>',1)
    doc=store.ingest(raw.encode(),language=lang,celex='62025CJ0901')
    assert doc['doc_type']=='judgment' and doc['extractor_version']==EXTRACTOR_VERSION


def test_order_remains_order_and_wrong_celex_rejected(store):
    raw=html(lang='en').replace(b'JUDGMENT OF THE COURT',b'ORDER OF THE COURT')
    assert store.ingest(raw,language='en',celex='62025CO0901')['doc_type']=='order'
    with pytest.raises(ValueError):store.ingest(raw,language='en',celex='62025CJ0901')


def test_first_heading_language_wins_over_later_quotation(store):
    raw=html(lang='en',body='1 The Court cites a French title.\n\nARRÊT DE LA COUR\n\nQuoted text.').decode()
    text,lang=html_content(raw)
    assert lang=='en'
    assert parse_metadata(text,celex_hint='62025CJ0901',retrieval_language=lang)['doc_type']=='judgment'


def test_portal_controls_do_not_create_keyword_matches(store,cfg):
    raw=fixture('fr',9006,'Le tribunal analyse les versions linguistiques.')
    raw=raw.replace(b'<body>',b'<body><nav>language version</nav><div id="TexteOnly">').replace(b'</body>',b'</div></body>')
    store.ingest(raw,language='fr',celex='62025CJ9006')
    result=execute(store.home,cfg,{'source_mode':'local','keywords':'language version','logic':'phrase','languages':['fr'],'min_score':1})
    assert result['documents'][0]['status']=='keyword-excluded'
    assert selected_cases(result)==[] and result['summary']['model_calls']==0


def test_french_literal_english_quote_is_a_real_match(store,cfg):
    raw=fixture('fr',9006,'La Cour cite les mots anglais « language version » dans sa discussion.')
    store.ingest(raw,language='fr',celex='62025CJ9006')
    r=execute(store.home,cfg,{'source_mode':'local','keywords':'language version','logic':'phrase','languages':['fr']})
    assert len(selected_cases(r))==1


def test_old_archive_reextracts_preserving_raw_and_settings(store,cfg):
    d=store.ingest(html(),language='fr',celex='62025CJ0901')
    raw=(store.home/d['source_path']).read_bytes()
    with store.connect() as con:
        old={**d};old.pop('extractor_version');old['case_name']='Verified title'
        con.execute('UPDATE documents SET metadata=? WHERE doc_id=?',(json.dumps(old),d['doc_id']))
    updated,_=store.read(d['doc_id'])
    assert updated['extractor_version']==EXTRACTOR_VERSION
    assert (store.home/d['source_path']).read_bytes()==raw
    assert updated['sha256']==d['sha256']


def test_self_check_uses_no_source_or_model_calls(tmp_path,cfg):
    result=run_keyword_check(tmp_path,cfg)
    assert result['passed'] and len(result['checks'])==10
    assert result['model_calls']==0 and result['network_calls']==0


WORK='http://publications.europa.eu/resource/cellar/7c0b9cad-fcf8-11f0-8da5-01aa75ed71a1'
ITEM=WORK+'.0009.05/DOC_1'
def row(lang='ENG',fmt='xhtml',item=ITEM):
    r={'work':{'value':WORK},'language':{'value':'http://publications.europa.eu/resource/authority/language/'+lang},'format':{'value':fmt}}
    if item:r['item']={'value':item}
    return r


def error404(url):
    resp=requests.Response();resp.status_code=404;resp.url=url
    return requests.HTTPError('missing',response=resp)


def test_catalogue_goes_straight_to_xhtml(cfg):
    calls=[]
    class Net:
        cancel=threading.Event()
        def get(self,url,params=None,headers=None):
            calls.append((url,headers))
            if 'sparql' in url:return json.dumps({'results':{'bindings':[row(fmt='http://example/format/XHTML')]}}).encode(),url,{}
            if 'DOC_1' in url:
                assert headers['Accept']=='application/xhtml+xml'
                return html(lang='en'),url,{}
            raise AssertionError('An unnecessary alias was requested')
    record={'celex':'62025CJ0901','work_uri':WORK}
    raw,_,_=fetch_record(record,'en',cfg,Net())
    assert raw==html(lang='en') and len(calls)==2


def test_confirmed_unlisted_english_is_availability_record(cfg):
    class Net:
        cancel=threading.Event()
        def get(self,url,params=None,headers=None):
            if 'sparql' in url:return json.dumps({'results':{'bindings':[row('FRA')]}}).encode(),url,{}
            raise error404(url)
    with pytest.raises(VersionUnavailable) as exc:fetch_record({'celex':'62025CJ0901','work_uri':WORK},'en',cfg,Net())
    assert exc.value.available_languages==['fr'] and exc.value.reason_code=='language-not-listed'


def test_empty_catalogue_keeps_real_download_failure(cfg):
    class Net:
        cancel=threading.Event()
        def get(self,url,**kw):
            if 'sparql' in url:return b'{"results":{"bindings":[]}}',url,{}
            raise error404(url)
    with pytest.raises(ValueError) as exc:fetch_record({'celex':'62025CJ0901'},'en',cfg,Net())
    assert not isinstance(exc.value,VersionUnavailable)


def test_real_type_conflict_is_not_relabelled_unavailable(cfg):
    class Net:
        cancel=threading.Event()
        def get(self,url,**kw):
            if 'sparql' in url:return json.dumps({'results':{'bindings':[row('FRA')]}}).encode(),url,{}
            return html(lang='en').replace(b'JUDGMENT OF THE COURT',b'ORDER OF THE COURT'),url,{}
    with pytest.raises(ValueError) as exc:fetch_record({'celex':'62025CJ0901','work_uri':WORK},'en',cfg,Net())
    assert not isinstance(exc.value,VersionUnavailable)


def test_404_html_retries_xhtml(cfg):
    seen=[]
    class Net:
        cancel=threading.Event()
        def get(self,url,headers=None,**kw):
            seen.append(headers['Accept'])
            if headers['Accept']=='text/html':raise error404(url)
            return html(),url,{}
    raw,_,_=fetch_record({'celex':'62025CJ0901'},'fr',cfg,Net())
    assert raw==html() and seen==['text/html','application/xhtml+xml']


def test_standard_eurlex_text_fallback_retains_requested_language(cfg):
    cfg={**cfg,'provider':'eurlex'}
    class Net:
        cancel=threading.Event()
        def get(self,url,**kw):
            if '/TXT/HTML/' in url:return b'<html lang="en">Temporarily unavailable</html>',url,{}
            assert '/FR/TXT/' in url
            return html(),url,{}
    assert fetch_record({'celex':'62025CJ0901'},'fr',cfg,Net())[0]==html()


def test_wrong_language_never_passes_catalogue_route(cfg):
    class Net:
        cancel=threading.Event()
        def get(self,url,**kw):
            if 'sparql' in url:return json.dumps({'results':{'bindings':[row('FRA')]}}).encode(),url,{}
            return html(lang='en'),url,{}
    with pytest.raises(ValueError):fetch_record({'celex':'62025CJ0901','work_uri':WORK},'fr',cfg,Net())


def test_alias_transport_timeout_is_retried(cfg,monkeypatch):
    seen=[]
    class Response:
        status_code=200;headers={}
        def __enter__(self):return self
        def __exit__(self,*a):pass
        def raise_for_status(self):pass
        def iter_content(self,*a):yield b'valid response'
    class Session:
        def __init__(self):self.headers={}
        def __enter__(self):return self
        def __exit__(self,*a):pass
        def get(self,url,**kw):
            seen.append(url)
            if len(seen)==1:raise requests.ReadTimeout('fixture timeout')
            return Response()
    monkeypatch.setattr('curia_lite.sources.requests.Session',Session)
    cfg={**cfg,'request_interval':0}
    assert Network(cfg).get('https://publications.europa.eu/resource/celex/62025CJ0901')[0]==b'valid response'
    assert len(seen)==2


def test_keyword_preview_and_acceptance_api(tmp_path):
    from http.server import ThreadingHTTPServer
    from curia_lite.server import Application,handler_class
    app=Application(tmp_path)
    server=ThreadingHTTPServer(('127.0.0.1',0),handler_class(app))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        with requests.Session() as s:
            s.trust_env=False;headers={'X-Curia-Token':app.token};url=f'http://127.0.0.1:{server.server_port}'
            for mode,units in [('phrase',['language version']),('any_words',['language','version']),('all_words',['language','version'])]:
                r=s.post(url+'/api/keyword-preview',headers=headers,json={'keywords':'language version','logic':mode})
                assert r.status_code==200 and r.json()['units']==units
            r=s.post(url+'/api/keyword-check',headers=headers,json={})
            assert r.status_code==200 and r.json()['passed']
    finally:server.shutdown();server.server_close()


def test_unlisted_versions_recorded_without_false_negative(store,cfg):
    class Net:
        cancel=threading.Event()
        def check(self):pass
        def get(self,url,**kw):
            if 'sparql' in url:return json.dumps({'results':{'bindings':[row('FRA')]}}).encode(),url,{}
            raise error404(url)
    result=execute(store.home,cfg,{'source_mode':'auto','languages':['en'],'keywords':'language version',
                 'date_from':'2025-01-01','date_to':'2025-12-31'},selection={'records':[{'celex':'62025CJ0901','work_uri':WORK}]},network=Net())
    assert result['status']=='completed-with-unavailable-versions'
    assert result['summary']['unavailable_versions']==1 and not result['documents'] and not result['failures']
    assert result['unavailable_versions'][0]['available_languages']==['fr']


def test_keyword_failures_never_enter_exported_shortlist():
    rows=[{'score':3,'case_name':'a','case_numbers':['C-1/25'],'best_document':'en','documents':[
        {'doc_id':'en','status':'assessed','retrieval_language':'en'},
        {'doc_id':'fr','status':'keyword-excluded','retrieval_language':'fr'}]},
        {'score':1,'case_numbers':['C-2/25'],'documents':[{'doc_id':'b','status':'keyword-excluded'}]}]
    chosen=selected_cases({'query':{'min_score':1},'cases':rows})
    assert len(chosen)==1 and [d['doc_id'] for d in chosen[0]['documents']]==['en']
    assert len(rows[0]['documents'])==2


def test_temporary_test_archive_does_not_pollute_user_archive(tmp_path,cfg):
    from curia_lite.store import Store
    assert run_keyword_check(tmp_path,cfg)['passed']
    assert Store(tmp_path).stats()['documents']==0


def test_no_exclusion_based_on_interface_language_only(store):
    raw=html(lang='fr').replace(b'<html lang="fr">',b'<html lang="en">')
    assert store.ingest(raw,language='fr',celex='62025CJ0901')['retrieval_language']=='fr'


def test_excluded_companion_cannot_rate_pending_case():
    from curia_lite.query import case_groups
    documents=[{'doc_id':'fr','case_numbers':['C-1/25'],'status':'keyword-excluded','score':1,'label':'Very low'},
               {'doc_id':'en','case_numbers':['C-1/25'],'status':'not-assessed','score':None,'label':'Not assessed'}]
    group=case_groups(documents)[0]
    assert group['best_document']=='en' and group['score'] is None and group['label']=='Not assessed'


def test_excluded_companion_cannot_be_shortlist_best_document():
    from curia_lite.query import case_groups
    documents=[{'doc_id':'fr','case_numbers':['C-1/25'],'status':'keyword-excluded','score':1,'label':'Very low'},
               {'doc_id':'en','case_numbers':['C-1/25'],'status':'assessed','score':1,'label':'Very low'}]
    groups=case_groups(documents)
    selected=selected_cases({'query':{'min_score':1},'cases':groups})
    assert selected[0]['best_document']=='en' and [d['doc_id'] for d in selected[0]['documents']]==['en']
