"""Regression fixtures reproduce source-routing and pagination failures from the submitted log."""
from __future__ import annotations
import json
import threading
from pathlib import Path
from urllib.parse import urlsplit

import pytest
import requests

from curia_lite.common import trusted_url
from curia_lite.query import Query
from curia_lite.sources import Network, fetch_record, discover, discovery_query, manifest_records
from conftest import html

WORK_A='http://publications.europa.eu/resource/cellar/aaaaaaaa-0000-4000-8000-000000000001'
WORK_B='http://publications.europa.eu/resource/cellar/aaaaaaaa-0000-4000-8000-000000000002'


def error_404(url):
    r=requests.Response();r.status_code=404;r.url=url
    return requests.HTTPError('404 document alias',response=r)


def test_http_cellar_resource_normalised_to_https():
    assert trusted_url(WORK_A,cellar=True)==WORK_A.replace('http:','https:',1)


@pytest.mark.parametrize('url',['http://example.org/resource/cellar/a','http://publications.europa.eu.evil.test/resource/cellar/a',
 'https://publications.europa.eu:8123/resource/cellar/a','http://publications.europa.eu/private','https://user:pass@publications.europa.eu/resource/cellar/a'])
def test_unsafe_source_urls_remain_blocked(url):
    with pytest.raises(ValueError):trusted_url(url,cellar=True)


def test_documented_http_redirect_uses_tls_and_preserves_language(cfg,monkeypatch):
    calls=[]
    class Response:
        def __init__(self,url,status,headers=None,raw=b'valid file'):
            self.url=url;self.status_code=status;self.headers=headers or {};self.raw=raw
        def __enter__(self):return self
        def __exit__(self,*a):pass
        def raise_for_status(self):pass
        def iter_content(self,*a):yield self.raw
    class Session:
        def __init__(self):self.headers={}
        def __enter__(self):return self
        def __exit__(self,*a):pass
        def get(self,url,**kw):
            calls.append((url,kw))
            if len(calls)==1:return Response(url,303,{'Location':WORK_A+'.0001.01/DOC_1'})
            return Response(url,200)
    monkeypatch.setattr('curia_lite.sources.requests.Session',Session)
    cfg['request_interval']=0
    net=Network(cfg)
    body,resolved,_=net.get('https://publications.europa.eu/resource/celex/62025CJ0901',headers={'Accept-Language':'eng','Accept':'text/html'})
    assert body==b'valid file'
    assert all(url.startswith('https:') for url,_ in calls)
    assert calls[-1][1]['headers']['Accept-Language']=='eng'
    assert resolved.endswith('/DOC_1')


def test_celex_404_tries_discovered_cellar_work(cfg):
    class Net:
        cancel=threading.Event()
        def get(self,url,**kw):
            if '/resource/celex/' in url:raise error_404(url)
            if url==WORK_A.replace('http:','https:'):return html(),url,{'Content-Type':'text/html'}
            raise ValueError('Unexpected fallback '+url)
    raw,requested,resolved=fetch_record({'celex':'62025CJ0901','work_uri':WORK_A},'fr',cfg,Net())
    assert raw==html() and requested==WORK_A.replace('http:','https:')


def test_preserved_work_alias_is_used_after_first_alias_404(cfg):
    class Net:
        cancel=threading.Event()
        def get(self,url,**kw):
            if url==WORK_B.replace('http:','https:'):return html(),url,{}
            raise error_404(url)
    raw,_,resolved=fetch_record({'celex':'62025CJ0901','work_uri':WORK_A,'work_uris':[WORK_A,WORK_B]},'fr',cfg,Net())
    assert raw==html() and resolved==WORK_B.replace('http:','https:')


def test_selection_merges_duplicate_celex_locations():
    records=manifest_records([{'celex':'62025CJ0901','work_uri':WORK_A},{'celex':'62025CJ0901','work_uri':WORK_B}])
    assert len(records)==1 and records[0]['work_uris']==[WORK_A,WORK_B]


def test_selection_rejects_date_conflict():
    with pytest.raises(ValueError):
        manifest_records([{'celex':'62025CJ0901','delivery_date':'2025-01-01'},
                          {'celex':'62025CJ0901','delivery_date':'2025-02-01'}])


def test_discovery_uses_unique_documents_and_cursor(cfg):
    q=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions']},cfg)
    text=discovery_query(q)
    assert 'GROUP_CONCAT' in text and 'GROUP BY' in text and 'OFFSET' not in text


def test_grouped_discovery_retains_aliases_and_counts_unique_cases(store,cfg):
    class Net:
        cancel=threading.Event()
        def get(self,url,params=None,headers=None):
            q=params['query']
            if 'COUNT' in q:rows=[{'total':{'value':'1'}}]
            elif 'FILTER(?celex >' in q:rows=[]
            else:rows=[{'celex':{'value':'62025CJ0901'},'date':{'value':'2025-10-14'},'work_uris':{'value':WORK_A+'|'+WORK_B}}]
            return json.dumps({'results':{'bindings':rows}}).encode(),url,{}
    q=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions']},cfg)
    r=discover(q,cfg,store,Net(),lambda *a,**kw:None)
    assert r['complete'] and r['expected']==1 and len(r['records'])==1
    assert len(r['records'][0]['work_uris'])==2


def test_earlier_page_overlap_is_ignored_when_cursor_advances(store,cfg):
    class Net:
        cancel=threading.Event()
        n=0
        def get(self,url,params=None,headers=None):
            if 'COUNT' in params['query']:rows=[{'total':{'value':'2'}}]
            else:
                self.n+=1
                a={'celex':{'value':'62025CJ0901'},'date':{'value':'2025-10-14'},'work_uris':{'value':WORK_A}}
                b={'celex':{'value':'62025CJ0902'},'date':{'value':'2025-10-14'},'work_uris':{'value':WORK_B}}
                rows=[a] if self.n==1 else [a,b] if self.n==2 else []
            return json.dumps({'results':{'bindings':rows}}).encode(),url,{}
    q=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions']},cfg)
    r=discover(q,cfg,store,Net(),lambda *a,**kw:None)
    assert r['complete'] and len(r['records'])==2


def test_requested_footer_sentence_removed():
    from importlib.resources import files
    text=files('curia_lite').joinpath('web','index.html').read_text('utf-8')
    assert 'Selected-snapshot coverage is recorded, not assumed' not in text


def test_html_format_negotiation_retries_xhtml(cfg):
    seen=[]
    class Net:
        cancel=threading.Event()
        def get(self,url,headers=None,**kw):
            seen.append(headers['Accept'])
            if headers['Accept']=='text/html':
                r=requests.Response();r.status_code=406;r.url=url
                raise requests.HTTPError('format unavailable',response=r)
            return html(),url,{'Content-Type':'application/xhtml+xml'}
    raw,_,_=fetch_record({'celex':'62025CJ0901'},'fr',cfg,Net())
    assert raw==html() and seen==['text/html','application/xhtml+xml']


def test_item_resolver_uses_selected_language(cfg):
    target=WORK_B+'.0001.01/DOC_1';queries=[]
    class Net:
        cancel=threading.Event()
        def get(self,url,params=None,headers=None):
            if 'sparql' in url:
                queries.append(params['query'])
                return json.dumps({'results':{'bindings':[{'item':{'value':target},'format':{'value':'html'}}]}}).encode(),url,{}
            if '/DOC_1' in url:return html(),url,{}
            raise error_404(url)
    raw,_,resolved=fetch_record({'celex':'62025CJ0901'},'fr',cfg,Net())
    assert raw==html() and resolved.startswith('https://')
    assert 'authority/language/FRA' in queries[0] and 'item_belongs_to_manifestation' in queries[0]


@pytest.mark.parametrize('enabled',[True,False])
def test_eurlex_fallback_can_be_selected(cfg,enabled):
    calls=[]
    class Net:
        cancel=threading.Event()
        def get(self,url,**kwargs):
            calls.append(url)
            if 'eur-lex.europa.eu' in url:return html(),url,{}
            if 'sparql' in url:return b'{"results":{"bindings":[]}}',url,{}
            raise error_404(url)
    cfg['eurlex_fallback']=enabled
    if enabled:
        raw,url,_=fetch_record({'celex':'62025CJ0901'},'fr',cfg,Net())
        assert raw==html() and url.startswith('https://eur-lex.europa.eu/')
    else:
        with pytest.raises(ValueError):fetch_record({'celex':'62025CJ0901'},'fr',cfg,Net())
        assert all('eur-lex' not in u for u in calls)


def test_wrong_language_remains_failure_on_every_route(cfg):
    class Net:
        cancel=threading.Event()
        def get(self,url,**kwargs):
            if 'sparql' in url:return b'{"results":{"bindings":[]}}',url,{}
            return html(lang='de'),url,{}
    with pytest.raises(ValueError) as err:fetch_record({'celex':'62025CJ0901'},'fr',cfg,Net())
    assert err.value.attempts and all('error' in x for x in err.value.attempts)


def test_wrong_date_remains_failure(cfg):
    class Net:
        cancel=threading.Event()
        def get(self,url,**kwargs):
            if 'sparql' in url:return b'{"results":{"bindings":[]}}',url,{}
            return html(),url,{}
    with pytest.raises(ValueError):fetch_record({'celex':'62025CJ0901','delivery_date':'2025-10-13'},'fr',cfg,Net())


def test_source_diagnostics_does_not_call_ollama(tmp_path,cfg,monkeypatch):
    import curia_lite.diagnostics as diagnostics
    class Bomb:
        def __init__(self,*args):raise AssertionError('Source testing must not call the model')
    monkeypatch.setattr(diagnostics,'Ollama',Bomb)
    monkeypatch.setattr('curia_lite.sources.fetch_record',lambda *a:(html(), 'https://publications.europa.eu/resource/celex/62025CJ0901', 'https://publications.europa.eu/resource/cellar/example'))
    r=diagnostics.diagnose(tmp_path,cfg,sources=True,source_language='fr',celex='62025CJ0901')
    assert r['ok'] and r['checks']['source_access']['status']=='passed'
    assert r['checks']['real_inference']['status']=='not-run'
    assert (tmp_path/'diagnostics/source-check.json').is_file()


def test_partial_discovery_never_uses_old_catalogue_cache(store,cfg):
    from curia_lite.common import utc_now,digest
    scope=['2025-01-01','2025-12-31',['CJ','TJ'],'']
    store.cache('discovery:'+digest(json.dumps(scope)),{'complete':True,'at':utc_now(),'scope':scope,'records':[]})
    class Net:
        cancel=threading.Event()
        calls=0
        def get(self,*a,**kw):
            self.calls+=1
            return b'{"results":{"bindings":[{"total":{"value":"0"}}]}}' if 'COUNT' in kw['params']['query'] else b'{"results":{"bindings":[]}}',a[0],{}
    q=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions']},cfg)
    net=Net();result=discover(q,cfg,store,net,lambda *a,**kw:None)
    assert net.calls and result['complete'] and not result['cached']


def test_no_progress_discovery_stops_with_saved_records(store,cfg):
    class Net:
        cancel=threading.Event()
        calls=0
        def get(self,url,params=None,headers=None):
            self.calls+=1
            if 'COUNT' in params['query']:rows=[{'total':{'value':'5'}}]
            else:rows=[{'celex':{'value':'62025CJ0901'},'date':{'value':'2025-10-14'},'work_uris':{'value':WORK_A}}]
            return json.dumps({'results':{'bindings':rows}}).encode(),url,{}
    q=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions']},cfg)
    net=Net();r=discover(q,cfg,store,net,lambda *a,**kw:None)
    assert not r['complete'] and len(r['records'])==1 and net.calls<=6 and r['errors']


def test_download_trace_saved_for_success_and_failure(store,cfg):
    from curia_lite.sources import obtain
    class Net:
        cancel=threading.Event()
        def check(self):pass
        def reset_trace(self):pass
        def trace(self):return [{'url':'https://publications.europa.eu/resource/celex/62025CJ0901','status':200}]
        def get(self,url,**kwargs):return html(),url,{}
    q=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions']},cfg)
    r=obtain([{'celex':'62025CJ0901'}],q,cfg,store,Net(),lambda *a,**kw:None)
    assert len(r['documents'])==1
    log=json.loads((store.home/'downloads/62025CJ0901_fr.json').read_text())
    assert log['status']=='saved' and log['network_trace'][0]['status']==200


def test_old_settings_gain_new_fallback_without_losing_model(tmp_path,cfg):
    from curia_lite.settings import load
    cfg.pop('eurlex_fallback',None);cfg['model']='ministral-3:14b'
    (tmp_path/'settings.json').write_text(json.dumps(cfg))
    updated=load(tmp_path)
    assert updated['model']=='ministral-3:14b' and updated['eurlex_fallback'] is True


def test_browser_fallback_respects_provider_choice(cfg,monkeypatch):
    cfg.update(browser_fallback=True,eurlex_fallback=False)
    captured=[]
    class Net:
        cancel=threading.Event()
        def get(self,url,**kwargs):
            if 'sparql' in url:return b'{"results":{"bindings":[]}}',url,{}
            raise error_404(url)
    def fake_browser(url,config,cancel,headers=None):
        captured.append((url,headers))
        return html(),url,{}
    monkeypatch.setattr('curia_lite.sources.browser_fetch',fake_browser)
    raw,requested,_=fetch_record({'celex':'62025CJ0901'},'fr',cfg,Net())
    assert raw==html() and requested.startswith('https://publications.europa.eu/')
    assert captured[0][1]['Accept-Language']=='fra'


def test_retry_api_reuses_saved_query_and_refreshes_incomplete_discovery(tmp_path,monkeypatch):
    from curia_lite.common import write_json
    from curia_lite.server import Application,handler_class
    from http.server import ThreadingHTTPServer
    app=Application(tmp_path/'app');ident='1234567890abcdef';calls=[]
    query={'source_mode':'auto','refresh':False,'date_from':'2026-01-01','date_to':'2026-10-15','keywords':['language versions']}
    selection={'records':[{'celex':'62025CJ0901'}]}
    write_json(app.home/'runs'/ident/'request.json',{'query':query,'selection':selection})
    write_json(app.home/'runs'/ident/'results.json',{'discovery':{'complete':False}})
    def fake_start(config,data,selection=None):
        calls.append((config,data,selection));return 'fedcba0987654321'
    monkeypatch.setattr(app.jobs,'start',fake_start)
    server=ThreadingHTTPServer(('127.0.0.1',0),handler_class(app))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        with requests.Session() as session:
            session.trust_env=False
            r=session.post(f'http://127.0.0.1:{server.server_port}/api/retry',json={'run_id':ident},headers={'X-Curia-Token':app.token})
            assert r.status_code==200 and r.json()['run_id']=='fedcba0987654321'
        assert calls[0][1]['refresh'] is True
        assert calls[0][1]['keywords']==query['keywords'] and calls[0][2]==selection
    finally:server.shutdown();server.server_close()


def test_rejected_redirect_records_destination_before_next_request(cfg,monkeypatch):
    calls=[]
    class Response:
        status_code=303;headers={'Location':'https://malicious.example/file'}
        def __enter__(self):return self
        def __exit__(self,*a):pass
    class Session:
        def __init__(self):self.headers={}
        def __enter__(self):return self
        def __exit__(self,*a):pass
        def get(self,url,**kwargs):calls.append(url);return Response()
    monkeypatch.setattr('curia_lite.sources.requests.Session',Session)
    cfg['request_interval']=0
    net=Network(cfg)
    with pytest.raises(ValueError):net.get('https://publications.europa.eu/resource/celex/62025CJ0901')
    assert len(calls)==1 and net.trace()[0]['location']=='https://malicious.example/file'
