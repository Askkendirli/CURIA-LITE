from __future__ import annotations
import copy
import json
import threading
from pathlib import Path

import pytest

from curia_lite.common import normalise_search, workspace_path
from curia_lite.engine import execute
from curia_lite.export import csv_cell
from curia_lite.query import Query, case_groups, eligibility, keyword_hits
from curia_lite.screening import select_evidence, valid_classification, semantic_result
from curia_lite.settings import load,save,validate
from curia_lite.sources import discovery_query,manifest_records
from conftest import FakeModel,html


@pytest.mark.parametrize('lang',['fr','en','de','es','it','pt','nl'])
def test_native_document_languages(store,lang):
    m=store.ingest(html(lang=lang),language=lang,celex='62025CJ0901')
    assert m['delivery_date']=='2025-10-14'
    assert m['case_numbers']==['C-901/25']
    assert m['retrieval_language']==lang


def test_wrong_language_rejected(store):
    with pytest.raises(ValueError):store.ingest(html(lang='de'),language='fr')


def test_wrong_celex_case(store):
    with pytest.raises(ValueError):store.ingest(html(),celex='62025CJ0902')


def test_wrong_celex_document_type(store):
    with pytest.raises(ValueError):store.ingest(html(),celex='62025CC0901')


def test_empty_blocked(store):
    for value in [b'',b'<html lang="fr">Verify you are not a robot</html>']:
        with pytest.raises(ValueError):store.ingest(value)


def test_own_case_not_cited_case(store):
    m=store.ingest(html(body='1 La demande vise cette affaire. Dans l’affaire C-456/12, la Cour a exposé un autre point. Cette mention ne désigne pas le litige en cours.'),celex='62025CJ0901')
    assert m['case_numbers']==['C-901/25']


def test_integrity_detects_changed_raw(store):
    m=store.ingest(html(),celex='62025CJ0901')
    (store.home/m['source_path']).write_text('changed')
    with pytest.raises(ValueError):store.read(m['doc_id'])
    assert store.lookup('62025CJ0901','fr') is None


def test_reingest_retains_known_metadata(store):
    m=store.ingest(html(),celex='62025CJ0901',side={'judge_rapporteur':'Example Judge'})
    again=store.ingest(html())
    assert again['celex']==m['celex']
    assert again['judge_rapporteur']=='Example Judge'


def test_metadata_date_conflict(store):
    with pytest.raises(ValueError):store.ingest(html(),side={'delivery_date':'2025-01-01'})


def test_bad_cache_hash(store):
    store.cache('test',{'score':4})
    with store.connect() as con:con.execute("UPDATE cache SET data='{}' WHERE key='test'")
    assert store.cached('test') is None


def test_unicode_literal_search():
    assert keyword_hits('SÉCURITÉ JURIDIQUE et l’établissement',['sécurité juridique',"l'établissement"])==['sécurité juridique',"l'établissement"]
    assert keyword_hits('wildcard abcdef',['%','_'])==[]
    assert keyword_hits('securite',['sécurité'])==[]


@pytest.mark.parametrize('values',[{'num_ctx':'8192'},{'num_predict':999999},{'native_languages':[]},{'browser_fallback':'false'},
                                  {'ollama_url':'https://remote.example'},{'model':'ministral:cloud'},{'unknown':12},{'llm_workers':True}])
def test_bad_settings(values):
    with pytest.raises(ValueError):validate(values)


def test_settings_rejection_does_not_change_file(tmp_path):
    load(tmp_path);before=(tmp_path/'settings.json').read_bytes()
    with pytest.raises(ValueError):save(tmp_path,{'num_ctx':10})
    assert (tmp_path/'settings.json').read_bytes()==before


@pytest.mark.parametrize('values',[{'source_mode':'auto'},{'source_mode':'local','keywords':['x'],'languages':['ro']},
    {'source_mode':'local','context':' '.join(['word']*31)},{'source_mode':'local','context':'x','filters':{'not-real':'x'}},
    {'source_mode':'local','context':'x','types':[]},{'source_mode':'local','context':'x','min_score':6}])
def test_query_validation(cfg,values):
    with pytest.raises(ValueError):Query.parse(values,cfg)


def test_unknown_metadata_not_silently_included(store,cfg):
    m=store.ingest(html(),celex='62025CJ0901')
    q=Query.parse({'source_mode':'local','keywords':['versions'],'filters':{'subject_matter':'tax'}},cfg)
    state,missing=eligibility(m,q)
    assert state=='metadata-unresolved' and missing==['subject_matter']


def test_identity_filter_exact(store,cfg):
    m=store.ingest(html(),celex='62025CJ0901')
    q=Query.parse({'source_mode':'local','keywords':['versions'],'filters':{'case_number':'C-90/25'}},cfg)
    assert eligibility(m,q)[0]=='excluded'


def test_case_groups_transitive_joined():
    rows=[{'doc_id':'a','case_numbers':['C-1/24'],'score':3}, {'doc_id':'b','case_numbers':['C-1/24','C-2/24'],'score':4},
          {'doc_id':'c','case_numbers':['C-2/24'],'score':5}]
    assert len(case_groups(rows))==1
    assert case_groups(rows)[0]['score']==5


def test_full_mode_does_not_drop_tail_under_small_budget(cfg):
    q=Query.parse({'source_mode':'local','context':'court comparison','depth':'full'},cfg)
    text='\n\n'.join(f'{i} UNIQUE_MARKER_{i} '+('é à 中 😀 '*120) for i in range(1,12))
    packets,total=select_evidence(text,q,'fr',cfg,budget=600)
    assert sum(len(p) for p in packets)==total
    joined=''.join(b['text'] for p in packets for b in p)
    for i in range(1,12):assert f'UNIQUE_MARKER_{i}' in joined
    assert all(len(json.dumps(p,ensure_ascii=False).encode())<=600 for p in packets)


def test_fast_mode_one_packet(cfg):
    q=Query.parse({'source_mode':'local','context':'comparison','preset':'court_language_comparison'},cfg)
    text='\n\n'.join(f'{i} background '+('word '*500) for i in range(1,15))+'\n\n99 Une divergence entre versions linguistiques est analysée.'
    packets,total=select_evidence(text,q,'fr',cfg)
    assert len(packets)==1
    assert any('divergence' in b['text'] for b in packets[0])
    assert len(packets[0])<total


@pytest.mark.parametrize('category',['general_multilingual_principle','party_argument','quoted_precedent_only','advocate_general_comparison'])
def test_comparison_preset_downgrades_nonjudicial_evidence(cfg,category):
    q=Query.parse({'source_mode':'local','preset':'court_language_comparison'},cfg)
    d={'score':5,'category':category,'evidence':[1],'reason':'Test'}
    assert valid_classification(d,[{'id':1}],{'doc_type':'judgment'},q)['score']==2


def test_opinion_not_proof_of_current_court(cfg):
    q=Query.parse({'source_mode':'local','preset':'court_language_comparison'},cfg)
    d={'score':5,'category':'applied_current_comparison','evidence':[1],'reason':'Test'}
    assert valid_classification(d,[{'id':1}],{'doc_type':'opinion'},q)['score']==2


def test_unavailable_evidence_rejected(cfg):
    q=Query.parse({'source_mode':'local','context':'comparison'},cfg)
    with pytest.raises(ValueError):valid_classification({'score':5,'category':'other_relevance','evidence':[99],'reason':'test'},[{'id':1}],{},q)


def test_no_llm_for_keywords(store,cfg):
    store.ingest(html(),celex='62025CJ0901')
    class Bomb:
        def ready(self):raise AssertionError('LLM must not be called')
    result=execute(store.home,cfg,{'source_mode':'local','keywords':['versions linguistiques']},client=Bomb())
    assert result['status']=='completed-local-subset'
    assert result['summary']['model_calls']==0
    assert (store.home/'runs'/result['run_id']/'shortlist.docx').is_file()


def test_all_selected_documents_processed_and_reused(store,cfg):
    for i in range(901,907):store.ingest(html(number=str(i)),celex=f'62025CJ{i:04d}')
    model=FakeModel()
    q={'source_mode':'local','preset':'court_language_comparison'}
    result=execute(store.home,cfg,q,client=model)
    assert result['summary']['assessed_documents']==6
    assert model.calls==6
    again=execute(store.home,cfg,q,client=model)
    assert model.calls==6
    assert again['summary']['cache_hits']==6


def test_failed_model_is_not_very_low(store,cfg):
    store.ingest(html(),celex='62025CJ0901')
    class Failing(FakeModel):
        def ready(self):raise RuntimeError('model unavailable')
    result=execute(store.home,cfg,{'source_mode':'local','context':'test'},client=Failing())
    assert result['status']=='partial'
    assert result['documents'][0]['score'] is None


def test_discovery_uses_document_date_not_case_registration(cfg):
    q=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','context':'example'},cfg)
    s=discovery_query(q)
    assert 'work_date_document' in s
    assert 'resource_legal_year' not in s
    assert 'ORDER BY ?celex ?date' in s and 'OFFSET' not in s


def test_selection_manifest_invalid_identifier():
    with pytest.raises(ValueError):manifest_records([{'celex':'javascript:wrong'}])


def test_export_formula_safety():
    assert csv_cell('=cmd')=="'=cmd"
    assert csv_cell('C-901/25')=='C-901/25'


@pytest.mark.parametrize('path',['../outside','C:\\secret.txt','/etc/passwd'])
def test_path_escape(tmp_path,path):
    with pytest.raises(ValueError):workspace_path(tmp_path,path)


def test_demo_export_marked_synthetic(store,cfg):
    from curia_lite.demo import install_demo
    from docx import Document
    install_demo(store)
    r=execute(store.home,cfg,{'source_mode':'local','include_demo':True,'keywords':['versions linguistiques'],'min_score':1})
    d=Document(store.home/'runs'/r['run_id']/'shortlist.docx')
    assert 'SYNTHETIC DEMONSTRATION' in '\n'.join(p.text for p in d.paragraphs)


def test_unsupported_source_language_rejected_before_run():
    with pytest.raises(ValueError):validate({'native_languages':['fi']})


def test_word_view_removes_controls_without_changing_original():
    from curia_lite.export import word_view
    original={'reason':'French\x00 text', 'score':3}
    assert word_view(original)=={'reason':'French text','score':3}
    assert original['reason']=='French\x00 text'
