from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs,urlsplit

import pytest
import requests

from curia_lite.engine import execute
from curia_lite.query import Query
from curia_lite.screening import Ollama
from curia_lite.server import Application,handler_class
from curia_lite.sources import discover,obtain,fetch_record
from conftest import html


class OfficialFixtureNetwork:
    def __init__(self):self.cancel=threading.Event();self.calls=[]
    def check(self):pass
    def get(self,url,params=None,headers=None):
        self.calls.append(url)
        if 'sparql' in url:
            q=params['query']
            if 'COUNT' in q:rows=[{'total':{'value':'2'}}]
            elif 'FILTER(?celex >' not in q:rows=[{'work':{'value':f'http://publications.europa.eu/resource/cellar/example-{i}'},'celex':{'value':f'62025CJ0{i}'},'date':{'value':'2025-10-14'}} for i in [901,902]]
            else:rows=[]
            return json.dumps({'results':{'bindings':rows}}).encode(),url,{}
        number=url[-4:]
        language={'fra':'fr','deu':'de','eng':'en'}[(headers or {})['Accept-Language']]
        return html(number,language),url,{}


def test_discover_all_pages_counts_and_cache(store,cfg):
    q=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions']},cfg)
    net=OfficialFixtureNetwork()
    result=discover(q,cfg,store,net,lambda *a,**kw:None)
    assert result['complete'] and len(result['records'])==2
    count=len(net.calls)
    cached=discover(q,cfg,store,net,lambda *a,**kw:None)
    assert cached['cached'] and len(net.calls)==count


def test_all_selected_versions_fetched_then_cached(store,cfg):
    q=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions'],'languages':['fr','de']},cfg)
    records=[{'celex':'62025CJ0901','delivery_date':'2025-10-14'},{'celex':'62025CJ0902','delivery_date':'2025-10-14'}]
    net=OfficialFixtureNetwork()
    first=obtain(records,q,cfg,store,net,lambda *a,**kw:None)
    assert len(first['documents'])==4 and not first['failures']
    calls=len(net.calls)
    second=obtain(records,q,cfg,store,net,lambda *a,**kw:None)
    assert second['cached']==4 and len(net.calls)==calls


def test_changed_source_is_reacquired(store,cfg):
    q=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions']},cfg)
    records=[{'celex':'62025CJ0901'}];net=OfficialFixtureNetwork()
    first=obtain(records,q,cfg,store,net,lambda *a,**kw:None)
    (store.home/first['documents'][0]['source_path']).write_text('damaged')
    second=obtain(records,q,cfg,store,net,lambda *a,**kw:None)
    assert second['downloaded']==1


def test_failed_download_visible_not_low_score(store,cfg):
    class Bad(OfficialFixtureNetwork):
        def get(self,*a,**kw):raise RuntimeError('HTTP blocked fixture')
    q={'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions']}
    result=execute(store.home,cfg,q,network=Bad(),selection={'records':[{'celex':'62025CJ0901'}]})
    assert result['status']=='partial'
    assert result['failures'] and result['cases']==[]


def test_metadata_snapshot_failure_is_not_complete(store,cfg):
    class Bad(OfficialFixtureNetwork):
        def get(self,*a,**kw):raise RuntimeError('fixture unavailable')
    q=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions']},cfg)
    r=discover(q,cfg,store,Bad(),lambda *a,**kw:None)
    assert r['complete'] is False and r['errors']


def fixture_ollama():
    class Handler(BaseHTTPRequestHandler):
        mode='ok'
        payloads=[]
        def log_message(self,*a):pass
        def do_GET(self):
            data={'models':[{'name':'ministral-3:8b','digest':'synthetic-digest'}]}
            raw=json.dumps(data).encode();self.send_response(200);self.end_headers();self.wfile.write(raw)
        def do_POST(self):
            obj=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            Handler.payloads.append(obj)
            self.send_response(200);self.end_headers()
            if self.path=='/api/show':self.wfile.write(b'{"capabilities":["completion"]}');return
            if Handler.mode=='empty':self.wfile.write(b'{"done":true,"done_reason":"stop","message":{"content":""}}\n');return
            if Handler.mode=='error':self.wfile.write(b'{"error":"synthetic failure"}\n');return
            response={'score':1,'category':'no_evidence','evidence':[],'reason':'Synthetic HTTP response'}
            item={'message':{'content':json.dumps(response)},'done':True,'done_reason':'length' if Handler.mode=='length' else 'stop'}
            self.wfile.write((json.dumps(item)+'\n').encode())
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
    return server,Handler


def test_real_http_client_schema_settings_and_stream(cfg):
    server,handler=fixture_ollama()
    try:
        cfg['ollama_url']=f'http://127.0.0.1:{server.server_port}'
        client=Ollama(cfg);assert client.ready()=='synthetic-digest'
        value,metrics=client.chat([{'role':'user','content':'test'}])
        assert value['score']==1
        sent=handler.payloads[-1]
        assert sent['stream'] is True and sent['options']['num_predict']==256
        assert sent['format']['type']=='object' and 'think' not in sent
        assert sent['keep_alive']=='30m'
    finally:server.shutdown();server.server_close()


@pytest.mark.parametrize('mode',['empty','length','error'])
def test_incomplete_model_output_rejected(cfg,mode):
    server,handler=fixture_ollama();handler.mode=mode
    try:
        cfg['ollama_url']=f'http://127.0.0.1:{server.server_port}'
        with pytest.raises((ValueError,RuntimeError)):Ollama(cfg).chat([{'role':'user','content':'test'}])
    finally:server.shutdown();server.server_close()


def test_loopback_ui_token_and_assets(tmp_path,monkeypatch):
    # A system MIME registry must not make executable JavaScript appear as plain text.
    monkeypatch.setattr('curia_lite.server.mimetypes.guess_type', lambda name: ('text/plain',None))
    app=Application(tmp_path/'app')
    server=ThreadingHTTPServer(('127.0.0.1',0),handler_class(app))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    url=f'http://127.0.0.1:{server.server_port}'
    try:
        with requests.Session() as s:
            s.trust_env=False
            r=s.get(url);assert r.status_code==200 and 'CURIA LITE' in r.text and '__SESSION_TOKEN__' not in r.text
            assert s.get(url+'/api/config').status_code==403
            assert s.get(url+'/app.js').headers['Content-Type'].startswith('application/javascript')
            headers={'X-Curia-Token':app.token}
            assert s.get(url+'/api/config',headers=headers).status_code==200
            assert s.post(url+'/api/settings',json={'num_ctx':12},headers=headers).status_code==400
            assert s.get(url,headers={'Host':'malicious.example'}).status_code==403
            assert s.post(url+'/api/demo',json={},headers={**headers,'Origin':'https://malicious.example'}).status_code==403
            assert s.post(url+'/api/demo',json={},headers=headers).json()['imported']==4
    finally:server.shutdown();server.server_close()


def test_cached_superset_avoids_online_discovery(store,cfg):
    net=OfficialFixtureNetwork()
    full=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions']},cfg)
    discover(full,cfg,store,net,lambda *a,**kw:None)
    n=len(net.calls)
    narrow=Query.parse({'date_from':'2025-10-01','date_to':'2025-10-31','keywords':['different']},cfg)
    result=discover(narrow,cfg,store,net,lambda *a,**kw:None)
    assert result['cached'] and len(net.calls)==n


def test_cached_source_receives_inspected_new_metadata(store,cfg):
    store.ingest(html(),celex='62025CJ0901')
    q=Query.parse({'date_from':'2025-01-01','date_to':'2025-12-31','keywords':['versions']},cfg)
    net=OfficialFixtureNetwork()
    acquired=obtain([{'celex':'62025CJ0901','subject_matter':'inspected example'}],q,cfg,store,net,lambda *a,**kw:None)
    assert acquired['cached']==1 and not net.calls
    assert acquired['documents'][0]['subject_matter']=='inspected example'


def test_selection_filters_before_download(store,cfg):
    net=OfficialFixtureNetwork()
    q={'date_from':'2025-01-01','date_to':'2025-12-31','types':['judgment'],'keywords':['versions']}
    r=execute(store.home,cfg,q,network=net,selection={'records':[{'celex':'62025CJ0901','delivery_date':'2025-10-14'},
                                                              {'celex':'62025CC0902','delivery_date':'2025-10-14'},
                                                              {'celex':'62024CJ0200','delivery_date':'2024-01-01'}]})
    assert r['acquisition']['requested']==1 and len(net.calls)==1


def test_curia_discovered_link_uses_selected_language(cfg):
    class Net:
        def __init__(self): self.cancel=threading.Event(); self.urls=[]
        def get(self,url,**kwargs):
            self.urls.append(url)
            if 'liste.jsf' in url:
                return b'<a href="/juris/document/document.jsf?docid=123&amp;doclang=EN">Document</a>',url,{}
            assert parse_qs(urlsplit(url).query)['doclang']==['FR']
            return html(),url,{}
    cfg['provider']='curia';net=Net()
    raw,requested,resolved=fetch_record({'celex':'62025CJ0901'},'fr',cfg,net)
    assert raw and len(net.urls)==2
